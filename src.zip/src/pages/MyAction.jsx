import React, { useState,useEffect } from "react";
import Navbar from "../components/Navbar/Navbar";
import { Link } from "react-router-dom";
import ApprovalScreen from "./ApprovalScreen";
import { BaseUrl } from "../constants/BaseURL";
import axios from "axios";
import { useSelector } from "react-redux";
import $ from 'jquery';
import DataTable from "datatables.net-dt";



const MyAction = () => {
  
  const [state, setstate] = useState(false);
  const [workFlowData, setWorkFlowData] = useState([]);
  const [workflow, setwrokflow] = useState();
  const user = useSelector((state) => JSON.parse(state.auth.userData));
 
  const handldWorkFlow = (e) => {
    console.log(e);
   // if(e.WF_ID.length>0){
    setstate(true);
    setwrokflow(e);
    console.log(workflow);
  //}
}


  useEffect(() => {
    getWorkflow();    
  }, []);
  

  const  getWorkflow = async() => {
    setstate(false);
    let token = sessionStorage.getItem('token');
    const headers = {
      'jwt-token': token      
    };
    
    await axios.get(`${BaseUrl}api/Workflow/GetWorkflow?ADID=${user.User_Id}`, {headers}, {
      withCredentials: true
     
    }).then((response) => {
          setWorkFlowData(response.data.jsonData); // Access the data directly
          setTimeout(() => {
            $('#tbl').DataTable({
                destroy: true,
                
                info: false,
                search: true,
                paging: false,
                sorting: true,
                scrollX: true,
                
            });
        }, 1000);
         })
         .catch((error) => {
           console.log(error);
         });;
  };

  // const getWorkflow = () => {
  //   setstate(false)
  //   fetch(`${BaseUrl}api/Workflow/GetWorkflow?ADID=163402`)   
  //   //fetch("http://localhost:54775/api/Workflow/GetWorkflow?ADID=163402")
  //     .then((response) => response.json())
  //     .then((data) => {
  //       setWorkFlowData(data.jsonData);
  //     })
  //     .catch((error) => {
  //       console.log(error);
  //     });
  // };
console.log("wfdata", workFlowData);

  return (
    <div>
      <Navbar/>
      {!state?
      <div
        className="container"
        style={{ marginTop: "8px", marginLeft: "0px", maxWidth: "100%" }}
      >
        <div className="card">
          <div
            className="card-heading"
            style={{ backgroundColor: "lightgray", height: "44px" }}
          >
            <h4 className="mt-2">
              {" "}
              &nbsp;&nbsp;<i className="fas fa-copy text-info"></i>&nbsp;My
              Action
            </h4>
          </div>
          <div className="card-body">
            <table id="tbl" className="table table-bordered" style={{width:"100%",fontSize:"12px"}}>
              <thead className="table-primary">
                <tr style={{textAlign:"center"}}>
                  <th>Workflow Id</th>
                  <th>Indent Number</th>
                  <th>UMC No</th>
                  <th>WF Category</th>
                  <th>Requested Quantity</th>
                  <th>UOM</th>
                  <th>Source Plant</th>
                  <th>Source LOC</th>
                  <th>Source Dept</th>
                  <th>Storage Loction </th>
                  <th>Pending Since</th>
                </tr>
              </thead>

              <tbody>
                {" "}
                {workFlowData.map((row, index) => (
                  <tr key={index}>
                    {/* <td>
                      {" "}
                      <Link
                        to={{
                          pathname: `/SIS/Approve/`,
                          state: { workflowID: row.WF_ID },
                        }}
                      >
                        {row.WF_ID}
                     </Link>
                    </td> */}

                    <td  className="tblTd">
                      {" "}
                      <a className="btn btn-sm text-primary" onClick={()=>{handldWorkFlow(row)}}>{row.WF_ID}</a>
                     </td>
                    
                    <td className="tblTd">{row.INDENT_ID}</td>
                    <td className="tblTd">{row.REQ_UMC_NO}</td>
                    <td className="tblTd">{row.WF_TYPE}</td>
                    <td className="tblTd">{row.REQ_QUANTITY}</td>
                    <td className="tblTd">{row.UOM}</td>
                    <td className="tblTd">{row.SRC_PLANT_DESC}</td>
                    <td className="tblTd">{row.SRC_LOC_DESC}</td>
                    <td className="tblTd">{row.SRC_DEPT_DESC}</td>
                    <td className="tblTd">{row.SLOC}</td>
                    <td className="tblTd">{row.MOD_DT}</td>
                  </tr>
                ))}{" "}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    :
    
      <ApprovalScreen data={workflow} updateClick={getWorkflow}/>
                      }
  </div>)
};

export default MyAction;
