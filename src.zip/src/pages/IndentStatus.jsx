import React, { useEffect, useState } from "react";
import Navbar from "../components/Navbar/Navbar";
import 'bootstrap-select';// Ensure this import is included in the component file
import 'bootstrap-select/dist/css/bootstrap-select.min.css'; // Ensure CSS is imported
//import "./RaiseRequest.css";
import Swal from "sweetalert2";
import TabMenu from "../components/TabMenu/TabMenu";
import { useSelector } from "react-redux";
import { BaseUrl } from "../constants/BaseURL";
import axios from "axios";
import { useParams } from "react-router-dom";
import "../components/TabMenu/TabMenu.css";
import $ from 'jquery';
import DataTable from "datatables.net-dt";
import 'datatables.net-dt/css/dataTables.dataTables.css'
import './indentMasterStatus.css'


const IndentStatus = () => {

  const [selectedIndentArray, setSelectedIndentArray] = useState([]);
  const [dataTableInstance,setdataTableInstance] =useState(null);
  const indentId = useSelector((state) => state.indent ? state.indent.indentId : '');
  const { id } = useParams();
  const [filterIndentArrays, setFilteredIndentArrays]=useState([]);
  const [INDENTSTATUS, setINDENTSTATUS] = useState("");
  const [DEPARTMENT, setDEPARTMENT] = useState("");
  const [SelindentId, setSelindentId] = useState([]);
  const [selectedCategory, setSelectedCategory] = useState("AIULP");



  useEffect(() => {
    if (indentId !== '') {
      fetchWfList();
    }
  }, [indentId]);

  useEffect(() => {
    if (INDENTSTATUS) {
      setInitialCategory();
    }
  }, [INDENTSTATUS]);

  useEffect(() => {
    filterIndentArray();
  }, [selectedCategory, selectedIndentArray]);

  const fetchWfList = async () => {


    try {

      let token = sessionStorage.getItem('token');
      const headers = {
        'jwt-token': token
      };
      const response = await axios.get(
        `${BaseUrl}api/Report/GetWFDetails?INDENTNO=${indentId}`, { headers }, {
        withCredentials: true

      }
      );
      if (response.data.statusText === "OK") {
        if (dataTableInstance !== null) {       dataTableInstance.destroy(); }
        var dt = JSON.parse(response.data.Data);
        setSelectedIndentArray(JSON.parse(response.data.Data));
      
        setSelindentId(JSON.parse(response.data.Data));
        setINDENTSTATUS(JSON.parse(response.data.Data)[0].INDENTSTATUS);
        setDEPARTMENT(JSON.parse(response.data.Data)[0].INDENTDEPT);
          setTimeout(() => {
           const tbl=   $('#tblMaster').DataTable({
                  destroy: true,
                  order: [[0, "asc"]],
                  info: false,
                  search: true,
                  paging: false,
                  sorting: true,
                  scrollX: true,
                  columnDefs: [{ width: '20%', targets: 0 }]
              });
              setdataTableInstance(tbl);
          }, 1000);

      } else {

        Swal.fire('', 'No data found', 'info');
      }

    } catch (error) {


    }
  };

  const setInitialCategory = () => {
    switch (INDENTSTATUS) {
      case "Pending for AIULP Spare sharing":
        setSelectedCategory("AIULP");
        break;
      case "Pending for INTRA Spare sharing":
        setSelectedCategory("INTRA");
        break;
      case "Pending for INTER Spare sharing":
        setSelectedCategory("INTER");
        break;
      default:
        setSelectedCategory(""); // Handle default case if needed
        break;
    }
  };

  const handleTabClick = (category) => {
    if (isTabClickable(category)) {
      setSelectedCategory(category);
    }
  };

  const isTabClickable = (category) => {

    if (["Pending for Capex Approval", "Pending for Intellibuy Check", "Pending for Shopping Cart"].includes(INDENTSTATUS)) {
      return true;
    }

    switch (INDENTSTATUS) {
      case "Pending for AIULP Spare sharing":
        return category === "AIULP";
      case "Pending for INTRA Spare sharing":
        return category === "AIULP" || category === "INTRA";
      case "Pending for INTER Spare sharing":
        return true;
      default:
        return false;
    }
  };


  const getStatusClass = (tabName) => {

    if (["Pending for Capex Approval", "Pending for Intellibuy Check", "Pending for Shopping Cart"].includes(INDENTSTATUS)) {
      return "green";
    }

    switch (INDENTSTATUS) {
      case "Pending for AIULP Spare sharing":
        if (tabName === "AIULP") return "yellow";
        return "blue disabled";
      case "Pending for INTRA Spare sharing":
        if (tabName === "INTRA") return "yellow";
        if (tabName === "AIULP") return "green";
        return "blue disabled";
      case "Pending for INTER Spare sharing":
        if (tabName === "INTER") return "yellow";
        return "green";
      default:
        return "";
    }
  };

  const filterIndentArray = () => {
    if (selectedCategory === "") {
      // No category selected, show all
      // setFilteredIndentArrays(selectedIndentArray.filter(item => item.CATEGORY === "INTER"));
      setFilteredIndentArrays(selectedIndentArray);
    } else {
      // Filter based on selected category
      setFilteredIndentArrays(selectedIndentArray.filter(item => item.CATEGORY === selectedCategory));
    }
  };



  // const tabNames = {
  //   AIULP: "AIULP",
  //   INTRA: "INTRA",
  //   INTER: "INTER",
  // };
  return (
    <>

      <>
        {/* <Navbar />
      <TabMenu prop={"IndentStatus"}/> */}

      </>
      <div style={{ margin: "0% 10%" }}>
        <div className="arrow-steps clearfix">
          <div
            className={`step ${getStatusClass("AIULP")} ${selectedCategory === "AIULP" ? "selected" : ""}`}
            style={{ minWidth: "30%", cursor: isTabClickable("AIULP") ? "pointer" : "default" }}
            onClick={() => handleTabClick("AIULP")}
          >
            <span>AIULP</span>
          </div>
          <div
            className={`step ${getStatusClass("INTRA")} ${selectedCategory === "INTRA" ? "selected" : ""}`}
            style={{ minWidth: "30%", cursor: isTabClickable("INTRA") ? "pointer" : "default" }}
            onClick={() => handleTabClick("INTRA")}
          >
            <span>INTRA</span>
          </div>
          <div
            className={`step ${getStatusClass("INTER")} ${selectedCategory === "INTER" ? "selected" : ""}`}
            style={{ minWidth: "30%" }}
            onClick={() => handleTabClick("INTER")}
          >
            <span>INTER</span>
          </div>
        </div>
        <br />
      </div>


      
      <div
        className="container"
        style={{ marginTop: "8px", marginLeft: "0px", maxWidth: "100%" }}
      >
        <div className="card">
          <div className="card-body" style={{fontSize:"12px !important"}}>
            {/* <div
            className="card-heading"
            style={{ backgroundColor: "lightgray", height: '44px' }}
          >
            <h4 className="mt-2"> &nbsp;&nbsp;<i className="fas fa-copy text-info"></i>&nbsp; Indent Status</h4>
          </div> */}

            <div className="row">
              <div className="col-md-2" style={{display:"none"}}>

                <h6>Indent Number : &nbsp;{indentId}</h6>

              </div>

              <div className="col-md-4" style={{display:"none"}}>

               <h6>&nbsp;&nbsp;&nbsp;&nbsp;Indent Status :&nbsp;{INDENTSTATUS}</h6>

              </div>

              <div className="col-md-3">

                <h6>Indentor Department :&nbsp; {DEPARTMENT}</h6>

              </div>



                  </div>
                      <div className="row" style={{marginTop:"-72px"}}>
                          <div className="col-md-12">
                              <br/>
                              <table id="tblMaster" className="table table-bordered" style={{width:"90% !important",fontSize:"12px"}}>
                                  <thead className="">
                                      <tr>
                                          <th>Umc No</th>
                                          <th>WF ID</th>
                                          <th>Req Date</th>
                                          <th>Req<br/>Qty</th>
                                          <th>Approved Qty</th>
                                          <th>MR Qty</th>
                                          <th>STO Qty</th>
                                          <th>WF Category</th>
                                          <th>Source Department</th>
                                          <th>Source Plant</th>
                                          <th>Source Location</th>
                                          <th>Storage Loction</th>
                                          <th>Current Status</th>
                                          <th>Pending with</th>
                                          <th>Days Pending</th>
                                          <th>Action Date</th>
                                          <th>Action By</th>
                                          <th>Action</th>
                                      </tr>
                                  </thead>
                                  <tbody>
                                      {filterIndentArrays.map((item, index) => {
                                          return (
                                              <tr key={index}>
                                                  <td className="tblTd">{item.UMC}</td>
                                                  <td className="tblTd"> {item.WF} </td>
                                                  <td className="tblTd">{item.DT}</td>
                                                  <td className="tblTd"> {item.REQ_QUANTITY} </td>

                                                  <td className="tblTd">{item.APPROVED_QTY}</td>
                                                  <td className="tblTd"> {item.MRQTY} </td>
                                                  <td className="tblTd">{item.STOQTY}</td>
                                                  <td className="tblTd"> {item.CATEGORY} </td>

                                                  <td className="tblTd">{item.DEPT}</td>
                                                  <td className="tblTd"> {item.PLANT} </td>
                                                  <td className="tblTd">{item.LOCATION}</td>
                                                  <td className="tblTd">{item.SLOC}</td>
                                                  <td  className="tblTd" style={{backgroundColor:item.COLR}}> {item.CSTATUS} </td>

                                                  <td className="tblTd">{item.PENDINGWITH}</td>
                                                  {item.DYS>-1?
                                                      <td  className="tblTd" style={{backgroundColor:item.COLR}}> {item.DYS} </td>
                                                      :<td></td>}
                                                  <td className="tblTd"> {item.ACTDT} </td>
                                                  <td className="tblTd">{item.ACTBY}</td>
                                                  <td className="tblTd" style={{backgroundColor:item.COLR}}>{item.ACTION} </td>
                                              </tr>
                      );
                    })}
                  </tbody>
                </table>

              </div>
            </div></div>
        </div></div>
    </>
  );
}

export default IndentStatus