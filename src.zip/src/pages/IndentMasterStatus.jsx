import axios from "axios";
import React, { useEffect } from "react";
import { useState } from "react";
import { Navbar } from "react-bootstrap";
import TabMenu from "../components/TabMenu/TabMenu";
import { BaseUrl } from "../constants/BaseURL";
import * as comman from "../constants/CommanConstant";
import $ from 'jquery';
import "bootstrap-select/dist/css/bootstrap-select.min.css";
import Swal from "sweetalert2";
import { setIndentId,clearIndentId } from "../store/indentSlice";
import { useDispatch, useSelector } from "react-redux";
import IndentStatus from "./IndentStatus";
import { useNavigate } from "react-router-dom";
import './indentMasterStatus.css'

import DataTable from "datatables.net-dt";
import 'datatables.net-dt/css/dataTables.dataTables.css'
import moment from "moment";

const IndentMasterStatus = (prop) => {
  const [dataTableInstance,setdataTableInstance] =useState(null);
  const [DocType, setDocType] = useState([]);
  const [fodType, setfodType] = useState([]);
  const [indentList,setIndentList] = useState([]);
  const user = useSelector((state) => JSON.parse(state.auth.userData));
  const [indentStatus, setIndentStatus] = useState([]);
  const [Department, setDepartment] = useState([]);
  const dispatch=useDispatch();
  const navigate = useNavigate();
  const[showDetails,setshowDetails]=useState(false);

  useEffect(() => {
    setDate();
    fetchDoctumentList();
    fetchFodList();
    fetchIndentStausList();
    fetchDepartmentList();
   
   
 
      handleClick();
  }, []);
  const fetchDoctumentList = async () => {
    try {
      const response = await axios.get(
        `${BaseUrl}api/Master/GetCodeList?CODE=${comman.DocumentTypeCode}`
      );
      const data = response.data;

      setDocType(data);
    } catch (error) {
      console.log(error);
    }
  };
  const fetchFodList = async () => {
    try {
      const response = await axios.get(
        `${BaseUrl}api/Master/GetCodeList?CODE=${comman.FODCode}`
      );
      const data = response.data;

      setfodType(data);
    } catch (error) {
      console.log(error);
    }
  };
  const fetchIndentStausList = async () => {
    try {
      const response = await axios.get(
        `${BaseUrl}api/Master/GetCodeList?CODE=${comman.IndentStatusCode}`
      );
      const data = response.data;

      setIndentStatus(data);
    } catch (error) {
      console.log(error);
    }
  };
  const fetchDepartmentList = async () => {
    try {
      
      const response = await axios.get(`${BaseUrl}api/Master/GetDepartment?adid=${user.User_Id}`);
      const data = response.data;
     
      setDepartment(data);
      
      
    } catch (error) {
      console.log(error);
    }
  };
  const getDetails=(lst)=>{
   
    setshowDetails(false);
   
      dispatch(setIndentId(lst.ID));
     navigate("/SIS/SmartIndenting");
      //var url="/SIS/WfStatus/"+lst.ID;
      //window.open(url,'_blank');
     

  
  
   
  }
 
  const setDate=()=>{
    $("#DTF").val(moment().subtract(7,'d').format('YYYY-MM-DD'));
    $("#DTT").val(moment().format('YYYY-MM-DD'))
  }
  const handleClick=()=>{

   
    if (dataTableInstance !== null) {       dataTableInstance.destroy(); }
   
  
    let token = sessionStorage.getItem('token');
            const headers = {
            'jwt-token': token      
            };
           
    setshowDetails(false);
    var fliter={
        DTF:$("#DTF").val(),
        DTT:$("#DTT").val(),
        DEPT:$("#DEPT").val(),
        FOD:$("#FOD").val(),
        STATUS:$("#STATUS").val(),
        INDENTNO:$("#INDENTNO").val(),
        DOCTYPE:$("#DOCTYPE").val(),
        USERNAME:user.User_Id
    }
    try {
      
      console.log("headers Token : ", headers)
        axios.post(`${BaseUrl}api/Report/GetIndentStatus`, fliter, {
          withCredentials: true
         
        })
  
          .then((response) => {
            if (response.data.statusText === "OK") {
                setIndentList(JSON.parse(response.data.Data));
                
                  setTimeout(() => {
                    const tbl=  $('#tbl').DataTable({
              destroy:true,
              order:[[0,"asc"]],
                     info:false,
                     searching:false,
                     paging:false,
                     sorting:true,
                     scrollX:false,
                     
                    }); 
                    setdataTableInstance(tbl);
                 }, 1000);
               
              prop.hideLoader();
             
            } else {
              prop.hideLoader();
              //Swal.fire('','No data found','info');
            }
          });
      } catch (error) {
        prop.hideLoader();
       
      }
  }
  return (
    <>
    <Navbar/>
   
    <div>
      <div className="container" style={{ marginTop: "10px", maxWidth: "100%",fontSize:"12px !important" }}>
        <div className="card" >
           <div
            className="card-heading"
            style={{ backgroundColor: "lightgray", height: "44px" }}
          >
            <h4 className="mt-2">

              &nbsp;&nbsp;<i className="fas fa-search text-info"></i>&nbsp;Search Indent
            </h4>
          </div> 
          <div className="card-body"  style={{fontSize:"12px !important"}}>
            <div className="row">
              <div className="col-md-3 colmd1">
                <label className="labelFont">Indent Number</label>
                <input Type="text" id="INDENTNO" className="form-control  labelFont" />
              </div>
              <div className="col-md-3 colmd2">
                <label className="labelFont">Indent Status</label>
                <select id="STATUS" className="form-control  labelFont">
                  <option value="">All</option>
                  {indentStatus.map((itm, id) => (
                    <option key={id} value={itm.ID}>
                      {itm.VAL}
                    </option>
                  ))}
                </select>
              </div>
              <div className="col-md-3 colmd2">
                <label className="labelFont">Department</label>
                <select id="DEPT" className="form-control  labelFont">
                  <option value="">All</option>
                  {Department.map((itm, id) => (
                    <option key={id} value={itm.dept}>
                      {itm.deptName}({itm.dept})
                    </option>
                  ))}
                </select>
              </div>
              <div className="col-md-3 mt-2" style={{width:"12% !important"}}>
                <label className="labelFont">FOD Type</label>
                <select id="FOD" className="form-control  labelFont">
                  <option value="">All</option>
                  {fodType.map((itm, id) => (
                    <option key={id} value={itm.ID}>
                      {itm.VAL}
                    </option>
                  ))}
                </select>
              </div>
              <div className="col-md-3 colmd2">
                <label className="labelFont">Document Type</label>
                <select id="DOCTYPE" className="form-control  labelFont">
                  <option value="">All</option>
                  {DocType.map((itm, id) => (
                    <option key={id} value={itm.ID}>
                      {itm.VAL}
                    </option>
                  ))}
                </select>
              </div>
             
           
            
            
              <div className="col-md-3 mt-2">
                <label className="labelFont">Date From</label>
                <input Type="date" id="DTF" className="form-control  labelFont" />
              </div>
              <div className="col-md-3 mt-2">
                <label className="labelFont">Date To</label>
                <input Type="date" id="DTT" className="form-control  labelFont" />
              </div>
              <div className="col-md-2 mt-4 colmd1">
                <a className="btn btn-primary labelFont" onClick={()=>handleClick()}><i className="fas fa-television"></i> &nbsp;View</a>
              </div>
            </div>
         <hr/> 
     

        
          <table className="table table-bordered"  style={{width:"100%",fontSize:"12px"}} id="tbl">
                  <thead className="table-primary">
                    <tr>
                      
                      <th>Indent Id</th>
                      <th>Department</th>
                      <th>Plant</th>
                      <th>Location</th>
                      <th>Requested By</th>
                      <th>Requested On</th>
                      <th>Indent Status</th>
                      <th>Indent Description</th>
                      <th>Remarks</th>
                     
                      
                    </tr>
                  </thead>
                  <tbody>
                 { indentList.map((item, index) => {
                      return (
                        <tr key={index}>
                          <td className="tblTd">
                            <a
                            style={{color:"blue",fontWeight:"bold",cursor:"pointer"}}
                              onClick={() =>getDetails(item)}
                             
                            >
                              {item.ID}
                            </a>
                          </td>
                          <td className="tblTd">{item.DEPT}</td>
                          <td className="tblTd">{item.PLANT}</td>
                          <td className="tblTd">{item.LOCATION}</td>
                          
                          <td className="tblTd"> {item.USR} </td>
                          <td className="tblTd"> {item.DT} </td>
                          <td className="tblTd">{item.STATUS}</td>
                          <td className="tblTd"> {item.DES} </td>
                          <td className="tblTd"> {item.REMARKS} </td>
                          
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
            </div>
            </div>
          </div>
      </div>
    </>
  );
};

export default IndentMasterStatus;
