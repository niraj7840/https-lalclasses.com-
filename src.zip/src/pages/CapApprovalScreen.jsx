import React, { useRef } from 'react'
import Navbar from '../components/Navbar/Navbar';
import { FaWpforms } from "react-icons/fa6";
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import LoadingBar from 'react-top-loading-bar'
import { BaseUrl } from "../constants/BaseURL";
import "../pages/CapApprovalScreen.css"
import Swal from 'sweetalert2';
import { useDispatch, useSelector } from "react-redux";


const CapApprovalScreen = ({showLoader, hideLoader}) => {

    const [show, setShow] = React.useState(false);


    const role = "level_1";
    //const role="level_2";
    //const role = "capex";

    const [requestData, setRequestData] = React.useState([]);
    const [dataForEachId, setdataForEachId] = React.useState([]);
    const [selectedRequestId, setSelectedRequestId] = React.useState(null);
    const [selectedRequestDetails, setSelectedRequestDetails] = React.useState([]);
    const [remark, setRemark] = React.useState("");
    const [message, setMessage] = React.useState("");
    const [showSuccessModal, setShowSuccessModal] = React.useState(false);
    const [clickedRequestedId, setClickRequestedId] = React.useState(null);
    const [selectedUmc, setSelectedUmc] = React.useState(null);
    const [progress, setProgress] = React.useState(0)
    const user = useSelector((state) => JSON.parse(state.auth.userData));

    const detailsRef = useRef(null);
    const navigate = useNavigate();

    // React.useEffect(()=>{
    //     fetchrolefromadid();
    // }, [user.User_Id])

    React.useEffect(() => {
        setProgress(20)
        showLoader();
        fetchGetApproverScreenData();
        setProgress(100)
    }, [role]);



    React.useEffect(() => {
        if (show && detailsRef.current) {
            detailsRef.current.scrollIntoView({ behavior: 'smooth' });
        }
    }, [show, selectedRequestId]);


    const fetchrolefromadid=async()=>{
        try {
            const result = await axios.get(`${BaseUrl}api/CapitalApprover/GetRole`, {
                params: {
                    //adid: user.User_Id,
                    adid:158876
                },
            });
            console.log("User id for 1 ", result.data.jsonData["BAG"])
        } catch (err) {
            
        }

    }

    const fetchGetApproverScreenData = () => {
        let apiUrl = '';
        if (role === 'level_1') {
            apiUrl = `${BaseUrl}api/CapitalApprover/GetApproverScreen1/level_1`;
        } else if (role === 'level_2') {
            apiUrl = `${BaseUrl}api/CapitalApprover/GetApproverScreen1/level_2`;
        } else if (role === 'capex') {
            apiUrl = `${BaseUrl}api/CapitalApprover/GetApproverScreen1/capex`;
        } else {
            alert("Unauthored!");
            return;
        }

        fetch(apiUrl)
            .then(response => {
                if (!response.ok) {
                    throw new Error('Network response was not ok');
                }
                return response.json();
            })
            .then(data => {
                setdataForEachId(data.jsonData);

                const uniqueRequests = getUniqueRequests(data.jsonData);
                console.log(uniqueRequests, "requesteddata");

                // const filteredData = uniqueRequests.filter(item => item.CUA_DEPTNO === '178');
                // setRequestData(filteredData);
                setRequestData(uniqueRequests);
                hideLoader();
            })
            .catch(error => {
                console.error('Error fetching data:', error);
                // Handle error as needed, e.g., show error message to user
            });
    
        }


    const handleApproveRequest = async () => {
        //setProgress(30);
        // Make sure there's a selected request and a remark
        if (!remark) {
            Swal.fire('', "Please enter Remarks", 'info');
            return;
        }

        if (selectedRequestId === null) {
            //console.log("selectedId1", selectedRequestId)
            Swal.fire('', "Please select any Id", 'info');
            return;
        }

        setProgress(30);
        showLoader()

        try {
            if (role === 'level_1') {
                // Make PUT request to update the request with the provided remark
                console.log("user1111", user);
                console.log("remarks", remark);
                const response = await axios.put(`${BaseUrl}api/CapitalApprover/UpdateApproverScreenRequestID/level_1`, {
                    CUA_REQUEST_ID: selectedRequestId,
                    CUA_LEVEL1_APPRD_BY: user.User_Id,
                    CUA_LEVEL1_APPRD_REMARKS: remark
                });

                // console.log("updated", response.data.jsonData);
                handleSuccess(role, "approved");
                setShowSuccessModal(true);
                setMessage("Request has been successfully Approved!");
                setProgress(100);
                hideLoader()
            } else if (role === 'level_2') {
                // Make PUT request to update the request with the provided remark
                const response = await axios.put(`${BaseUrl}api/CapitalApprover/UpdateApproverScreenRequestID/level_2`, {
                    CUA_REQUEST_ID: selectedRequestId,
                    CUA_LEVEL2_APPRD_BY: user.User_Id,
                    CUA_LEVEL2_APPRD_REMARKS: remark
                });

                // console.log("updated", response.data.jsonData);
                handleSuccess(role, "approved");
                setShowSuccessModal(true);
                setMessage("Request has been successfully Approved!");
                setProgress(100);
                hideLoader()
            } else if (role === 'capex') {
                setProgress(30);
                // Make PUT request to update the request with the provided remark
                const response = await axios.post(`${BaseUrl}api/CapitalApprover/CAPEXMARKEDCAPITAL/capex`, {
                    CUA_REQUEST_ID: selectedRequestId,
                    CUA_CAPACCNTS_APPRD_BY: user.User_Id,
                    CUA_CAPACCNTS_APPRD_REMARKS: remark,
                    CRU_UMC: selectedUmc,
                    CRU_TAG: 'C',
                    CRU_REQUEST_ID: selectedRequestId,
                    CRU_STATUS: 'N',
                });

                console.log("response for capex", response)

                handleSuccess(role, "approved");
                setShowSuccessModal(true);
                setMessage("Request has been successfully Approved and UMC marked as Capital");
                // console.log('Success:', data.data);
                hideLoader()
                setProgress(100);
            }
        } catch (error) {
            console.error('Error:', error);
        }
    };

    const handleRejectRequest = () => {
        // Make sure there's a selected request and a remark

        if (!remark) {
            Swal.fire('', "Please enter Remarks", 'info');
            return;
        }


        if (selectedRequestId === null) {
            Swal.fire('', "Please select any Id", 'info');
            return;
        }

        setProgress(30);
        showLoader()
        // Make PUT request to update the request with the provided remark
        fetch(`${BaseUrl}api/CapitalApprover/REJECTNMARKEDREVENUE/${role}`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                CUA_REQUEST_ID: selectedRequestId,
                CUA_LEVEL1_APPRD_REMARKS: role==='level_1'?remark:null,
                CUA_LEVEL2_APPRD_REMARKS: role==='level_2'?remark:null,
                CUA_CAPACCNTS_APPRD_REMARKS: role==='capex'?remark:null,
                CRU_UMC: selectedUmc,
                CRU_TAG: 'R',
                CRU_REQUEST_ID: selectedRequestId,
                CRU_STATUS: 'N',
                CRU_CREATED_BY:user.User_Id
            }),

        })
            .then(response => {
                const data = response.data;
                handleSuccess(role, "rejected");
                setProgress(100)
                setShowSuccessModal(true)
                setMessage("Sorry! Request has been rejected and UMC marked as Revenue");

                console.log('Success:', data);
                // Handle success response
                hideLoader();

            })
            .catch(error => {
                console.error('Error:', error);
                // Handle error
            });
    }




const handleSuccess = (role, action) => {
    // Optimistically update the local state
    const updatedRequests = requestData.filter(request => request.CUA_REQUEST_ID !== selectedRequestId);
    const updatedDetails = dataForEachId.filter(request => request.CUA_REQUEST_ID !== selectedRequestId);

    setRequestData(updatedRequests);

    setdataForEachId(updatedDetails);

    setRemark("");
    setSelectedRequestId(null);

    //setShowSuccessModal(true);
    //setMessage(`Your Request has been successfully ${action} by ${role.toUpperCase()} team`);
};



const getUniqueRequests = (data) => {
    // Create a map to store unique requests by CUA_REQUEST_ID
    const requestMap = new Map();
    data.forEach(request => {
        if (!requestMap.has(request.CUA_REQUEST_ID)) {
            requestMap.set(request.CUA_REQUEST_ID, request);
            console.log(requestMap)
        }
    });
    // Convert the map values to an array
    return Array.from(requestMap.values());
};


const formatDateFromBackend = (dateString) => {
    // 1. Parse the input date string into a Date object
    const date = new Date(dateString);

    // 2. Extract year, month,  hours, minutes, and seconds from the Date object
    const year = date.getFullYear();
    const month = date.toLocaleString('default', { month: 'short' }).toUpperCase();
    let hours = date.getHours();
    const minutes = date.getMinutes();
    const seconds = date.getSeconds();

    // 3. Determine AM/PM
    const ampm = hours >= 12 ? 'PM' : 'AM';

    // 4. Convert hours to 12-hour format
    hours = hours % 12;
    hours = hours ? hours : 12; // Handle midnight (0 hours)

    // 5. Format the components into the desired string
    const formattedDate = `${date.getDate()}-${month}-${year}, ${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')} ${ampm}`;

    // 6. Return the formatted date string
    return formattedDate;
};





const handleShowDetails = (requestId) => {
    setShow(true)
    setClickRequestedId(requestId)
    // Filter details of the selected request
    const requestDetails = dataForEachId.filter(request => request.CUA_REQUEST_ID === requestId && request.CUR_RESPONSE != null);

    requestDetails.sort((a, b) => a.CUR_QUESTION_ID - b.CUR_QUESTION_ID)
    const umc = requestDetails.length > 0 ? requestDetails[0].CUA_UMC : null;
    console.log("umc", umc);
    setSelectedUmc(umc);
    console.log(requestId)
    console.log("detail", requestDetails)
    setSelectedRequestId(requestId);
    setSelectedRequestDetails(requestDetails);


    /**   if(detailsRef.current) {
          detailsRef.current.scrollIntoView({behavior: 'smooth'});
      }*/

};

const handleCloseModal = () => {
    setShow(false)
    setShowSuccessModal(false);
    //navigate("/SIS/ViewCapitalRequest");
    //window.location.reload();
}

return (
    <>
        <LoadingBar
            color='#f11946'
            progress={progress}
            onLoaderFinished={() => setProgress(0)}
        />
        <Navbar />

        <div
            className="container"
            style={{ marginTop: "8px", marginLeft: "2px", maxWidth: "100%" }}
        >
            <div className="card">
                <div
                    className="card-heading"
                    style={{
                        backgroundColor: "lightgray", // fallback background color
                        //backgroundImage: "linear-gradient(to right, #62a7c1, #10b6c8, #00c4bd, #00cf9e, #38d771)",
                        height: '48px',
                        display: 'flex',
                        justifyContent: 'center',
                        alignItems: 'center'
                    }}
                >
                    <h4 style={{ display: 'flex', alignItems: 'center', gap: '8px', color: "#080808de" }} className="mt-1"><i style={{ fontSize: "30px", marginBottom: "5px" }}><FaWpforms /></i>Pending Request For Approval</h4>
                </div>

                <div className="card-body">

                    <section className="requestTable mt-1">
                        <table className="table text-center table-bordered">
                            <thead className="table-primary">
                                <tr>
                                    <th style={{ fontWeight: 500 }}>Request Number</th>
                                    <th style={{ fontWeight: 500 }}>UMC NO</th>
                                    <th style={{ fontWeight: 500 }}>Request Date</th>
                                    <th style={{ fontWeight: 500 }}>Show Details</th>

                                </tr>
                            </thead>
                            <tbody>

                                {requestData.map(request => (

                                    <tr key={request.CUA_REQUEST_ID} className={clickedRequestedId === request.CUA_REQUEST_ID ? 'highlighted-row' : ''}>
                                        <td>{request.CUA_REQUEST_ID}</td>
                                        <td>{request.CUA_UMC}</td>
                                        <td>{formatDateFromBackend(request.CUR_CREATED_ON)}</td>
                                        <td><button onClick={() => handleShowDetails(request.CUA_REQUEST_ID)}
                                            style={{
                                                color: clickedRequestedId === request.CUA_REQUEST_ID ? 'red' : 'blue',
                                                textDecoration: "none",
                                                background: "none",
                                                border: "none",
                                                padding: 0,
                                                cursor: "pointer"
                                            }}>Show Details</button></td>
                                    </tr>
                                ))}

                            </tbody>
                        </table>
                    </section>
                    <section>

                        {show && selectedRequestId && (
                            <div>
                                <h5 className='TableHeading'>Details of Request Id #{selectedRequestId}</h5>
                                <table className="table text-center table-bordered">
                                    <thead className="table-primary">
                                        <tr>
                                            <th>Question ID</th>
                                            <th>Question Description</th>
                                            <th>Response</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        {selectedRequestDetails.map(detail => (
                                            <tr key={detail.CUR_QUESTION_ID}>
                                                <td>{detail.CUR_QUESTION_ID}</td>
                                                <td>{detail.CQM_QUES_DESC}</td>
                                                <td>{detail.CUR_RESPONSE}</td>
                                            </tr>
                                        ))}
                                    </tbody>
                                </table>
                            </div>
                        )}

                    </section>

                    <section ref={detailsRef}>
                        <div
                            className="container1">
                            <div className="row">
                                <div className="col-md-2">

                                    <label style={{
                                        "fontWeight": "600",
                                        "alignContent": "center",
                                        "paddingTop": "8px"
                                    }}>Enter Remarks for ID {selectedRequestId}:</label>


                                </div>
                                <div className="col-md-4">
                                    <input
                                        className="form-control"
                                        type="text"
                                        value={remark}
                                        onChange={(e) => setRemark(e.target.value)}
                                        placeholder='Enter Remarks'
                                    />
                                </div>
                            </div>
                        </div>
                    </section>

                    <section className='text-center'>
                        <div
                            className="container1">
                            <div className="row">
                                <div className="col">
                                    <button onClick={handleApproveRequest} style={{ paddingLeft: "50px", paddingRight: "50px" }} type="submit" className="btn btn-success mt-4">Approve</button>



                                </div>
                                <div className="col">
                                    <button onClick={handleRejectRequest} style={{ paddingLeft: "50px", paddingRight: "50px" }} type="submit" className="btn btn-danger mt-4">Reject</button>
                                </div>
                            </div>
                        </div>
                    </section>

                </div>



            </div>
        </div>


        {showSuccessModal && (
            <>
                <div className="modal-backdrop fade show"></div>
                <div className="modal fade show" style={{ display: 'block' }} tabIndex="-1">
                    <div className="modal-dialog">
                        <div className="modal-content">
                            <div className="modal-header">
                                <h5 className="modal-title">Success</h5>
                                <button type="button" className="btn-close" onClick={handleCloseModal} aria-label="Close"></button>
                            </div>
                            <div className="modal-body">
                                <p>{message}</p>
                            </div>
                            <div className="modal-footer">
                                <button type="button" className="btn btn-primary" onClick={handleCloseModal}>Close</button>
                            </div>
                        </div>
                    </div>
                </div>
            </>
        )}
    </>
);
}

export default CapApprovalScreen
