import React, { useState, useEffect } from "react";
import Navbar from "../components/Navbar/Navbar";
import ApprovalScreen from "./ApprovalScreen";
import { BaseUrl, LocalUrl } from "../constants/BaseURL";
// import "bootstrap-select";
// import "bootstrap-select/dist/css/bootstrap-select.min.css";
//import "static/js/bundle.js";
import "./IntelliBuySystemChecks.css";
import MaxQtyModal from "../components/IntelliBuy/MaxQtyModal";
import RequirmentConsumptionModal from "../components/IntelliBuy/RequirmentConsumptionModal";
import RefurshibilityModal from "../components/IntelliBuy/RefurshibilityModal";
import VMIModal from "../components/IntelliBuy/VMIModal";
import DepropModal from "../components/IntelliBuy/DepropModal";
import axios from "axios";
import TabMenu from "../components/TabMenu/TabMenu";
import Swal from "sweetalert2";
import Tabs from "react-bootstrap/Tabs";
import Tab from "react-bootstrap/Tab";
import { Link } from "react-router-dom";
import { Label, TextArea } from "react-aria-components";
import Select from "react-select";
import "./ShoppingCart.css";
import {
  Container,
  Row,
  Col,
  Form,
  FormGroup,
  Collapse,
} from "react-bootstrap";
import * as moment from "moment";
import { useNavigate } from "react-router-dom";

import { Button, Modal, ModalHeader, ModalBody, ModalFooter, Input } from 'reactstrap';
import 'bootstrap/dist/css/bootstrap.min.css';

const PendingForApproval = (prop) => {

  const navigate = useNavigate();
  const [state, setstate] = useState(false);
  const [workFlowData, setWorkFlowData] = useState([]);
  const [indentno, setIndentNo] = React.useState("10000115");
  const [indentstatus, setIndentStatus] = React.useState("");
  const [indentdept, setIndentDept] = React.useState("");
  const [isLoading, setisLoading] = useState(true);
  const [show, setShow] = useState(false);
  const [showrcm, setShowRCM] = useState(false);
  const [showrefurshibility, setShowRefurshibility] = useState(false);
  const [showvmi, setShowVMI] = useState(false);
  const [showdeprop, setShowDeprop] = useState(false);
  const [selectedData, setSelectedData] = useState({});
  const [filterText, setFilterText] = useState("");
  const [currentPage, setCurrentPage] = useState(1);
  const [selectedRow, setSelectedRow] = useState(null);
  const [CsrCategoryList, Setcsrcategorylist] = useState([]);
  const [CsrSubCategoryList, Setcsrsubcategorylist] = useState([]);
  const [CsrSubActivityList, Setcsrsubactivitylist] = useState([]);
  // const [selectedOptions, setSelectedOptions] = useState([]);
  const [checkedItems, setCheckedItems] = useState([]);
  const [filterTextTable, setFilterTextTable] = useState("");
  const [rows, setRows] = useState([
    { Line: 1, Percentage: "100", Assigned: "" },
    { Line: 2, Percentage: "", Assigned: "" },
    { Line: 3, Percentage: "", Assigned: "" },
    { Line: 4, Percentage: "", Assigned: "" },
    { Line: 5, Percentage: "", Assigned: "" },
  ]);
  const [selectedOptions, setSelectedOptions] = useState([]);
  const [selectedOption, setSelectedOption] = useState([]);
  const [subactivityselectedOption, setSubActivitySelectedOption] =
    useState("");
  const [RCMstatus, setRCMStatus] = useState("");
  const [VMIstatus, setVMIStatus] = useState({});
  const [open, setOpen] = useState(false);
  const togglePanel = () => {
    setOpen(!open);
  };




  //---------------------------Start Approver section-----------------------
  const [selectedOptionRd, setSelectedOptionRd] = useState('');
  const [app_remarks, setApp_remarks] = useState('');

  const handleOptionChange = (e) => {
    setSelectedOptionRd(e.target.value);
  };

  const handleRemarksChange = (e) => {
    setApp_remarks(e.target.value);
  };

  const handleSubmit = (e) => {
   
    // Add your form submission logic here

    var ApproverformDetails = {

      nscnum: shoppingcartno, //"4100000040",
      _status: selectedOptionRd,
      appr_id: "163402",
      appr_rem: app_remarks,
      mail_to: "ALL",
      IMEI_no: "WEB"
    }
    console.log("Response:", ApproverformDetails);

    try {
      axios.post(`${BaseUrl}api/ShoppingCart/SCApproverSection`, ApproverformDetails
      )
     
  .then(response => {
    // Handle success
    console.log("Response:", response);
    if (response.status === 200) {
      Swal.fire("", "ShoppingCart Approved Successfully", "success");
    } else {
      // Handle unexpected response
      Swal.fire("", "Something went wrong", "error");
    }
  })
    } 
    
    catch (error) {
      console.error("Error in Axios POST request:", error);
      prop.hideLoader();
      setisLoading(false);
    }  
    
    


  


  };

  //---------------------------End Approver section-----------------------



  const addRow = () => {
    const newRow = {
      Line: rows.length + 1,
      Percentage: "",
      Assigned: "",
    };
    setRows([...rows, newRow]);
  };
  const itemsPerPage = 5;

  ///-------------MaxQty Modal---------//
  const MaxQtyStatus = workFlowData.some((item) => item.QTY > item.ALLOWEDQTY);
  const hanldeDelete = (rowno) => {
    const newData = workFlowData.map((item) =>
      item.UMC_INDENT_ID === rowno ? { ...item, ISACTIVE: "N" } : item
    );
    setWorkFlowData(newData);
    const filteredData = newData.filter((item) => item.ISACTIVE === "Y");
    const totalPage = Math.ceil(filteredData.length / itemsPerPage);
    setCurrentPage(totalPage);
  };

  const getUpdateQty = () => {
    setWorkFlowData(workFlowData);
  };
  const hanldeClick = (selectedRec) => {
    getUpdateQty();
    setShow(true);
  };

  const hideModal = () => {
    setShow(false);
  };

  ///-------------Refurshibility Modal---------//

  const hanlderefurshibilityClick = (selectedRec) => {
    getrefurshibility();
    setShowRefurshibility(true);
  };

  const hiderefurshibilityModal = () => {
    setShowRefurshibility(false);
  };

  const getrefurshibility = () => {
    setWorkFlowData(workFlowData);
  };

  ///-------------RequirmentConsumption Modal---------//
  const formatDateInput = (dateStr) => {
    const parts = dateStr.split("-");
    if (parts.length === 3) {
      return `${parts[2]}-${parts[1]}-${parts[0]}`;
    } else {
      return dateStr;
    }
  };
  const formatDate = (date) => {
    if (!date) return ""; // Handle empty date case
    const formattedDate = new Date(date).toISOString().split("T")[0];
    return formattedDate;
  };
  const hanldeRCMEdit = (index, field, ChangeDT, SysDT) => {

    const newData = [...workFlowData];
    const strSysTM = new Date(SysDT);
    strSysTM.setMonth(strSysTM.getMonth() + 3);
    const strSysDT = new Date(SysDT).getTime();
    const strChangeDT = new Date(ChangeDT).getTime();
    const strSysTMTime = strSysTM.getTime();

    if (field === "REQUIREMENT_DATE") {
      debugger;

      if (strChangeDT < strSysDT) {
        setRCMStatus("Red"); // red
      }
      else if (strChangeDT >= strSysDT) {
        setRCMStatus("Green"); // green
      }
      if (strSysTMTime <= strChangeDT) {
        setRCMStatus("Red"); // red
      }
    }
    newData[index][field] = ChangeDT;
    newData[index]["RCM_Status"] = RCMstatus;
    newData[index]["VMI_Status"] = VMIstatus;
    setWorkFlowData(newData);
  };

  const hanldeRCMClick = (selectedRec) => {
    getRCM();
    setShowRCM(true);
  };
  const hideRCMModal = () => {
    setShowRCM(false);
  };
  const getRCM = () => {
    setWorkFlowData(workFlowData);
  };

  ///-------------VMI-----------//

  const hanldeVMIClick = (selectedRec) => {
    getVMI();
    setShowVMI(true);
  };

  const hideVMIModal = () => {
    setShowVMI(false);
  };

  const getVMI = () => {
    setWorkFlowData(workFlowData);
  };

  ////---------------Deprop------------///
  const hanldeDepropClick = (selectedRec) => {
    getDeprop();
    setShowDeprop(true);
    console.log(workFlowData, "workFlowData");
  };

  const hideDepropModal = () => {
    setShowDeprop(false);
  };

  const getDeprop = () => {
    setWorkFlowData(workFlowData);
  };

  const handleFilterChange = (event) => {
    setFilterText(event.target.value);

    setCurrentPage(1);
  };

  ////    for pagination      /////
  const hanldeSearchClick = async (IndentNo) => {
    debugger;
    if (IndentNo.length > 0) {
      await axios
        .get(
          `${BaseUrl}api/ShoppingCart/GetIntelliBuyChecksDetails?IndentId=${IndentNo}`
        )
        .then((response) => {
          const data = response.data;
          console.log(data.jsonData, "Data");
          if (data.jsonData.length > 0) {
            setWorkFlowData(data.jsonData);
            // setDocumentType(data.jsonData[0].DOCUMENT_TYPE_DESC);
            // setStorageLocation(data.jsonData[0].DEST_SLOC);
            // setPurchaseGroup(data.jsonData[0].PG_DESC);
            // setProcurementType(data.jsonData[0].PROC_TYPE);
            setUnderConsumption();
            // setRequirementDate(data.jsonData[0].REQUIREMENT_DATE);
            setShoppingCartNo(data.jsonData[0].SCH_CART_NO);
            const SCId=data.jsonData[0].SCH_CART_NO;
            console.log("data.jsonData", data.jsonData);

            try {
              const response =  axios.get(
                `${BaseUrl}api/ShoppingCart/GetShoppingCartDetails?SCId=${SCId}`
              )
              .then((response) => {
                const data = response.data;
                SetShoppingCartName(data.jsonData[0].SCH_CART_NAME);
              
              });


             
             
            } catch (error) {
           
            }
            

          } else {
            Swal.fire("", "No Data Found", "info");
            setWorkFlowData([]);
            setShoppingCartNo("");
            setIndentDept("");
          }

          ////console.log(data.jsonData[0].INDENT_STATUS,'INDENT_CURRENT_STATUS');
        })
        .catch((error) => {
          //console.log(error);
        });
    } else {
      Swal.fire("", "Please fill Indent No", "error");
    }
  };
  // Function to calculate the product
  const calculatePrice = (value1, value2) => {
    return (value1 * value2).toFixed(3);
  };

  const filteredData = workFlowData.filter((row) => {
    // Convert the filter text to lowercase for case-insensitive comparison
    const searchText = filterText.toLowerCase();

    // Iterate through each column in the row
    for (const key in row) {
      const value = row[key];

      // Check if the value exists
      if (value !== undefined && value !== null) {
        if (typeof value === "string") {
          // Convert the string value to lowercase
          const columnValue = value.toLowerCase();
          // Check if the column value contains the filter text
          if (columnValue.includes(searchText)) {
            // If found, return true to include this row in the filtered data
            return true;
          }
        } else if (typeof value === "number") {
          // Convert the integer value to string
          const columnValue = value.toString();
          // Check if the column value contains the filter text
          if (columnValue.includes(searchText)) {
            // If found, return true to include this row in the filtered data
            return true;
          }
        }
      }
    }
    // If no match is found in any column, return false to exclude this row from the filtered data
    return false;
  });

  const totalPages = Math.ceil(filteredData.length / itemsPerPage);
  //console.log(totalPages, "Total page");
  //console.log(filteredData, "filteredData");
  // const currentData = filteredData.slice(
  //   (currentPage - 1) * itemsPerPage,

  //   currentPage * itemsPerPage
  // );
  const currentData = filteredData
    .filter((row) => row.ISACTIVE === "Y")
    .slice((currentPage - 1) * itemsPerPage, currentPage * itemsPerPage);

  const handlePageChange = (pageNumber) => {
    setCurrentPage(pageNumber);
  };

  const hanldeEdit = (index, field, event) => {
    const newData = [...workFlowData];
    newData[index][field] = event;
    setWorkFlowData(newData);
  };


  const handleDeleteRow = (UMC_INDENT_ID) => {
    const newData = workFlowData.map((item) =>
      item.UMC_INDENT_ID === UMC_INDENT_ID ? { ...item, ISACTIVE: "N" } : item
    );
    setWorkFlowData(newData);
    const filteredData = newData.filter((item) => item.ISACTIVE === "Y");
    const totalPage = Math.ceil(filteredData.length / itemsPerPage);
    setCurrentPage(totalPage);
  };

  const handleButtonShowClick = (umcIndentId) => {
    setSelectedRow(umcIndentId); // Set the selected row ID
    ///togglePanel();
    console.log("UMC ID", umcIndentId);
  };

  useEffect(() => {
    // Get all elements with class 'reqcon'
    var indcbutton = document.getElementsByClassName("reqcon");
    const indccon = true;
    for (let i = 0; i < indcbutton.length; i++) {
      if (indccon) {
        // Apply green background color if indccon is true
        indcbutton[i].style.backgroundColor = "green";
      } else {
        // Apply red background color if indccon is false
        indcbutton[i].style.backgroundColor = "red";
      }
    }
    //fetchCsrCategoryList();
  }, []);




  //--------------------------For 2nd section Tables--------------
  const [PurchaseGroup, setPurchaseGroup] = React.useState("");
  const [ProcurementType, setProcurementType] = React.useState("");
  const [RequirementDate, setRequirementDate] = React.useState("");
  const [StorageLocation, setStorageLocation] = React.useState("");
  const [scqty, Setscqty] = React.useState("");
  const [priceperitem, Setpriceperitem] = React.useState("");
  const [openimport, setOpenImport] = useState(true);
  const [UnderConsumption, setUnderConsumption] = React.useState("");
  const [CurrencyList, Setcurrencylist] = useState([]);
  const [CostCategoryList, Setcostcategorylist] = useState([]);
  const [DocumentsList, Setdocumentslist] = useState([]);
  const [panelData, setPanelData] = useState("");

  const [selectedItemId, setSelectedItemId] = useState(null);
  const [enablePanel, setEnablePanel] = useState(false);
  const [DocumentType, setDocumentType] = React.useState("");
  const [shoppingcartno, setShoppingCartNo] = React.useState("");
  const [shoppingcartname, SetShoppingCartName] = React.useState("");

  const handleInputChangePrice = (event) => {
    Setpriceperitem(event.target.value); // Update the state with input value
  };



  // const handleCheckboxChangeSC = (index) => {
  //   debugger;
  //   setSelectedRow(index);
  //   togglePanel();
  // };

  const handleCheckboxChangeforSelect = (id) => {
    //const handleCheckboxChangeSC = (index) => {
    debugger;
    setSelectedRow(id);
    //togglePanel();

    const updatedData = workFlowData.map((item) =>
      item.UMC_INDENT_ID === id
        ? { ...item, checked: true }
        : { ...item, checked: false }
    );
    console.log(workFlowData, 'workFlowData');
    setWorkFlowData(updatedData);

    const selectedCheckbox = updatedData.find(
      (item) => item.UMC_INDENT_ID === id
    );

    if (selectedItemId !== id) {
      // Only update state if a different checkbox is selected
      setSelectedItemId(id);
      setEnablePanel(true);
      setPanelData(selectedCheckbox.data);
      setDocumentType(selectedCheckbox.DOCUMENT_TYPE_DESC);
      setStorageLocation(selectedCheckbox.SLOC_DESC);
      setPurchaseGroup(selectedCheckbox.PG_DESC);
      setProcurementType(selectedCheckbox.PROC_TYPE);
      setRequirementDate(selectedCheckbox.REQUIREMENT_DATE);
      setShoppingCartNo(selectedCheckbox.SCH_CART_NO);
      setUnderConsumption(selectedCheckbox.SPARE);
      Setscqty(selectedCheckbox.QTY);
      Setpriceperitem(selectedCheckbox.PRICE_PER_ITEM);
    } else {
      // Deselect the checkbox if it was already selected
      setSelectedItemId(null);
      setEnablePanel(false);
      setPanelData("");
      setDocumentType("");
      setStorageLocation("");
      setPurchaseGroup("");
      setProcurementType("");
      setRequirementDate("");
      setShoppingCartNo("");
      setUnderConsumption("");
      Setscqty("");
    }
    // const filteredData = workFlowData.filter((item) => item.ISACTIVE === "Y");
    // const totalPage = Math.ceil(filteredData.length / itemsPerPage);
    // console.log(totalPage,'totalPage');
    // setCurrentPage(totalPage);
  };


  useEffect(() => {
    debugger;
    if (indentno != null) {
      hanldeSearchClick(indentno);
    }
    fetchCsrCategoryList();
    fetchCostCategoryList();
    fetchDocumentsList();
    fetchCurrencyList();
 
  }, []);


  //--------------------------------Cost Assigment-------------------------//
  const fetchCostCategoryList = async () => {
    try {
      const response = await axios.get(
        `${BaseUrl}api/ShoppingCart/GetCostCategory`
      );
      Setcostcategorylist(response.data.jsonData);
      console.log(response.data.jsonData, "GetCostCategory");
    } catch (error) {
      console.log(error, "GetCostCategory");
    }
  };
  // Function to delete row
  const deleteRow = (id) => {
    const updatedRows = rows.filter((row) => row.Line !== id);
    setRows(updatedRows);
  };
  //------------------------------------Documents---------------------------------//
  const fetchDocumentsList = async () => {
    try {
      const response = await axios.get(
        `${BaseUrl}api/ShoppingCart/GetDocumentsText`
      );
      Setdocumentslist(response.data.jsonData);
      console.log(response.data.jsonData, "fetchDocumentsList");
    } catch (error) {
      console.log(error, "fetchDocumentsList");
    }
  };
  //---------------------------------Sustainability-----------------------------//
  const fetchCsrCategoryList = async () => {
    try {
      const response = await axios.get(
        `${BaseUrl}api/ShoppingCart/GetCostCsrCategory`
      );
      Setcsrcategorylist(response.data.jsonData);
      console.log(response.data.jsonData, "Setcsrsubcategorylist");
    } catch (error) {
      console.log(error, "fetchCsrCategoryList");
    }
  };
  const fetchCsrSubCategoryList = async () => {
    try {
      const response = await axios.get(
        `${BaseUrl}api/ShoppingCart/GetCostCsrSubCategory`
      );
      Setcsrsubcategorylist(response.data.jsonData);
    } catch (error) {
      console.log(error, "GetCostCsrSubCategory");
    }
  };

  const fetchCurrencyList = async () => {
    try {
      const response = await axios.get(
        `${BaseUrl}api/ShoppingCart/GetCurrencyCode`
      );
      Setcurrencylist(response.data.jsonData);
      console.log(response.data.jsonData, "GetCurrencyCode");
    } catch (error) {
      console.log(error, "GetCurrencyCode");
    }
  };

  const fetchCsrSubActivityList = async (CSR_SUB_CODE) => {
    try {
      const response = await axios.get(
        `${BaseUrl}api/ShoppingCart/GetCostCsrSubActivity?CSR_SUB_CODE=${CSR_SUB_CODE}`
      );
      Setcsrsubactivitylist(response.data.jsonData);
      console.log(response.data.jsonData, "fetchCsrSubActivityList");
    } catch (error) {
      console.log(error, "GetCostCsrSubActivity");
    }
  };

  const isChecked = (value) => selectedOptions.includes(value);
  const handleCheckboxChange = (value) => {
    debugger;
    console.log(value, "None");
    if (value == "01") {
      fetchCsrSubCategoryList();
      isChecked(true);
    } else {
      Setcsrsubcategorylist([]);
      Setcsrsubactivitylist([]);
    }
    // if (value === "all") {
    //   // console.log("None");
    //   // setSelectedOptions([]);

    //   // Setcsrsubcategorylist([]);
    //   // Setcsrsubactivitylist([]);
    //   if (selectedOptions.length === CsrCategoryList.length) {
    //     setSelectedOptions([]);
    //   } else {
    //     setSelectedOptions(CsrCategoryList.map((option) => option.VALUE));
    //   }
    // } else {
    //   if (selectedOptions.includes(value)) {
    //     setSelectedOptions(
    //       selectedOptions.filter((option) => option !== value)
    //     );
    //   } else {
    //     setSelectedOptions([...selectedOptions, value]);
    //   }
    //   //fetchCsrSubCategoryList();
    // }
  };
  const handleRadioChange = (value) => {
    setSelectedOption(value);
    fetchCsrSubActivityList(value);
  };
  const handleSubActivityRadioChange = (value) => {
    setSubActivitySelectedOption(value);
  };

  // Function to handle input changes

  const handleInputChange = (id, field, value) => {
    const updatedRows = rows.map((row) => {
      if (row.Line === id) {
        return { ...row, [field]: value };
      }
      return row;
    });
    console.log(updatedRows);
    setRows(updatedRows);
  };




  //--------------------------End For 2nd section Tables--------------



  //---------------------Save As Draft-------------------------------
  const handleSaveAsDraft = async () => {
    //  setisLoading(true);
    // prop.showLoader();
    var formDetails = {
      ObjIntelliBuyChecksHeader: {
        INDENT_ID: indentno,
        INDENTER_LOC: workFlowData[0].INDENTER_LOC,
        INDENTOR_PLANT: workFlowData[0].INDENTOR_PLANT,
        INDENTER_DEPT: workFlowData[0].INDENTER_DEPT,
        INDENT_DESC: workFlowData[0].INDENT_DESC,
        INDENT_REMARKS: workFlowData[0].INDENT_REMARKS,
        INDENT_CRT_BY: workFlowData[0].INDENT_CRT_BY,
        INDENT_MOD_BY: workFlowData[0].INDENT_MOD_BY,
        INDENT_STATUS: "25",
        SCH_CART_NO: "",
        SCH_CRT_DT: "",
        SCH_USR_NAME: "",
        ISACTIVE: "Y",
      },
      ObjIntelliBuyIndentDetails: workFlowData,
      IsDraft: "Y",
    };
    ////console.log("wfdata", workFlowData);
    try {
      axios
        .post(
          `${BaseUrl}api/IntelliBuyChecks/InsertIntelliBuyCheckItem`,
          formDetails
        )

        .then((response) => {
          if (response.statusText === "OK") {
            // fetchSavedDraftData();
            setisLoading(false);
            prop.hideLoader();
            //Swal.fire("", "Items Saved Successfully", "success");
            sessionStorage.setItem('INDENT_ID', indentno);
            navigate('/SIS/ShoppingCart');// Redirect to new page
          } else {
            prop.hideLoader();
          }
        });
    } catch (error) {
      prop.hideLoader();
      setisLoading(false);
    }
  };
  //====================Start Upload Approver file doc=================
  const [modal, setModal] = useState(false);
  const [file, setFile] = useState(null);

  const toggle = () => setModal(!modal);

  const handleFileChange = (e) => {
    setFile(e.target.files[0]);
  };

  const handleUpload = () => {
    const formData = new FormData();
    formData.append('file', file);
    formData.append('Sno', '1001101558'); // Example Sno
    formData.append('UserId', 'TSM911459'); // Example userId

    axios.post(`${BaseUrl}api/ShoppingCart/SCApproverFileUpload`, formData)
      .then(response => {
        console.log(response.data);
        toggle();
      })
      .catch(error => {
        console.error('There was an error uploading the file!', error);
      });
  };


  //==================Start Upload Approver file doc===============

  return (
    <div>
      {/* <Navbar />
      <TabMenu prop={"IntelliBuySystemChecks"} /> */}
      {!state ? (
        <>
          <div
            className="container"
            style={{ marginTop: "8px", marginLeft: "2px", maxWidth: "100%" }}
          >
            <div className="card">
              <div className="card-body" style={{ maxWidth: "100%" }}>
                <div className="row">

                  <div className="col-md-2">
                    <label style={{
                      textAlign: "center",
                      fontSize: "20px",
                      fontWeight: "bold",
                      color: "black",
                    }}> Indent Number:</label>
                  </div>
                  <div className="col-md-2">
                    <input
                      id="indentno"
                      name="indentno"
                      value={indentno}
                      onChange={(e) => setIndentNo(e.target.value)}
                      className="form-control"
                      type="text"
                    />
                  </div>
                  <div className="col-md-1">
                    <button
                      onClick={() => hanldeSearchClick(indentno)}
                      className=" btn btn-warning"
                      style={{ fontSize: "13px" }}
                    >
                      <i class="fas fa-filter"></i>
                      Search
                    </button>
                  </div>

                  <div className="col-md-3">
                    <label
                      style={{
                        textAlign: "center",
                        fontSize: "20px",
                        fontWeight: "bold",
                        color: "black",
                      }}
                    >
                      {" "}
                      Department:
                    </label>
                    <label
                      style={{
                        textAlign: "center",
                        fontSize: "20px",
                        fontWeight: "bold",
                        color: "red",
                        marginLeft: "10px",
                      }}
                    >
                      {" "}
                      {indentdept}
                    </label>
                  </div>

                  <div className="col-md-4">
                    <label
                      style={{
                        textAlign: "center",
                        fontSize: "20px",
                        fontWeight: "bold",
                        color: "black",
                      }}
                    >
                      {" "}
                      Status:
                    </label>
                    <label
                      style={{
                        textAlign: "center",
                        fontSize: "20px",
                        fontWeight: "bold",
                        color: "red",
                        marginLeft: "10px",
                      }}
                    >
                      {indentstatus}
                    </label>
                  </div>

                </div>


                <br />
                <div className="row">
                  <div className="col-md-2">
                    <label
                      style={{
                        textAlign: "center",
                        fontSize: "20px",
                        fontWeight: "bold",
                        color: "black",
                      }}> Shopping Cart No. :</label>
                  </div>
                  <div className="col-md-3">
                    {shoppingcartno}
                  </div>

                  <div className="col-md-1">
                    &nbsp;
                  </div>
                  <div className="col-md-2">
                  &nbsp;
                  </div>


                  <div className="col-md-1">
                    <label
                      style={{
                        textAlign: "center",
                        fontSize: "20px",
                        fontWeight: "bold",
                        color: "black",
                      }}> Filter :</label>
                  </div>
                  <div className="col-md-3">

                    <input
                      type="text"
                      value={filterText}
                      onChange={handleFilterChange}
                      className="form-control"
                      placeholder="Enter search text"
                    />
                  </div>
                </div>
                <br></br>
                <div className="row" style={{ overflowX: "auto" }}>
                  <div className="tables table-responsive table-responsive-sm">
                    <table className="table table-bordered tb">
                      <thead className="table-primary">
                        <tr>
                          <th> Action</th>
                          <th> Sl No</th>
                          <th> UMC No</th>
                          <th> Description </th>
                          <th> BGG</th>
                          {/* <th> Nature of SKU</th> */}
                          <th> Refurbishable</th>
                          {/* <th> Proprietry</th> */}
                          <th style={{ whiteSpace: "nowrap" }}> Required On</th>
                          <th> UOM</th>
                          <th>Ident Qty</th>
                          <th> SC Qty</th>
                          {/* <th> Rate Per Item</th>
                        <th> Price</th>
                        <th> Plant</th> */}
                          <th> Max Qty</th>
                          <th style={{ whiteSpace: "normal" }}>
                            {" "}
                            Requirement / Consumption
                          </th>
                          <th> VMI/ARC </th>
                          <th> Refurshibility</th>
                          <th> Deprop</th>

                          <th> </th>
                        </tr>
                      </thead>

                      <tbody>
                        {" "}
                        {currentData.map((row, index) => (
                          <tr
                            key={row.UMC_INDENT_ID}
                            style={{
                              backgroundColor:
                                selectedRow === row.UMC_INDENT_ID
                                  ? "#ddd"
                                  : "white",
                            }}
                          >
                            <td>
                              {/* <input
                                type="checkbox"
                                onChange={() => handleCheckboxChangeSC(index)}
                                checked={selectedRow === index}
                              /> */}

                              <Link
                                href=""
                                onClick={() => handleCheckboxChangeforSelect(row.UMC_INDENT_ID)}


                                className="btn btn-info"
                              >
                                View{" "}
                              </Link>{" "}

                            </td>
                            <td style={{ display: "none" }}>
                              {row.UMC_INDENT_ID}
                            </td>
                            <td>{row.SRNO}</td>
                            <td>{row.REQ_UMC_NO}</td>
                            <td>{row.REQ_UMC_DESC}</td>
                            <td>{row.REQ_UMC_BGG}</td>
                            {/* <td></td> */}
                            <td>
                              {row.IS_REFURBISHABLE === "R"
                                ? "Refurbishable"
                                : row.IS_REFURBISHABLE === "N"
                                  ? "Non Refurbishable"
                                  : row.IS_REFURBISHABLE}
                            </td>
                            {/* <td></td> */}
                            <td>{row.REQUIREMENT_DATE}</td>
                            <td>{row.UOM}</td>
                            <td>{row.QTY}</td>
                            <td>{row.QTY - row.TOTAL_SAP_DOC_QTY}</td>
                            {/* <td>{row.PRICE_PER_ITEM}</td>
                          <td>{calculatePrice(row.PRICE_PER_ITEM, row.QTY)}</td>
                          <td>{row.INDENTOR_PLANT}</td> */}
                            <td>
                              <button
                                href=""
                                onClick={() => hanldeClick(row)}
                                className="btn"
                                style={{
                                  // backgroundColor: true === true ? "green" : "red",
                                  backgroundColor:
                                    row.QTY > parseInt(row.ALLOWEDQTY)
                                      ? "red"
                                      : "green",
                                  width: "70px",
                                  fontSize: "13px",
                                  color: "white",
                                }}
                              >
                                {row.QTY > parseInt(row.ALLOWEDQTY)
                                  ? "Fail"
                                  : "Passed"}
                              </button>
                            </td>
                            <td>
                              <div>
                                <button
                                  href=""
                                  onClick={() => hanldeRCMClick(row)}
                                  className="btn"
                                  style={{
                                    backgroundColor:
                                      true === true ? "green" : "red",
                                    width: "70px",
                                    fontSize: "13px",
                                    color: "white",
                                  }}
                                >
                                  {" "}
                                  Passed
                                </button>
                              </div>
                            </td>
                            <td>
                              <div>
                                <button
                                  href=""
                                  onClick={() => hanldeVMIClick(row)}
                                  className="btn"
                                  style={{
                                    backgroundColor:
                                      row.ARC_VMI === "FALSE" ? "green" : "red",
                                    width: "70px",
                                    fontSize: "13px",
                                    color: "white",
                                  }}
                                >
                                  {" "}
                                  Passed
                                </button>
                              </div>
                            </td>
                            <td>
                              <div>
                                <button
                                  href=""
                                  onClick={() => hanlderefurshibilityClick(row)}
                                  className="btn"
                                  style={{
                                    backgroundColor:
                                      row.IS_REFURBISHABLE === "R"
                                        ? "green"
                                        : "red",
                                    width: "70px",
                                    fontSize: "13px",
                                    color: "white",
                                  }}
                                >
                                  {" "}
                                  {row.IS_REFURBISHABLE === "R"
                                    ? "Passed"
                                    : "Fail"}
                                </button>
                              </div>
                            </td>
                            <td>
                              <div>
                                <button
                                  href=""
                                  onClick={() => hanldeDepropClick(row)}
                                  className="btn"
                                  style={{
                                    backgroundColor:
                                      row.DOCUMENT_TYPE === "NA"
                                        ? "green"
                                        : "red",
                                    width: "70px",
                                    fontSize: "13px",
                                    color: "white",
                                  }}
                                >
                                  {" "}
                                  {row.DOCUMENT_TYPE === "NA"
                                    ? "Passed"
                                    : "Fail"}
                                </button>
                              </div>
                            </td>
                            <td>
                              <button
                                onClick={() => {
                                  handleDeleteRow(row.UMC_INDENT_ID);
                                }}
                                style={{
                                  width: "25px",
                                  height: "25px",
                                  padding: "0px",
                                }}
                                class="btn btn-danger btn-sm"
                                type="button"
                                data-toggle="tooltip"
                                data-placement="top"
                                title="Delete"
                              >
                                <i class="fa fa-trash"></i>
                              </button>
                            </td>
                          </tr>
                        ))}{" "}
                      </tbody>
                    </table>
                  </div>
                </div>
                <div className="row mt-2">
                  <div className="col-10"></div>
                  <div className="col-2">
                    <div className="pagination">
                      {Array.from({ length: totalPages }, (_, index) => (
                        <button
                          key={index}
                          onClick={() => handlePageChange(index + 1)}
                          className={`page-link ${currentPage === index + 1 ? "active" : ""
                            }`}
                        >
                          {index + 1}
                        </button>
                      ))}
                    </div>
                  </div>
                </div>

                <div className="row mt-3">
                  <div className="col-8"></div>
                  <div className="col-2 d-flex justify-content-end">
                    <button
                      type="button"
                      className="btn btn-primary"
                      onClick={() => handleSaveAsDraft()}
                      style={{ visibility: "hidden" }}
                    >
                      Create Shopping Cart
                    </button>
                  </div>

                  <div className="col-2 d-flex justify-content-start">
                    {/* <button type="button" className="btn btn-success">
                      Raise Shopping Cart
                    </button> */}
                  </div>
                </div>
                {show && (
                  <MaxQtyModal
                    updateQtyData={workFlowData}
                    handleClose={hideModal}
                    handleCellChange={hanldeEdit}
                    OnDeleteRow={hanldeDelete}
                  />
                )}
                {showrcm && (
                  <RequirmentConsumptionModal
                    requirmentConsumptionData={workFlowData}
                    handleClose={hideRCMModal}
                    handleCellChange={hanldeRCMEdit}
                    OnDeleteRow={hanldeDelete}
                  />
                )}
                {showrefurshibility && (
                  <RefurshibilityModal
                    requirmentConsumptionData={workFlowData}
                    handleClose={hiderefurshibilityModal}
                    OnDeleteRow={hanldeDelete}
                  />
                )}
                {showvmi && (
                  <VMIModal
                    VMIData={workFlowData}
                    handleClose={hideVMIModal}
                    OnDeleteRow={hanldeDelete}
                  />
                )}
                {showdeprop && (
                  <DepropModal
                    DepropData={workFlowData}
                    handleClose={hideDepropModal}
                    OnDeleteRow={hanldeDelete}
                  />
                )}
              </div>
            </div>

            <div style={{ border: "" }}>


              <div className="card mt-3" style={{ maxWidth: "100%" }}>
                <div
                  className="card-heading" onClick={togglePanel}
                  style={{ backgroundColor: "#0d6efd", height: "34px" }}
                >
                  <h6 className="mt-2" style={{ color: "white" }}>

                    &nbsp;   {open ? <i className="fa fa-minus text-blue"></i> : <i className="fa fa-plus text-blue"></i>}
                    &nbsp;   Indent Item Details
                  </h6>
                </div>

                <Collapse in={open}>
                  <div className="card-body">
                    {/* ----------Start Nav Tab---------- */}
                    <div className="col-12">
                      <Tabs
                        defaultActiveKey="SSA"
                        id="uncontrolled-tab-example"
                        className="my-tab position-relative"
                      >
                        <Tab
                          eventKey="SSA"
                          title={
                            <div style={{ padding: "0px 80px 0px 80px" }}>
                              Basic Data
                            </div>
                          }
                          className="act-clr"
                        >
                          <br />
                          <div className="row">
                            <div className="col-6">
                              <div class="row">
                                <div class="col-md-6">
                                  <label className="form-label label-font">
                                    Storage location
                                  </label>
                                </div>
                                <div class="col-md-6">
                                  <label className="form-label label-font">
                                    {StorageLocation}{" "}
                                  </label>
                                </div>
                              </div>

                              <div class="row">
                                <div class="col-md-6">
                                  <label className="form-label label-font">
                                    Document type
                                  </label>
                                </div>
                                <div class="col-md-6">
                                  <label className="form-label label-font">
                                    {DocumentType}{" "}
                                  </label>
                                </div>
                              </div>
                              <div class="row">
                                <div class="col-md-6">
                                  <label className="form-label label-font">
                                    Purchase Group
                                  </label>
                                </div>
                                <div class="col-md-6">
                                  <label className="form-label label-font">
                                    {" "}
                                    {PurchaseGroup}
                                  </label>
                                </div>
                              </div>
                              <div class="row mt-1">
                                <div class="col-md-6">
                                  <label className="form-label label-font">
                                    Shopping Cart Qty
                                  </label>
                                </div>
                                <div class="col-md-3">
                                  <label className="form-label label-font">
                                    {scqty}
                                  </label>
                                  <label className="form-label label-font">
                                    {" "}  NO
                                  </label>
                                </div>

                              </div>

                              <div class="row mt-1">
                                <div class="col-md-6">
                                  <label className="form-label label-font">
                                    Unit price of the item
                                  </label>
                                </div>
                                <div class="col-md-6">
                                  <input
                                    className="form-control form-control-sm"
                                    value={priceperitem} // Bind input value to state variable
                                    onChange={handleInputChangePrice} // Handle input change
                                  ></input>
                                </div>

                              </div>

                              {/* <div class="row">
                              <div class="col-md-6">
                                <label className="form-label label-font">
                                  Required qty.
                                </label>
                              </div>
                              <div class="col-md-6">
                                <label className="form-label label-font"> </label>
                              </div>
                            </div> */}

                              {/* <div class="row mt-1">
                                  <div class="col-md-6">
                                    <label className="form-label label-font">
                                      Refurbish Spare Qty
                                    </label>
                                  </div>
                                  <div class="col-md-6">
                                    <input className="form-control form-control-sm"></input>
                                  </div>
                                </div> */}
                              <div
                                class="row mt-1"
                                style={{ display: openimport }}
                              >
                                <div class="col-md-6">
                                  <label className="form-label label-font">
                                    Material Consumption Plan
                                  </label>
                                </div>
                                <div class="col-md-6">
                                  <select
                                    name="category"
                                    id="category"
                                    className="form-control form-control-sm"
                                    type="text"
                                  >
                                    <option> --Select-- </option>
                                    <option Value="MTRCL">
                                      Material consumtion within 33 month of
                                      Import{" "}
                                    </option>
                                    <option Value="0"> Other</option>
                                  </select>
                                </div>
                              </div>
                            </div>
                            <div className="col-6">
                              <div class="row">
                                <div class="col-md-6">
                                  <label className="form-label label-font">
                                    Procurement Type
                                  </label>
                                </div>
                                <div class="col-md-6">
                                  <label className="form-label label-font">
                                    {ProcurementType}
                                  </label>
                                </div>
                              </div>
                              <div class="row">
                                <div class="col-md-6">
                                  <label className="form-label label-font">
                                    Spare Categorization
                                  </label>
                                </div>
                                <div class="col-md-6">
                                  <label className="form-label label-font">
                                    {UnderConsumption}
                                  </label>
                                </div>
                              </div>

                              <div class="row mt-1">
                                <div class="col-md-6">
                                  <label className="form-label label-font">
                                    Requirement Date
                                  </label>
                                </div>
                                <div class="col-md-6">
                                  <label className="form-label label-font">
                                    {RequirementDate}
                                  </label>
                                </div>
                              </div>
                              <div class="row mt-1">
                                <div class="col-md-6">
                                  <label className="form-label label-font">
                                    Installed Qty
                                  </label>
                                </div>
                                <div class="col-md-6">
                                  <input className="form-control form-control-sm"></input>
                                </div>
                              </div>

                              <div class="row mt-1">
                                <div class="col-md-6">
                                  <label className="form-label label-font">
                                    Celling Price
                                  </label>
                                </div>
                                <div class="col-md-2">
                                  <input className="form-control form-control-sm"></input>
                                </div>
                                <div class="col-md-1">
                                  <label className="form-label label-font">
                                    Currency
                                  </label>
                                </div>
                                <div class="col-md-2 d-flex justify-content-end">
                                  <select
                                    name="category"
                                    id="category"
                                    className="form-control form-control-sm"
                                    type="text"
                                  >
                                    <option>Select</option>
                                    <option value="INR"> INR </option>
                                    {CurrencyList.map((jsonData, id) => (
                                      <option key={id} value={jsonData.FCURR}>
                                        {jsonData.FCURR}
                                      </option>
                                    ))}
                                  </select>
                                </div>
                              </div>

                              <div
                                class="row mt-1"
                                style={{ display: openimport }}
                              >
                                <div class="col-md-6">
                                  <label className="form-label label-font">
                                    Imported Plant And Machineary
                                  </label>
                                </div>
                                <div class="col-md-6">
                                  <select
                                    name="category"
                                    id="category"
                                    className="form-control form-control-sm"
                                    type="text"
                                  >
                                    <option> --Select-- </option>
                                    <option Value="Y">Yes</option>
                                    <option Value="N">No</option>
                                  </select>
                                </div>
                              </div>
                            </div>
                          </div>


                        </Tab>
                        <Tab
                          eventKey="CRA"
                          title={
                            <div style={{ padding: "0px 80px 0px 80px" }}>
                              Cost Assignment
                            </div>
                          }
                          className="tab-txt-clr act-clr"
                        >
                          <div>
                            <label
                              style={{ fontSize: "16px", fontWeight: "bold" }}
                            >
                              You can see who bears the costs and, if
                              necessary, you can distribute the costs to
                              several cost centers.
                            </label>
                            <div className="row mt-3">
                              <div className="col-2">
                                <label>Category</label>
                              </div>
                              <div className="col-3">
                                <select
                                  name="category"
                                  id="category"
                                  className="form-control form-control-sm"
                                  type="text"
                                >
                                  <option> --Select-- </option>
                                  {CostCategoryList.map((jsonData, id) => (
                                    <option
                                      key={id}
                                      value={jsonData.CostCategoryList}
                                    >
                                      {jsonData.ACCT_ASGNMT_DESC}
                                    </option>
                                  ))}
                                </select>
                              </div>
                              <div className="col-2">
                                <label>Cost Distribution</label>
                              </div>
                              <div className="col-3">
                                <select className="form-control form-control-sm">
                                  <option> --Select-- </option>
                                  <option>Percentage </option>
                                  <option> Quantity </option>
                                  <option VALUE="V"> Value </option>
                                </select>
                              </div>
                            </div>
                            <button
                              className="btn btn-primary mb-3"
                              onClick={addRow}
                            >
                              Add New Row
                            </button>
                            <div className="tables table-responsive">
                              <table className="table table-bordered">
                                <thead>
                                  <tr>
                                    <th>Line</th>
                                    <th>Percentage</th>
                                    <th>Assigned To</th>
                                    <th>Delete</th>
                                  </tr>
                                </thead>
                                <tbody>
                                  {rows.map((row, index) => (
                                    <tr key={row.id}>
                                      <td>{index + 1}</td>
                                      <td>
                                        <input
                                          type="text"
                                          className="form-control form-control sm"
                                          value={row.Percentage}
                                          onChange={(e) =>
                                            handleInputChange(
                                              row.Line,
                                              "Percentage",
                                              e.target.value
                                            )
                                          }
                                        />
                                      </td>
                                      <td>
                                        <input
                                          type="text"
                                          className="form-control form-control sm"
                                          value={row.Assigned}
                                          onChange={(e) =>
                                            handleInputChange(
                                              row.Line,
                                              "Assigned",
                                              e.target.value
                                            )
                                          }
                                        />
                                      </td>
                                      <td>
                                        <button
                                          onClick={() => {
                                            deleteRow(row.Line);
                                          }}
                                          style={{
                                            width: "25px",
                                            height: "25px",
                                            padding: "0px",
                                          }}
                                          class="btn btn-danger btn-sm"
                                          type="button"
                                          data-toggle="tooltip"
                                          data-placement="top"
                                          title="Delete"
                                        >
                                          <i class="fa fa-trash"></i>
                                        </button>
                                      </td>
                                    </tr>
                                  ))}
                                </tbody>
                              </table>
                            </div>
                          </div>
                          <p style={{ float: "right" }}>

                          </p>
                        </Tab>
                        <Tab
                          eventKey="IBCA"
                          title={
                            <div style={{ padding: "0px 80px 0px 80px" }}>
                              Documents
                            </div>
                          }
                          className="tab-txt-clr act-clr"
                        >
                          <div>
                            <div className="row mt-3">
                              <div className="col-3">
                                <select
                                  name="category"
                                  id="category"
                                  className="form-control form-control-sm"
                                  type="text"
                                >
                                  <option> --Select-- </option>
                                  {DocumentsList.map((jsonData, id) => (
                                    <option key={id} value={jsonData.TEXT_ID}>
                                      {jsonData.TXT_DESC}
                                    </option>
                                  ))}
                                </select>
                              </div>
                              <div className="col-5">
                                <textarea
                                  className="form-control form-control sm"
                                  rows={4}
                                  cols={40}
                                />
                              </div>
                            </div>

                          </div>
                        </Tab>
                        <Tab
                          eventKey="SCA"
                          title={
                            <div style={{ padding: "0px 80px 0px 80px" }}>
                              Sustainibility
                            </div>
                          }
                          className="tab-txt-clr act-clr"
                        >
                          <div className="row">
                            <div className="col-4">
                              <Form>
                                <Form.Check type="checkbox" />
                                {CsrCategoryList.map((option) => (
                                  <Form.Check
                                    key={option.VALUE}
                                    type="checkbox"
                                    label={option.LABEL}
                                    onChange={() =>
                                      handleCheckboxChange(option.VALUE)
                                    }
                                  //checked={isChecked(option.VALUE)}
                                  />
                                ))}
                              </Form>
                              <p>
                                {selectedOptions.length} /{" "}
                                {CsrCategoryList.length} selected
                              </p>
                            </div>
                            <div className="col-4">
                              <Form>
                                {CsrSubCategoryList.map((option, index) => (
                                  <Form.Check
                                    key={index}
                                    type="radio"
                                    label={option.LABEL}
                                    name="radioGroup"
                                    value={option.VALUE}
                                    checked={selectedOption === option.VALUE}
                                    onChange={() =>
                                      handleRadioChange(option.VALUE)
                                    }
                                  />
                                ))}
                              </Form>
                              <p>Selected option: {selectedOption}</p>
                            </div>
                            <div className="col-4">
                              <Form>
                                {CsrSubActivityList.map((option, index) => (
                                  <Form.Check
                                    key={index}
                                    type="radio"
                                    label={option.LABEL}
                                    name="radioGroupAct"
                                    value={option.VALUE}
                                    checked={
                                      subactivityselectedOption ===
                                      option.VALUE
                                    }
                                    onChange={() =>
                                      handleSubActivityRadioChange(
                                        option.VALUE
                                      )
                                    }
                                  />
                                ))}
                              </Form>
                              <p>
                                Selected option: {subactivityselectedOption}
                              </p>
                            </div>
                          </div>
                        </Tab>
                        {openimport && (
                          <Tab
                            eventKey="CLA"
                            title={
                              <div style={{ padding: "0px 80px 0px 80px" }}>
                                Classification
                              </div>
                            }
                            className="tab-txt-clr act-clr"
                          >
                            <div>
                              <div className="row mt-2">
                                <div className="col-3">
                                  <label className="form-label label-font d-flex justify-content-end">
                                    HSN No.
                                  </label>
                                </div>
                                <div className="col-6">
                                  <input className="form-control"></input>
                                </div>
                              </div>
                              <div className="row mt-2">
                                <div className="col-3">
                                  <label className="form-label label-font d-flex justify-content-end">
                                    Characteristics
                                  </label>
                                </div>
                                <div className="col-6">
                                  <textarea
                                    className="form-control form-control-sm"
                                    style={{ width: "400", height: "100px" }}
                                    placeholder="Characteristics"
                                  ></textarea>
                                </div>
                              </div>
                              <div className="row mt-2">
                                <div className="col-3">
                                  <label className="form-label label-font d-flex justify-content-end">
                                    Composition
                                  </label>
                                </div>
                                <div className="col-6">
                                  <textarea
                                    className="form-control form-control-sm"
                                    style={{ width: "400", height: "100px" }}
                                    placeholder="Composition"
                                  ></textarea>
                                </div>
                              </div>
                              <div className="row mt-2">
                                <div className="col-3">
                                  <label className="form-label label-font d-flex justify-content-end">
                                    End use :
                                  </label>
                                </div>
                                <div className="col-6">
                                  <textarea
                                    className="form-control form-control-sm"
                                    style={{ width: "400", height: "100px" }}
                                    placeholder="   End use :	"
                                  ></textarea>
                                </div>
                              </div>
                              <div className="row mt-2">
                                <div className="col-3">
                                  <label className="form-label label-font d-flex justify-content-end">
                                    Function
                                  </label>
                                </div>
                                <div className="col-6">
                                  <textarea
                                    className="form-control form-control-sm"
                                    style={{ width: "400", height: "100px" }}
                                    placeholder="Function"
                                  ></textarea>
                                </div>
                              </div>
                            </div>
                          </Tab>
                        )}
                      </Tabs>
                    </div>
                    {/*----End Nav Tab-----*/}
                  </div>
                </Collapse>

              </div>

            </div>

            {/*----Start Approver Section-----*/}
            <div className="card mt-3" style={{ maxWidth: "100%" }}>
              <div className="card-heading" style={{ backgroundColor: "#0d6efd", height: "34px" }}>
                <h6 className="mt-2" style={{ color: "white" }}>

                  &nbsp;&nbsp;<i className="fas fa-copy text-white"></i>
                  &nbsp;Approver Section
                </h6>
              </div>
              <div className="card-body">
                <div className="col-6">
                  <div class="row mt-1">
                    <div class="col-md-6">
                      <label className="form-label label-font">
                        Name of the Shopping Cart
                      </label>
                    </div>
                    <div class="col-md-6">
                      <input value={shoppingcartname} className="form-control form-control-sm"></input>
                    </div>
                  </div>

                  <div class="row mt-2">
                    <div class="col-md-6">
                      <label className="form-label label-font">
                        Approver's Remarks
                      </label>
                    </div>
                    <div class="col-md-6">
                      <textarea
                        value={app_remarks}
                        className="form-control form-control-sm" style={{ width: "400", height: "100px" }} onChange={handleRemarksChange} placeholder="Max 1000 Characters"></textarea>
                    </div>
                  </div>
                  <div class="row mt-2">
                    <div class="col-md-6">

                    </div>
                    <div class="col-md-6">
                      <div className="App">
                        <Button color="link" onClick={toggle}>Click to attach document</Button><br />
                        <span style={{ color: "Red", fontSize: "12px" }}>Only .pdf, .jpg, .jpeg, .gif, .bmp, .png</span>

                        <Modal isOpen={modal} toggle={toggle}>
                          <ModalHeader toggle={toggle}>Upload Document</ModalHeader>
                          <ModalBody>
                            <Form>
                              <FormGroup>
                                <Label for="fileUpload"> Select File to Upload</Label>
                                <Input type="file" name="file" id="fileUpload" accept="pdf, .jpg, .jpeg, .gif, .bmp, .png" onChange={handleFileChange} />
                              </FormGroup>
                            </Form>
                          </ModalBody>
                          <ModalFooter>
                            <Button color="primary" onClick={handleUpload}>Upload</Button>
                            <Button color="secondary" onClick={toggle}>Cancel</Button>
                          </ModalFooter>
                        </Modal>
                      </div>
                    </div>
                  </div>




                  <div class="row mt-2"></div>
                  <div class="row mt-2">
                    <div class="col-md-2">
                      <label>
                        <input
                          type="radio"
                          value="1"
                          checked={selectedOptionRd === '1'}
                          onChange={handleOptionChange}
                        />
                        Approval
                      </label>
                    </div>
                    <div class="col-md-2">
                      <label>
                        <input
                          type="radio"
                          value="0"
                          checked={selectedOptionRd === '0'}
                          onChange={handleOptionChange}
                        />
                        Reject
                      </label>
                    </div>

                    <div class="col-md-2">
                      <label>
                        <input
                          type="radio"
                          value="2"
                          checked={selectedOptionRd === '2'}
                          onChange={handleOptionChange}
                        />
                        Return
                      </label>
                    </div>
                    <div class="col-md-2">
                      <button type="submit" onClick={handleSubmit} className="btn btn-primary">Submit</button>
                    </div>
                  </div>


                </div>
                <div class="row mt-1">
                  <div class="col-md-12">
                    <p style={{ float: "right" }}><button type="submit" className="btn btn-danger" style={{ height: "25px", paddingTop: "0px" }}>Ask Question?</button></p>
                  </div>
                </div>
              </div>
            </div>
            {/*----End Approver Section-----*/}


          </div>
        </>
      ) : (
        <ApprovalScreen />
      )}
    </div>
  );
};
export default PendingForApproval;
