import React, { useState, useEffect } from "react";
import Navbar from "../components/Navbar/Navbar";
import ApprovalScreen from "./ApprovalScreen";
import { BaseUrl, LocalUrl } from "../constants/BaseURL";
import { useSelector } from "react-redux";
import "./IntelliBuySystemChecks.css";
import MaxQtyModal from "../components/IntelliBuy/MaxQtyModal";
import RequirmentConsumptionModal from "../components/IntelliBuy/RequirmentConsumptionModal";
import RefurshibilityModal from "../components/IntelliBuy/RefurshibilityModal";
import VMIModal from "../components/IntelliBuy/VMIModal";
import DepropModal from "../components/IntelliBuy/DepropModal";
import ProgressBar from "../components/IntelliBuy/ProgressBar";
import axios from "axios";
import TabMenu from "../components/TabMenu/TabMenu";
import Swal from "sweetalert2";
import * as moment from "moment";
import { useNavigate } from "react-router-dom";
const IntelliBuyWorkflow = ({
  showLoader,
  hideLoader,
  switchToShoppingCart,
}) => {
  const navigate = useNavigate();
  const indentId = useSelector((state) =>
    state.indent ? state.indent.indentId : ""
  );
  const [state, setstate] = useState(false);
  const [workFlowData, setWorkFlowData] = useState([]);
  const [indentno, setIndentNo] = React.useState(indentId);
  const [indentstatus, setIndentStatus] = React.useState("");
  const [indentdept, setIndentDept] = React.useState("");
  const [isLoading, setisLoading] = useState(true);
  const [show, setShow] = useState(false);
  const [showrcm, setShowRCM] = useState(false);
  const [showrefurshibility, setShowRefurshibility] = useState(false);
  const [showvmi, setShowVMI] = useState(false);
  const [showdeprop, setShowDeprop] = useState(false);
  const [filterText, setFilterText] = useState("");
  const [currentPage, setCurrentPage] = useState(1);
  const [selectedRow, setSelectedRow] = useState(null);
  const [RCMstatus, setRCMStatus] = useState("");
  const [VMIstatus, setVMIStatus] = useState({});
  const [selectedDatercmdt, setSelectedDateRCMDate] = useState('');
  //const INDENT_ID = sessionStorage.getItem("INDENT_ID");
  const [progress, setProgress] = useState(80);
  const itemsPerPage = 5;

  ///-------------MaxQty Modal---------//
  const MaxQtyStatus = workFlowData.some((item) => item.QTY > item.ALLOWEDQTY);
  const hanldeDelete = (rowno) => {
    const newData = workFlowData.map((item) =>
      item.UMC_INDENT_ID === rowno ? { ...item, ISACTIVE: "N" } : item
    );
    setWorkFlowData(newData);
    const filteredData = newData.filter((item) => item.ISACTIVE === "Y");
    const totalPage = Math.ceil(filteredData.length / itemsPerPage);
    setCurrentPage(totalPage);
  };

  const getUpdateQty = () => {
    setWorkFlowData(workFlowData);
  };
  const hanldeClick = (selectedRec) => {
    getUpdateQty();
    setShow(true);
  };

  const hideModal = () => {
    setShow(false);
  };

  ///-------------Refurshibility Modal---------//

  const hanlderefurshibilityClick = (selectedRec) => {
    getrefurshibility();
    setShowRefurshibility(true);
  };

  const hiderefurshibilityModal = () => {
    setShowRefurshibility(false);
  };

  const getrefurshibility = () => {
    setWorkFlowData(workFlowData);
  };

  ///-------------RequirmentConsumption Modal---------//
  // Function to format date as dd-mm-yyyy
  const formatDate = (dateString) => {
    const dateObj = new Date(dateString);
    const day = String(dateObj.getDate()).padStart(2, '0');
    const month = String(dateObj.getMonth() + 1).padStart(2, '0'); // January is 0!
    const year = dateObj.getFullYear();

    return `${day}-${month}-${year}`;
  };
  const formatDateInput = (dateStr) => {
    const parts = dateStr.split("-");
    if (parts.length === 3) {
      return `${parts[2]}-${parts[1]}-${parts[0]}`;
    } else {
      return dateStr;
    }
  };
  // const formatDate = (date) => {
  //   if (!date) return ""; // Handle empty date case
  //   const formattedDate = new Date(date).toISOString().split("T")[0];
  //   return formattedDate;
  // };
  const hanldeRCMEdit = (index, field, SysReqDTT, SysConsumDTT,ChangeReqDTT,changeConsumDTT) => {
    debugger;
    let Retrncolor=false;
    const SyReqDTT = SysReqDTT;
    const newData = [...workFlowData];
    const strSysTM = new Date(SysReqDTT);
    strSysTM.setMonth(strSysTM.getMonth() + 3);
    const SysReqDT = new Date(SysReqDTT).getTime();
    const SysConsumDT = new Date(SysConsumDTT).getTime();
    const ChangeReqDT = new Date(ChangeReqDTT).getTime();
    const changeConsumDT = new Date(changeConsumDTT).getTime();

if(changeConsumDT!='' && ChangeReqDT!=''){
    // if (field === "REQUIREMENT_DATE") {
      if (ChangeReqDT === SysReqDT && SysConsumDT===changeConsumDT) {
        setRCMStatus("green"); // green 1
        Retrncolor=true;
      } 
      if (SysReqDT < ChangeReqDT && SysConsumDT===changeConsumDT) {
        setRCMStatus("red"); // red 2
        Retrncolor=false;
      } 
      if (SysReqDT === ChangeReqDT && SysConsumDT<changeConsumDT) {
        setRCMStatus("green"); // green 3
        Retrncolor=true;
      } 
      if (SysReqDT > ChangeReqDT &&  SysConsumDT>changeConsumDT) {
        setRCMStatus("red"); // red 4
        Retrncolor=false;
      } 
      if (SysReqDT === ChangeReqDT &&  SysConsumDT>changeConsumDT) {
        setRCMStatus("green"); // green 5
        Retrncolor=true;
      }       
      if (SysReqDT > ChangeReqDT &&  SysConsumDT===changeConsumDT) {
        setRCMStatus("green"); // green 6
        Retrncolor=true;
      } 
      if (SysReqDT < ChangeReqDT &&  SysConsumDT<changeConsumDT) {
        setRCMStatus("green"); // green 7
        Retrncolor=true;
      } 
      // if (strSysTM >= ChangeReqDT) {
      //   setRCMStatus("green"); // green 8
      // } 
    //} 
  }
    newData[index]["REQUIREMENT_DATE"] = ChangeReqDTT;
    newData[index]["CONSUMP_DT"] = changeConsumDTT;
    newData[index]["RCM_CHECKS_Status"] = Retrncolor;
    //newData[index]["VMI_Status"] = VMIstatus;
    setWorkFlowData(newData);
    console.log(newData,"newData");
  };

  const RCMStatus = (index, field, SysReqDTT, SysConsumDTT,ChangeReqDTT,changeConsumDTT) => {
    debugger;
    const Retrncolor ="green";
    const SyReqDTT = SysReqDTT;
    const newData = [...workFlowData];
    const strSysTM = new Date(SysReqDTT);
    strSysTM.setMonth(strSysTM.getMonth() + 3);
    const SysReqDT = new Date(SysReqDTT).getTime();
    const SysConsumDT = new Date(SysConsumDTT).getTime();
    const ChangeReqDT = new Date(ChangeReqDTT).getTime();
    const changeConsumDT = new Date(changeConsumDTT).getTime();

if(changeConsumDT!='' && ChangeReqDT!=''){
    // if (field === "REQUIREMENT_DATE") {
      if (ChangeReqDT === SysReqDT && SysConsumDT===changeConsumDT) {
        setRCMStatus("green"); // green 1
      } 
      if (SysReqDT < ChangeReqDT && SysConsumDT===changeConsumDT) {
        setRCMStatus("red"); // red 2
      } 
      if (SysReqDT === ChangeReqDT && SysConsumDT<changeConsumDT) {
        setRCMStatus("green"); // green 3
      } 
      if (SysReqDT > ChangeReqDT &&  SysConsumDT>changeConsumDT) {
        setRCMStatus("red"); // red 4
      } 
      if (SysReqDT === ChangeReqDT &&  SysConsumDT>changeConsumDT) {
        setRCMStatus("green"); // green 5
      }       
      if (SysReqDT > ChangeReqDT &&  SysConsumDT===changeConsumDT) {
        setRCMStatus("green"); // green 6
      } 
      if (SysReqDT < ChangeReqDT &&  SysConsumDT<changeConsumDT) {
        setRCMStatus("green"); // green 7
      } 
      // if (strSysTM >= ChangeReqDT) {
      //   setRCMStatus("green"); // green 8
      // } 
    //} 
  }    
    newData[index]["RCM_CHECKS_Status"] = RCMstatus;
    setWorkFlowData(newData);

  };

  const hanldeRCMClick = (selectedRec) => {
    getRCM();
    setShowRCM(true);
   
  };
  const hideRCMModal = () => {
    setShowRCM(false);
  };
  const getRCM = () => {
    setWorkFlowData(workFlowData);
  };

  ///-------------VMI-----------//

  const hanldeVMIClick = (selectedRec) => {
    getVMI();
    setShowVMI(true);
  };

  const hideVMIModal = () => {
    setShowVMI(false);
  };

  const getVMI = () => {
    setWorkFlowData(workFlowData);
  };

  ////---------------Deprop------------///
  const hanldeDepropClick = (selectedRec) => {
    getDeprop();
    setShowDeprop(true);
    console.log(workFlowData, "workFlowData");
  };

  const hideDepropModal = () => {
    setShowDeprop(false);
  };

  const getDeprop = () => {
    setWorkFlowData(workFlowData);
  };

  const handleFilterChange = (event) => {
    setFilterText(event.target.value);

    setCurrentPage(1);
  };

  ////    for pagination      /////
  const hanldeSearchClick = async (indentno) => {
    console.log(indentno, "indentno test 2");
    setisLoading(true);
    showLoader();
    if (indentno !== "") {
      await axios
        .get(
          `${BaseUrl}api/IntelliBuyChecks/GetIntelliBuyChecksDetails?IndentId=${indentno}`
        )
        .then((response) => {
          const data = response.data;
          console.log(data.jsonData, "Data");
          if (data.jsonData.length > 0) {
            setWorkFlowData(data.jsonData);
            setIndentStatus(data.jsonData[0].INDENT_CURRENT_STATUS);
            setIndentDept(data.jsonData[0].DEPT);
            console.log(data.jsonData[0].ITEM_ID, "Item ID");
            setisLoading(false);
            hideLoader();
          } else {
            Swal.fire("", "No Data Found", "info");
            setWorkFlowData([]);
            setIndentStatus("");
            setIndentDept("");
            setisLoading(false);
            hideLoader();
          }

          ////console.log(data.jsonData[0].INDENT_STATUS,'INDENT_CURRENT_STATUS');
        })
        .catch((error) => {
          console.log(error);
          setisLoading(false);
          hideLoader();
        });
    } else {
      Swal.fire("", "Please fill Indent No", "error");
    }
  };
  // Function to calculate the product
  const calculatePrice = (value1, value2) => {
    return (value1 * value2).toFixed(3);
  };

  const filteredData = workFlowData.filter((row) => {
    // Convert the filter text to lowercase for case-insensitive comparison
    const searchText = filterText.toLowerCase();

    // Iterate through each column in the row
    for (const key in row) {
      const value = row[key];

      // Check if the value exists
      if (value !== undefined && value !== null) {
        if (typeof value === "string") {
          // Convert the string value to lowercase
          const columnValue = value.toLowerCase();
          // Check if the column value contains the filter text
          if (columnValue.includes(searchText)) {
            // If found, return true to include this row in the filtered data
            return true;
          }
        } else if (typeof value === "number") {
          // Convert the integer value to string
          const columnValue = value.toString();
          // Check if the column value contains the filter text
          if (columnValue.includes(searchText)) {
            // If found, return true to include this row in the filtered data
            return true;
          }
        }
      }
    }
    // If no match is found in any column, return false to exclude this row from the filtered data
    return false;
  });

  const totalPages = Math.ceil(filteredData.length / itemsPerPage);
  //console.log(totalPages, "Total page");
  //console.log(filteredData, "filteredData");
  // const currentData = filteredData.slice(
  //   (currentPage - 1) * itemsPerPage,

  //   currentPage * itemsPerPage
  // );
  const currentData = filteredData
    .filter((row) => row.ISACTIVE === "Y")
    .slice((currentPage - 1) * itemsPerPage, currentPage * itemsPerPage);

  const handlePageChange = (pageNumber) => {
    setCurrentPage(pageNumber);
  };

  const hanldeEdit = (index, field, event) => {
    const newData = [...workFlowData];
    newData[index][field] = event;
    setWorkFlowData(newData);
  };

  // const handleDeleteRow = (UMC_INDENT_ID) => {
  //   const newData = workFlowData.filter(
  //     (item) => item.UMC_INDENT_ID !== UMC_INDENT_ID
  //   );
  //   setWorkFlowData(newData);
  //   const totalPage = Math.ceil(newData.length / itemsPerPage);
  //   setCurrentPage(totalPage);
  // };
  const handleDeleteRow = (UMC_INDENT_ID) => {
    const newData = workFlowData.map((item) =>
      item.UMC_INDENT_ID === UMC_INDENT_ID ? { ...item, ISACTIVE: "N" } : item
    );
    setWorkFlowData(newData);
    const filteredData = newData.filter((item) => item.ISACTIVE === "Y");
    const totalPage = Math.ceil(filteredData.length / itemsPerPage);
    setCurrentPage(totalPage);
  };

  useEffect(() => {
    console.log(indentId, "indentno test");
    if (indentId !== "") {
      hanldeSearchClick(indentId);
    }
    //fetchCsrCategoryList();
  }, []);

  useEffect(()=>{
    debugger;
    workFlowData.forEach(row=> {
      hanldeRCMEdit(row.index,"",row.ReqDate,row.ConsDate,row.REQUIREMENT_DATE,row.CONSUMP_DT );
      console.log("use effect");
    });
  },[])
  //---------------------Save As Draft-------------------------------
  const handleSaveAsDraft = async () => {
    setisLoading(true);
    showLoader();
    var formDetails = {
      ObjIntelliBuyChecksHeader: {
        INDENT_ID: indentno,
        INDENTER_LOC: workFlowData[0].INDENTER_LOC,
        INDENTOR_PLANT: workFlowData[0].INDENTOR_PLANT,
        INDENTER_DEPT: workFlowData[0].INDENTER_DEPT,
        INDENT_DESC: workFlowData[0].INDENT_DESC,
        INDENT_REMARKS: workFlowData[0].INDENT_REMARKS,
        INDENT_CRT_BY: workFlowData[0].INDENT_CRT_BY,
        INDENT_MOD_BY: workFlowData[0].INDENT_MOD_BY,
        INDENT_STATUS: "25",
        SCH_CART_NO: workFlowData[0].SCH_CART_NO,
        SCH_CRT_DT: "",
        SCH_USR_NAME: "",
        ISACTIVE: "Y",
      },
      ObjIntelliBuyIndentDetails: workFlowData,
      IsDraft: "Y",
    };
    ////console.log("wfdata", workFlowData);
    try {
      axios
        .post(
          `${BaseUrl}api/IntelliBuyChecks/InsertIntelliBuyCheckItem`,
          formDetails
        )

        .then((response) => {
          if (response.statusText === "OK") {
            // fetchSavedDraftData();
            setisLoading(false);
            hideLoader();
            //Swal.fire("", "Items Saved Successfully", "success");
            sessionStorage.setItem("INDENT_ID", indentno);
            //navigate("/SIS/ShoppingCart"); // Redirect to new page
            switchToShoppingCart();
          } else {
            hideLoader();
          }
        });
    } catch (error) {
      hideLoader();
      setisLoading(false);
    }
  };

  return (
    <div>
      {/* <Navbar />
      <TabMenu prop={"IntelliBuySystemChecks"} /> */}
      {!state ? (
        <>
          <div
            className="container"
            style={{ marginTop: "8px", marginLeft: "2px", maxWidth: "100%" }}
          >
            <div className="card">
              <div className="card-body" style={{ maxWidth: "100%" }}>
                {/* <div className="row">
                  <div className="col-md-1">
                    <label> Indent Number:</label>
                  </div>
                  <div className="col-md-3">
                    <input
                      id="indentno"
                      name="indentno"
                      value={indentno}
                      onChange={(e) => setIndentNo(e.target.value)}
                      className="form-control"
                      type="text"
                    />
                  </div>
                  <div className="col-md-1">
                    <button
                      onClick={() => hanldeSearchClick(indentno)}
                      className=" btn btn-warning"
                      style={{ fontSize: "13px" }}
                    >
                      <i class="fas fa-filter"></i>
                      Search
                    </button>
                  </div>
                  <div className="col-md-3">
                    <label
                      style={{
                        textAlign: "center",
                        fontSize: "20px",
                        fontWeight: "bold",
                        color: "black",
                      }}
                    >
                      {" "}
                      Department:
                    </label>
                    <label
                      style={{
                        textAlign: "center",
                        fontSize: "20px",
                        fontWeight: "bold",
                        color: "red",
                        marginLeft: "10px",
                      }}
                    >
                      {" "}
                      {indentdept}
                    </label>
                  </div>

                  <div className="col-md-3">
                    <label
                      style={{
                        textAlign: "center",
                        fontSize: "20px",
                        fontWeight: "bold",
                        color: "black",
                      }}
                    >
                      {" "}
                      Status:
                    </label>
                    <label
                      style={{
                        textAlign: "center",
                        fontSize: "20px",
                        fontWeight: "bold",
                        color: "red",
                        marginLeft: "10px",
                      }}
                    >
                      {indentstatus}
                    </label>
                  </div>
                </div> */}
                <div className="row">
                  <div className="col-md-4">
                    {" "}
                    <input
                      type="text"
                      value={filterText}
                      onChange={handleFilterChange}
                      className="form-control"
                      placeholder="Enter search text"
                    />
                  </div>
                  <div className="col-md-5"></div>
                  <div
                    className="col-md-3"
                    style={{ border: "1px solid green" }}
                  >
                    <div className="row">
                      <label
                        className="form-label label-font"
                        style={{ textAlign: "center" }}
                      >
                        {" "}
                        Dept Budget Consumption in %{" "}
                      </label>
                    </div>
                    <div className="row">                      
                      <div className="app-container">                      
                        <ProgressBar backgroundColor={{color:"black"}} percentage={progress} />
                      </div>
                      <label
                        className="form-label label-font"
                        style={{ textAlign: "center" }}
                      >
                       
                      </label>
                    </div>
                    {/* <div className="row">
                      <div className="col-md-6 d-flex justify-content-end">
                        <label className="form-label label-font">Budget</label>
                        <label className="form-label label-font">
                          {" "}
                          &nbsp; 22562
                        </label>
                      </div>
                      <div className="col-md-6 d-flex justify-content-start">
                        <label className="form-label label-font">Actual</label>
                        <label className="form-label label-font">
                          {" "}
                          &nbsp; 13758
                        </label>
                      </div>
                    </div> */}
                  </div>
                </div>
                <br></br>
                <div className="row" style={{ overflowX: "auto" }}>
                  <div className="tables table-responsive table-responsive-sm">
                    <table className="table table-bordered tb">
                      <thead className="table-primary">
                        <tr>
                          <th> Sl No</th>
                          <th> UMC No</th>
                          <th> Description </th>
                          <th> BGG</th>
                          {/* <th> Nature of SKU</th> */}
                          <th> Refurbishable</th>
                          {/* <th> Proprietry</th> */}
                          <th style={{ whiteSpace: "nowrap" }}> Required On</th>
                          <th> UOM</th>
                          <th>Ident Qty</th>
                          <th> SC Qty</th>
                          {/* <th> Rate Per Item</th>
                        <th> Price</th>
                        <th> Plant</th> */}
                          <th> Max Qty</th>
                          <th style={{ whiteSpace: "normal" }}>
                            {" "}
                            Requirement / Consumption
                          </th>
                          <th> VMI/ARC </th>
                          <th> Refurshibility</th>
                          <th> Deprop</th>

                          <th> </th>
                        </tr>
                      </thead>

                      <tbody>
                        {" "}
                        {currentData.map((row, index) => (
                          <tr
                            key={row.UMC_INDENT_ID}
                            style={{
                              backgroundColor:
                                selectedRow === row.UMC_INDENT_ID
                                  ? "#ddd"
                                  : "white",
                            }}
                          >
                            <td style={{ display: "none" }}>
                              {row.UMC_INDENT_ID}
                            </td>
                            <td>{row.SRNO}</td>
                            <td>{row.REQ_UMC_NO}</td>
                            <td>{row.REQ_UMC_DESC}</td>
                            <td>{row.REQ_UMC_BGG}</td>
                            {/* <td></td> */}
                            <td>
                              {row.IS_REFURBISHABLE === "R"
                                ? "Refurbishable"
                                : row.IS_REFURBISHABLE === "N"
                                ? "Non Refurbishable"
                                : row.IS_REFURBISHABLE}
                            </td>
                            {/* <td></td> */}
                            <td>{row.REQUIREMENT_DATE}</td>
                            <td>{row.UOM}</td>
                            <td>{row.QTY}</td>
                            <td>{row.QTY - row.TOTAL_SAP_DOC_QTY}</td>
                            {/* <td>{row.PRICE_PER_ITEM}</td>
                          <td>{calculatePrice(row.PRICE_PER_ITEM, row.QTY)}</td>
                          <td>{row.INDENTOR_PLANT}</td> */}
                            <td>
                              <button
                                href=""
                                onClick={() => hanldeClick(row)}
                                className="btn"
                                style={{
                                  // backgroundColor: true === true ? "green" : "red",
                                  backgroundColor:
                                    row.QTY > parseInt(row.ALLOWEDQTY)
                                      ? "red"
                                      : "green",
                                  width: "70px",
                                  fontSize: "13px",
                                  color: "white",
                                }}
                              >
                                {row.QTY > parseInt(row.ALLOWEDQTY)
                                  ? "Fail"
                                  : "Passed"}
                              </button>
                            </td>
                            <td>
                              <div>
                                <button
                                  href=""
                                  onClick={() => hanldeRCMClick(row)}
                                  className="btn"                                 
                                  style={{
                                    backgroundColor:
                                    row.RCM_CHECKS_Status === false ? "red" : "green",                                                                
                                    width: "70px",
                                    fontSize: "13px",
                                    color: "white",
                                  }}
                                >
                                  {" "}
                                  {row.RCM_CHECKS_Status === false  ? "Fail"
                                  : "Passed"}
                                </button>
                              </div>
                            </td>
                            <td>
                              <div>
                                <button
                                  href=""
                                  onClick={() => hanldeVMIClick(row)}
                                  className="btn"
                                  style={{
                                    backgroundColor:
                                      row.ARC_VMI === "FALSE" ? "green" : "red",
                                    width: "70px",
                                    fontSize: "13px",
                                    color: "white",
                                  }}
                                >
                                  {" "}
                                  {row.ARC_VMI === "FALSE"
                                    ? "Passed"
                                    : "Fail"}
                                </button>
                              </div>
                            </td>
                            <td>
                              <div>
                                <button
                                  href=""
                                  onClick={() => hanlderefurshibilityClick(row)}
                                  className="btn"
                                  style={{
                                    backgroundColor:
                                      row.IS_REFURBISHABLE === "R"
                                        ? "red"
                                        : "green",
                                    width: "70px",
                                    fontSize: "13px",
                                    color: "white",
                                  }}
                                >
                                  {" "}
                                  {row.IS_REFURBISHABLE === "R"
                                    ? "Fail"
                                    : "Passed"}
                                </button>
                              </div>
                            </td>
                            <td>
                              <div>
                                <button
                                  href=""
                                  onClick={() => hanldeDepropClick(row)}
                                  className="btn"
                                  style={{
                                    backgroundColor:
                                      row.DOCUMENT_TYPE === "NP"
                                        ? "red"
                                        : "green",
                                    width: "70px",
                                    fontSize: "13px",
                                    color: "white",
                                  }}
                                >
                                  {" "}
                                  {row.DOCUMENT_TYPE === "NP"
                                    ? "Fail"
                                    : "Passed"}
                                </button>
                              </div>
                            </td>
                            <td>
                              <button
                                onClick={() => {
                                  handleDeleteRow(row.UMC_INDENT_ID);
                                }}
                                style={{
                                  width: "25px",
                                  height: "25px",
                                  padding: "0px",
                                }}
                                class="btn btn-danger btn-sm"
                                type="button"
                                data-toggle="tooltip"
                                data-placement="top"
                                title="Delete"
                              >
                                <i class="fa fa-trash"></i>
                              </button>
                            </td>
                          </tr>
                        ))}{" "}
                      </tbody>
                    </table>
                  </div>
                </div>
                <div className="row mt-2">
                  <div className="col-10"></div>
                  <div className="col-2">
                    <div className="pagination">
                      {Array.from({ length: totalPages }, (_, index) => (
                        <button
                          key={index}
                          onClick={() => handlePageChange(index + 1)}
                          className={`page-link ${
                            currentPage === index + 1 ? "active" : ""
                          }`}
                        >
                          {index + 1}
                        </button>
                      ))}
                    </div>
                  </div>
                </div>

                <div className="row mt-3">
                  <div className="col-8"></div>
                  <div className="col-2 d-flex justify-content-end">
                    <button
                      type="button"
                      className="btn btn-primary"
                      onClick={() => handleSaveAsDraft()}
                    >
                      Create Shopping Cart
                    </button>
                  </div>

                  <div className="col-2 d-flex justify-content-start">
                    {/* <button type="button" className="btn btn-success">
                      Raise Shopping Cart
                    </button> */}
                  </div>
                </div>
                {show && (
                  <MaxQtyModal
                    updateQtyData={workFlowData}
                    handleClose={hideModal}
                    handleCellChange={hanldeEdit}
                    OnDeleteRow={hanldeDelete}
                  />
                )}
                {showrcm && (
                  <RequirmentConsumptionModal
                    requirmentConsumptionData={workFlowData}
                    handleClose={hideRCMModal}
                    handleCellChange={hanldeRCMEdit}
                    OnDeleteRow={hanldeDelete}
                  />
                )}
                {showrefurshibility && (
                  <RefurshibilityModal
                    requirmentConsumptionData={workFlowData}
                    handleClose={hiderefurshibilityModal}
                    OnDeleteRow={hanldeDelete}
                  />
                )}
                {showvmi && (
                  <VMIModal
                    VMIData={workFlowData}
                    handleClose={hideVMIModal}
                    OnDeleteRow={hanldeDelete}
                  />
                )}
                {showdeprop && (
                  <DepropModal
                    DepropData={workFlowData}
                    handleClose={hideDepropModal}
                    OnDeleteRow={hanldeDelete}
                  />
                )}
              </div>
            </div>
          </div>
        </>
      ) : (
        <ApprovalScreen />
      )}
    </div>
  );
};
export default IntelliBuyWorkflow;
