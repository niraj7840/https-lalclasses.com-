import React, { useEffect } from 'react'
import "./RaiseCapitalItemRequest.css"
//import '../../node_modules/bootstrap/dist/css/bootstrap.min.css'
import Button from 'react-bootstrap/Button';
//import 'bootstrap-select';
//import 'bootstrap-select/dist/css/bootstrap-select.min.css';
//import "./RaiseRequest.css";
//import $ from 'jquery';
import Navbar from "../components/Navbar/Navbar"
import { FaWpforms } from "react-icons/fa6";
import { useNavigate, useLocation } from 'react-router-dom';
import LoadingBar from 'react-top-loading-bar'
import CapitalUmcSearchBar from '../components/CapitalUmcSearchBar/CapitalUmcSearchBar';
import { BaseUrl } from "../constants/BaseURL";
import Swal from 'sweetalert2';
import { useRef } from 'react';
import axios from 'axios';
import { useDispatch, useSelector } from "react-redux";
import { clearIndentId } from "../store/indentSlice";




const RaiseCapitalItemRequest = ({ setShowViewCapReq, setComponentToShow, showLoader, hideLoader }) => {
    const location = useLocation();
    var { request, indent1 } = location.state || {};
    // const indent=''
    const indent = useSelector((state) => state.indent ? state.indent.indentId : '');
    const user = useSelector((state) => JSON.parse(state.auth.userData));
    console.log("User", user);



    const [questions, setQuestions] = React.useState([]);
    const [forms, setForms] = React.useState([{ UmcNumber: '', QuestionResponses: [], Remarks: '', tag:''}]);
    const [showSuccessModal, setShowSuccessModal] = React.useState(false);
    const [progress, setProgress] = React.useState(0)
    const [showInitialModal, setShowInitialModal] = React.useState(indent === '');
    const [intent, setIntent] = React.useState("");
    const [requestData, setRequestData] = React.useState([]);
    const lastFormRef = useRef(null);
    const lastFormInputRef = useRef(null);
    const navigate = useNavigate();
    const [umcNumber, setUmcNumber] = React.useState('');
    const [isFilteredData, setIsFilteredData] = React.useState(true);
    const [message, setMessage] = React.useState("");
    const [success, setSuccess] = React.useState("");
    const [questionType, setQuestionType] = React.useState('spares');
    const [filteredQuestion, setFilteredQuestion] = React.useState([]);
    const [category, setCategory] = React.useState("");
    const dispatch = useDispatch();


    // Fetch questions from API
    useEffect(() => {
        showLoader();
        fetchQuestions();

    }, []);

    useEffect(() => {
        //showLoader();
        filterQuestions();


    }, [questionType, questions]);


    //       useEffect(()=>{
    //     dispatch(clearIndentId())
    //    },[navigate, dispatch])

    useEffect(() => {
        if (indent) {
            showLoader();
            setIntent(indent);
            handleSubmitIntent();
            console.log("Intent", intent)
            //handleIntentData();
        }


    }, [questions, indent]);



    const handleIntentData = () => {
        if (request) {
            //setShowInitialModal(false);

            console.log("intent request", request);

            const newForms = [{
                UmcNumber: `${request.REQ_UMC_NO} - ${request.DESCRIPTION}`,
                QuestionResponses: [],
                Remarks: ''
            }];
            console.log("newForm", newForms)

            setForms(newForms);
            console.log(forms);

            setTimeout(() => {
                if (lastFormRef.current) {
                    lastFormRef.current.scrollIntoView({ behavior: 'smooth' });
                }
            }, 100);

            setIsFilteredData(false); // Set to false to disable the search bar
            setProgress(100);
            setIntent(indent);
        }
    };

    const showQuestion = (formIndex, questionIndex) => {
        const previousResponses = forms[formIndex].QuestionResponses;

        if (questionType === 'spares') {
            if (questionIndex === 0) return true; // Always show the first question
            if (questionIndex === 1) return previousResponses[0] === 'N'; // Show second question if first answer is 'N'
            if (questionIndex === 2) return previousResponses[1] === 'Y'; // Show third question if second answer is 'Y'
        } else if (questionType === 'Repair') {

            if (questionIndex === 3) return true; // Always show the first question
            if (questionIndex === 4) return previousResponses[3] === 'N'; // Show second question if first answer is 'N'
            if (questionIndex === 5) return previousResponses[4] === 'Y'; // Show third question if second answer is 'Y'
        }
        return false; // Default case
    };

    const clearDependentResponses = (updatedForms, formIndex, questionIndex, value) => {
        if (questionType === 'spares') {
            if (questionIndex === 0 && value === 'Y') {
                updatedForms[formIndex].QuestionResponses[1] = '';
                updatedForms[formIndex].QuestionResponses[2] = '';
            } else if (questionIndex === 1 && value === 'N') {
                updatedForms[formIndex].QuestionResponses[2] = '';
            }
        } else if (questionType === 'Repair') {
            if (questionIndex === 3 && value === 'N') {
                updatedForms[formIndex].QuestionResponses[4] = '';
                updatedForms[formIndex].QuestionResponses[5] = '';
            } else if (questionIndex === 4 && value === 'N') {
                updatedForms[formIndex].QuestionResponses[5] = '';
            }
        }
    };
    



    const fetchQuestions = () => {
        console.log("Hit!")
        setProgress(20)
        fetch(`${BaseUrl}api/Question/GetQuestion`).then((response) =>
            response.json().then((data) => {

                setQuestions(data.jsonData);
                //setForms([{ UmcNumber: '', QuestionResponses: new Array(data.jsonData.length).fill('Y'), Remarks: '' }]);
                setProgress(100)
                hideLoader();

            })
                .catch(error => {
                    console.log(error)
                }
                )
        );
    }


    const filterQuestions = () => {
        let filtered;
        if (questionType === 'spares') {
            filtered = questions.filter(question => question.CQM_QUES_TYP === 'S');
            console.log("filtered Spare", filtered)
        } else if (questionType === 'Repair') {
            filtered = questions.filter(question => question.CQM_QUES_TYP === 'R'); // Assuming 'R' for repair questions
            console.log("filtered Repair", filtered)
        }
        setFilteredQuestion(filtered);
        setForms([{ UmcNumber: '', QuestionResponses: [], Remarks: '', tag:'' }]);
    };



    const handleChange = (e) => {
        setRequestData([]);
        setIntent(e.target.value);

    }


    const handleSubmitIntent = async (e) => {
        if (indent === '') {
            e.preventDefault();
        }
        console.log("Intent here at submit", intent)
        if (indent === '') {
            if (!intent) {
                Swal.fire('', "Please enter Indent NUMBER", 'info');
                return;
            }
        }


        setShowInitialModal(false)
        setProgress(30);

        try {
            const response = await axios.get(`${BaseUrl}api/IndentUmc/GetUmcsTaggedUnderIntent?intent=${intent}`);
            const data = response.data.jsonData;

            const responseExclusion = await axios.get(`${BaseUrl}api/IndentUmc/GetUmcsUnderIntent?indent=${intent}`);
            const exclusiveData = responseExclusion.data.jsonData;


            const umcNumbersInState = new Set(exclusiveData.map(item => item.CUA_UMC));
            console.log("Exclusion", umcNumbersInState)

            const filteredData = data.filter(item => item.TAG === 'N' && !umcNumbersInState.has(item.REQ_UMC_NO));

            setIsFilteredData(filteredData.length === 0);
            if (filteredData.length === 0) {
                setShowInitialModal(false);
            }
            else {
                console.log(filteredData, "filtereddata")
                const newForms = filteredData.map(item => ({
                    UmcNumber: `${item.REQ_UMC_NO} - ${item.DESCRIPTION}`,
                    QuestionResponses: [], // Assuming 'Y' as the default response
                    Remarks: ''
                }));
                // console.log("umcnumber",newForms)
                setForms(newForms);

                setTimeout(() => {
                    if (lastFormRef.current) {
                        lastFormRef.current.scrollIntoView({ behavior: 'smooth' })
                    }
                }, 100);

            }
            //setRequestData(data)
            setProgress(100);
            hideLoader();
            // console.log("data", data)
            //console.log("umcnumber",forms)

        } catch (error) {

            console.error('Error fetching data:', error);
        }

    };



    const handleChange1 = (event) => {
        setUmcNumber(event.target.value);
    };

    const determineCategory = (formIndex) => {
        const responses = forms[formIndex].QuestionResponses;
        console.log("Responsesss", responses);
        if (responses[0] === 'Y') {
            return 'Capital';
        } else if (responses[2] === 'Y') {
            return 'Capital';
        } else if (responses[1] === 'N' || responses[2] === 'N') {
            return 'Revenue';
        }
        return '';
    };

    const handleInputChange = (e, formIndex, field, questionIndex) => {
        console.log("Queestion Index", questionIndex)
        const value = e.target.value;
        const updatedForms = [...forms];

        if (field === 'UmcNumber' || field === 'Remarks') {
            updatedForms[formIndex][field] = value;
        } else {
            updatedForms[formIndex].QuestionResponses[questionIndex] = value;
            clearDependentResponses(updatedForms, formIndex, questionIndex, value);
            const newCategory = determineCategory(formIndex);
            if(newCategory==='Capital')
            {
                updatedForms[formIndex].tag='C'
            }
            else if(newCategory==='Revenue')
            {
                updatedForms[formIndex].tag='R'
            }
            else if(newCategory==='')
            {
                updatedForms[formIndex].tag=''
            }
            //updatedForms[formIndex].tag=newCategory==='Capital'?'C':'R';
            console.log("category is :", newCategory)
            setCategory(newCategory);
        }

        setForms(updatedForms);
    };

    const onRemove = (i) => {
        const newForm = forms.filter((_, index) => index !== i);

        //newForm.splice(i, 1)
        setForms(newForm)
    }

    const addForm = () => {
        setForms([...forms, { UmcNumber: '', QuestionResponses: [], Remarks: '', tag:'' }]);
        // setCategory("");
        // lastFormRef.current.scrollIntoView({
        //     behavior: 'smooth'
        // })
        setTimeout(() => {
            if (lastFormRef.current) {
                lastFormRef.current.scrollIntoView({ behavior: 'smooth' })
            }
        }, 100);
    };


    const handleSubmit = async (e) => {

        console.log(forms);
        console.log("Intent", intent);

        e.preventDefault();

        // Validate if all UMC Number fields are filled
        for (let form of forms) {
            if (!form.UmcNumber) {
                Swal.fire('', "Please Enter UMC NUMBER", 'info');
                return;
            }

            if (!form.Remarks) {
                Swal.fire('', "Please Enter Remark", 'info');
                return;
            }
            if (form.QuestionResponses.length === 0) {
                Swal.fire('', "Please Enter choices", 'info');
                return;
            }

        }


        const strippedForms = forms.map(form => {
            const umcParts = form.UmcNumber.split(' - ');
            return {
                ...form,
                UmcNumber: umcParts.length > 1 ? umcParts[0] : form.UmcNumber // Take only the UMC number part if it includes a description
            };
        });

        console.log(JSON.stringify(strippedForms));

        const requestBody = {
            Forms: strippedForms,
            CUA_INTENT_NO: intent,
            CUR_CREATED_BY: user.User_Id

        }

        try {
            setProgress(20);
            showLoader();
            let token = sessionStorage.getItem('token');
            const headers = {
                'jwt-token': token
            };
            console.log("form with tag", requestBody)

            const response = await axios.post(`${BaseUrl}api/RaiseCapReq/AddRequestFinal`, requestBody, { headers }, {
                withCredentials: true

            });

            console.log('Success:', response.data);
            if (response.data.Text === "Exist") {
                let message = "<div style='color: red;'>The following UMC numbers already tagged as Revenue/Capital:<br><br>";

                // Access UMCs marked as 'R'
                if (response.data.jsonData.hasOwnProperty("R") && response.data.jsonData["R"].length > 0) {
                    //message += "<b>UMCs marked as 'Revenue':</b><br>" + response.data.jsonData["R"].join(", ") + "<br><br>";
                    message += "<b>UMCs marked as 'Revenue':</b><br><span style='color: red;'>" + response.data.jsonData["R"].join(", ") + "</span><br><br>";
                }

                // Access UMCs marked as 'C'
                if (response.data.jsonData.hasOwnProperty("C") && response.data.jsonData["C"].length > 0) {
                    //message += "<b>UMCs marked as 'Capital':</b><br>" + response.data.jsonData["C"].join(", ") + "<br><br>";
                    message += "<b>UMCs marked as 'Capital':</b><br><span style='color: red;'>" + response.data.jsonData["C"].join(", ") + "</span><br><br>";
                }

                // Access existing UMCs
                // if (response.data.jsonData.hasOwnProperty("AlreadyExists") && response.data.jsonData["AlreadyExists"].length > 0) {
                //     message += "<b>Existing UMCs:</b><br>" + response.data.jsonData["AlreadyExists"].join(", ") + "<br><br>";
                // }

                message += "</div>";

                // Show the message using SweetAlert
                Swal.fire({
                    title: "Already Tagged!",
                    html: message,
                });




                setForms([{ UmcNumber: '', QuestionResponses: [], Remarks: '', tag:'' }])
                hideLoader();
                setProgress(100);
                return;
            }
            else if (response.data.Text === "Success") {
                setSuccess("Success!");
                setShowSuccessModal(true);
                setMessage("Your Request has been successfully submitted!");
                setProgress(100);
            }


        } catch (error) {
            console.error('Error:', error);
        }
    };
    const handleInitialModalChoice = (choice) => {
        setShowInitialModal(false);

    };

    const handleCloseModal = () => {
        setShowSuccessModal(false);

        navigate("/SIS/ViewCapitalRequest");
        // setShowViewCapReq(true);
        // setComponentToShow(false);

    }

    const handleCloseNotFoundModal = () => {
        //navigate("/SIS/ViewCapitalRequest");
        setShowInitialModal(false);
    }

    const handleQuestionTypeChange = (e) => {
        setQuestionType(e.target.value);
        //fetchQuestions(); // Refetch questions based on the new type
    };

    return (
        <>
            <LoadingBar
                color='#f11946'
                progress={progress}
                onLoaderFinished={() => setProgress(0)}
            />
            {/* <Navbar /> */}
            <div className="container" style={{ maxWidth: "100%" }}>
                <div className="card border" style={{ background: "white" }}>
                    {/* <div
                        className="card-heading"
                        style={{
                            // backgroundColor: "#004d7a", // fallback background color
                            backgroundColor: 'lightgray',
                            height: '48px',
                            display: 'flex',
                            justifyContent: 'center',
                            alignItems: 'center'
                        }}
                    >
                        <h4 style={{ display: 'flex', alignItems: 'center', gap: '8px', color: "#080808de" }} className="mt-1"><i style={{ fontSize: "30px", marginBottom: "5px" }}><FaWpforms /></i>Raise Capital Item request</h4>
                    </div>*/}

                    {/* <div>
                        <label>
                            <input
                                type="radio"
                                value="spares"
                                checked={questionType === 'spares'}
                                onChange={handleQuestionTypeChange}
                            />
                            Spares
                        </label>
                        <label>
                            <input
                                type="radio"
                                value="Repair"
                                checked={questionType === 'Repair'}
                                onChange={handleQuestionTypeChange}
                            />
                            Repair
                        </label>
                    </div> */}

                    <form>

                        {forms.map((form, formIndex) => (
                            <div key={`form-${formIndex}`} className="card mb-2 m-2">
                                <div className='card-body' style={{ border: "1px solid rgb(0, 196, 189)," }}>

                                    {isFilteredData ? (
                                        <div className="col-md-8">

                                            <div className="RaiseRequest" >
                                                <label style={{ color: 'rgb(0 144 191)', fontWeight: "bolder", marginBottom: "10px" }}>Search for the UMC Details</label>

                                                <CapitalUmcSearchBar
                                                    id={`UmcNumber-${formIndex}`}
                                                    name="UmcNumber"
                                                    capitalForm={forms}
                                                    setCapitalForm={setForms}
                                                    formNumber={formIndex}
                                                    className="form-control" />

                                            </div>
                                        </div>
                                    ) : (
                                        <div className="col-md-8">

                                            <div className="RaiseRequest" >
                                                <label style={{ color: 'rgb(0 144 191)', fontWeight: "bolder", marginBottom: "10px" }}>Search for the UMC Details</label>

                                                <input
                                                    id={`UmcNumber-${formIndex}`}
                                                    name="UmcNumber"
                                                    value={form.UmcNumber}
                                                    onChange={handleChange1}
                                                    disabled
                                                    className="form-control" />

                                            </div>
                                        </div>
                                    )}





                                    <section className="requestTable mt-2">
                                        <div className='d-flex justify-content-center'>
                                            <table className="table text-center table-bordered">

                                                <thead className="table-primary">
                                                    <tr>
                                                        <th style={{ fontWeight: 500 }}>Question No.</th>
                                                        <th style={{ fontWeight: 500 }}>Questions</th>
                                                        <th style={{ fontWeight: 500 }}>Yes</th>
                                                        <th style={{ fontWeight: 500 }}>No</th>


                                                    </tr>
                                                </thead>

                                                <tbody>
                                                    {filteredQuestion.map((question, questionIndex) => {
                                                        // Starting index based on the selected option
                                                        let startIndex = question.CQM_QUES_TYP === 'R' ? 3 : 0; // Adjust as needed

                                                        // Map questionIndex based on startIndex
                                                        //questionIndex = startIndex + questionIndex;

                                                        return (
                                                            showQuestion(formIndex, startIndex + questionIndex) && (
                                                                <tr key={`form-${formIndex}-question-${questionIndex}`}>
                                                                    <td className='tableElement'>{questionIndex + 1}</td> {/* Adding 1 to display index starting from 1 */}
                                                                    <td className='tableElement1'>{question.CQM_QUES_DESC}</td>
                                                                    <td>
                                                                        <input
                                                                            type="radio"
                                                                            id={`form-${formIndex}-question-${startIndex + questionIndex}-Y`}
                                                                            name={`form-${formIndex}-question-${startIndex + questionIndex}`}
                                                                            value="Y"
                                                                            checked={form.QuestionResponses[startIndex + questionIndex] === 'Y'}
                                                                            onChange={(e) => handleInputChange(e, formIndex, 'answer', startIndex + questionIndex)}
                                                                            className="form-check-input"
                                                                        />
                                                                        <label style={{ marginLeft: "5px" }} htmlFor={`form-${formIndex}-question-${questionIndex}-Y`} className="form-check-label">
                                                                            Yes
                                                                        </label>
                                                                    </td>
                                                                    <td>
                                                                        <input
                                                                            type="radio"
                                                                            id={`form-${formIndex}-question-${startIndex + questionIndex}-N`}
                                                                            name={`form-${formIndex}-question-${startIndex + questionIndex}`}
                                                                            value="N"
                                                                            checked={form.QuestionResponses[startIndex + questionIndex] === 'N'}
                                                                            onChange={(e) => handleInputChange(e, formIndex, 'answer', startIndex + questionIndex)}
                                                                            className="form-check-input"
                                                                        />
                                                                        <label style={{ marginLeft: "5px" }} htmlFor={`form-${formIndex}-question-${questionIndex}-N`} className="form-check-label">
                                                                            No
                                                                        </label>
                                                                    </td>
                                                                </tr>
                                                            )
                                                        );
                                                    })}
                                                </tbody>


                                            </table>
                                        </div>
                                    </section>

                                    {/* Render questions here based on your logic */}
                                    {form.tag && (
                                        <div className="alert alert-info" role="alert">
                                            Based on your inputs, this UMC is of category "<strong>{form.tag==='C'?'Capital':'Revenue'}</strong>"
                                        </div>
                                    )}



                                    <div className="mb-1">
                                        <label style={{ color: 'rgb(0 144 191)', fontWeight: "bolder", marginTop: "0px" }} htmlFor={`Remarks-${formIndex}`}>Remarks:</label>
                                        <input
                                            type="text"
                                            id={`Remarks-${formIndex}`}
                                            name="Remarks"
                                            value={form.Remarks}
                                            onChange={(e) => handleInputChange(e, formIndex, 'Remarks')}
                                            className="form-control"
                                            placeholder='Enter Remarks'
                                        />
                                    </div>
                                    {
                                        formIndex !== 0 && (<Button onClick={() => onRemove(formIndex)} className='m-2' style={{ width: "120px", height: "40px" }} variant="danger">Remove</Button>
                                        )}
                                </div>
                            </div>
                        ))}

                        <div className='card-footer' style={{ backgroundColor: "white" }}>
                            <section className='text-center'>
                                <div
                                    className="container1">
                                    {isFilteredData ? (<div className="row">

                                        <div className="col">
                                            <Button ref={lastFormRef} onClick={addForm} variant='primary' style={{ fontSize: "18px", paddingLeft: "30px", paddingRight: "30px" }}>Add More</Button>{' '}
                                        </div>
                                        <div className="col">
                                            <Button onClick={handleSubmit} variant='success' style={{ fontSize: "18px", paddingLeft: "40px", paddingRight: "40px" }}>Submit</Button>{' '}
                                        </div>
                                    </div>) : (<div className="row">


                                        <div className="col">
                                            <Button ref={lastFormRef} onClick={handleSubmit} variant='success' style={{ fontSize: "18px", paddingLeft: "40px", paddingRight: "40px" }}>Submit</Button>{' '}
                                        </div>
                                    </div>)}

                                </div>
                            </section>




                        </div>


                    </form>
                </div>
            </div>



            {showSuccessModal && (
                <>
                    <div className="modal-backdrop fade show"></div>
                    <div className="modal fade show" style={{ display: 'block' }} tabIndex="-1">
                        <div className="modal-dialog">
                            <div className="modal-content">
                                <div className="modal-header">
                                    <h5 className="modal-title">{success}</h5>
                                    <button type="button" className="btn-close" onClick={handleCloseModal} aria-label="Close"></button>
                                </div>
                                <div className="modal-body">
                                    <p>{message}</p>
                                </div>
                                <div className="modal-footer">
                                    <button type="button" className="btn btn-primary" onClick={handleCloseModal}>Close</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </>
            )}




            {showInitialModal && (
                <>
                    <div className="modal-backdrop fade show"></div>
                    <div className="modal fade show" style={{ display: 'block' }} tabIndex="-1">
                        <div className="modal-dialog">
                            <div className="modal-content" id="modalContent">
                                <div className="modal-header" id="modalHeader">



                                    <h5 style={{ paddingLeft: "120px" }} className="modal-title" id="ChooseOption">Choose an Option</h5>
                                    <button type="button" className="btn-close" onClick={handleCloseNotFoundModal} aria-label="Close"></button>
                                </div>
                                <div className="modal-body">
                                    <div className='row' id="buttonGroup">
                                        <Button variant="primary mb-4" id="Manual" onClick={() => handleInitialModalChoice('manual')}>Raise Request by UMC</Button>
                                        {/* "or" section */}
                                        <div className="row">
                                            <div className="col-12 text-center">
                                                <p className='ModalOr'>OR</p>
                                            </div>
                                        </div>
                                        {/* Input and Submit section */}

                                        <form onSubmit={handleSubmitIntent}>
                                            <div className="row g-0 align-items-center" id="rowFormIntent">
                                                <div className="row" id="row1">
                                                    {/* <div className='row' id="row1">
                                                        <label htmlFor="intent" className="col-form-label">Intent Number:</label>

                                                    </div> */}
                                                    <div className='row' id="row1">
                                                        <input
                                                            type="text"
                                                            id="intent"
                                                            value={intent}
                                                            onChange={(e) => handleChange(e)}
                                                            className="form-control"
                                                            placeholder='Enter an Indent Number'
                                                        />
                                                    </div>
                                                </div>

                                                <div className="row" id="row1">
                                                    <button id="submit1" type="submit" style={{ marginTop: "40px" }} className="btn btn-primary">Raise Request by Indent</button>
                                                </div>
                                            </div>
                                        </form>

                                    </div>
                                    <div className='row'>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </>
            )}

        </>
    );
};




export default RaiseCapitalItemRequest;

