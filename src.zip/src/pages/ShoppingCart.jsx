import React, { useState, useEffect } from "react";
import Navbar from "../components/Navbar/Navbar";
import TabMenu from "../components/TabMenu/TabMenu";
import ApprovalScreen from "./ApprovalScreen";
import { BaseUrl, LocalUrl } from "../constants/BaseURL";
import "./ShoppingCart.css";
import { useSelector } from "react-redux";

import axios from "axios";
import Swal from "sweetalert2";
import Tabs from "react-bootstrap/Tabs";
import Tab from "react-bootstrap/Tab";
import { Link } from "react-router-dom";
import { Label, TextArea } from "react-aria-components";
import {
  Container,
  Row,
  Col,
  Form,
  FormGroup,
  Collapse,
} from "react-bootstrap";
import { useNavigate } from "react-router-dom";
const ShoppingCart = (prop) => {
  const indentId = useSelector((state) =>
    state.indent ? state.indent.indentId : ""
  );
  const navigate = useNavigate();
  const [state, setstate] = useState(false);
  const [workFlowData, setWorkFlowData] = useState([]);
  const [indentno, setIndentNo] = React.useState("10000115");
  const [shoppingcartno, setShoppingCartNo] = React.useState("");
  const [indentdept, setIndentDept] = React.useState("");
  const [isLoading, setisLoading] = useState(true);
  const [StorageLocation, setStorageLocation] = React.useState("");
  const [DocumentType, setDocumentType] = React.useState("");
  const [PurchaseGroup, setPurchaseGroup] = React.useState("");
  const [ProcurementType, setProcurementType] = React.useState("");
  const [UnderConsumption, setUnderConsumption] = React.useState("");
  const [RequirementDate, setRequirementDate] = React.useState("");
  const [scqty, Setscqty] = React.useState("");
  const [priceperitem, Setpriceperitem] = React.useState("");
  const [filterText, setFilterText] = useState("");
  const [currentPage, setCurrentPage] = useState(1);
  const [CsrCategoryList, Setcsrcategorylist] = useState([]);
  const [CostCategoryList, Setcostcategorylist] = useState([]);
  const [DocumentsList, Setdocumentslist] = useState([]);
  const [CurrencyList, Setcurrencylist] = useState([]);
  const [CsrSubCategoryList, Setcsrsubcategorylist] = useState([]);
  const [CsrSubActivityList, Setcsrsubactivitylist] = useState([]);
  const [selectedRow, setSelectedRow] = useState(null);
  const [selectedItemId, setSelectedItemId] = useState(null);
  const [rows, setRows] = useState([
    { Line: 1, Percentage: "100", Assigned: "" },
    { Line: 2, Percentage: "", Assigned: "" },
    { Line: 3, Percentage: "", Assigned: "" },
    { Line: 4, Percentage: "", Assigned: "" },
    { Line: 5, Percentage: "", Assigned: "" },
  ]);

  const [selectedOptions, setSelectedOptions] = useState([]);
  const [selectedOption, setSelectedOption] = useState([]);
  const [subactivityselectedOption, setSubActivitySelectedOption] =
    useState("");
  const [open, setOpen] = useState(false);
  const [opendoc, setOpenDoc] = useState(false);
  const [openimport, setOpenImport] = useState(true);
  const [enablePanel, setEnablePanel] = useState(false);
  const [panelData, setPanelData] = useState("");
  const togglePanel = () => {
    setOpen(!open);
  };
  const togglePanelDoc = () => {
    setOpenDoc(!opendoc);
  };

  const handleCheckboxChangeSC = (index) => {
    setSelectedRow(index);
    togglePanel();
  };
  const addRow = () => {
    const newRow = {
      Line: rows.length + 1,
      Percentage: "",
      Assigned: "",
    };
    setRows([...rows, newRow]);
  };
  const itemsPerPage = 5;

  const handleFilterChange = (event) => {
    setFilterText(event.target.value);

    setCurrentPage(1);
  };

  ////    for pagination      /////
  const hanldeSearchClick = async (IndentNo) => {
    if (IndentNo.length > 0) {
      await axios
        .get(
          `${BaseUrl}api/ShoppingCart/GetIntelliBuyChecksDetails?IndentId=${IndentNo}`
        )
        .then((response) => {
          const data = response.data;
          console.log(data.jsonData, "Data");
          if (data.jsonData.length > 0) {
            setWorkFlowData(data.jsonData);
            // setDocumentType(data.jsonData[0].DOCUMENT_TYPE_DESC);
            // setStorageLocation(data.jsonData[0].DEST_SLOC);
            // setPurchaseGroup(data.jsonData[0].PG_DESC);
            // setProcurementType(data.jsonData[0].PROC_TYPE);
            setUnderConsumption();
            // setRequirementDate(data.jsonData[0].REQUIREMENT_DATE);
            setShoppingCartNo(data.jsonData[0].SCH_CART_NO);
            console.log(data.jsonData[0].SLOC_DESC, "SLOC_DESC");
          } else {
            Swal.fire("", "No Data Found", "info");
            setWorkFlowData([]);
            setShoppingCartNo("");
            setIndentDept("");
          }

          ////console.log(data.jsonData[0].INDENT_STATUS,'INDENT_CURRENT_STATUS');
        })
        .catch((error) => {
          //console.log(error);
        });
    } else {
      Swal.fire("", "Please fill Indent No", "error");
    }
  };
  // Function to calculate the product
  const calculatePrice = (value1, value2) => {
    return (value1 * value2).toFixed(3);
  };

  const filteredData = workFlowData.filter((row) => {
    // Convert the filter text to lowercase for case-insensitive comparison
    const searchText = filterText.toLowerCase();

    // Iterate through each column in the row
    for (const key in row) {
      const value = row[key];

      // Check if the value exists
      if (value !== undefined && value !== null) {
        if (typeof value === "string") {
          // Convert the string value to lowercase
          const columnValue = value.toLowerCase();
          // Check if the column value contains the filter text
          if (columnValue.includes(searchText)) {
            // If found, return true to include this row in the filtered data
            return true;
          }
        } else if (typeof value === "number") {
          // Convert the integer value to string
          const columnValue = value.toString();
          // Check if the column value contains the filter text
          if (columnValue.includes(searchText)) {
            // If found, return true to include this row in the filtered data
            return true;
          }
        }
      }
    }
    // If no match is found in any column, return false to exclude this row from the filtered data
    return false;
  });

  const totalPages = Math.ceil(filteredData.length / itemsPerPage);
  //console.log(totalPages, "Total page");
  //console.log(filteredData, "filteredData");
  // const currentData = filteredData.slice(
  //   (currentPage - 1) * itemsPerPage,

  //   currentPage * itemsPerPage
  // );
  const currentData = filteredData
    .filter((row) => row.ISACTIVE === "Y")
    .slice((currentPage - 1) * itemsPerPage, currentPage * itemsPerPage);

  const handlePageChange = (pageNumber) => {
    setCurrentPage(pageNumber);
  };

  const hanldeEdit = (index, field, event) => {
    const newData = [...workFlowData];
    newData[index][field] = event;
    setWorkFlowData(newData);
  };

  // const handleDeleteRow = (UMC_INDENT_ID) => {
  //   const newData = workFlowData.filter(
  //     (item) => item.UMC_INDENT_ID !== UMC_INDENT_ID
  //   );
  //   setWorkFlowData(newData);
  //   const totalPage = Math.ceil(newData.length / itemsPerPage);
  //   setCurrentPage(totalPage);
  // };
  const handleDeleteRow = (UMC_INDENT_ID) => {
    const newData = workFlowData.map((item) =>
      item.UMC_INDENT_ID === UMC_INDENT_ID ? { ...item, ISACTIVE: "N" } : item
    );
    setWorkFlowData(newData);
    const filteredData = newData.filter((item) => item.ISACTIVE === "Y");
    const totalPage = Math.ceil(filteredData.length / itemsPerPage);
    setCurrentPage(totalPage);
  };

  const handleButtonShowClick = (umcIndentId) => {
    setSelectedRow(umcIndentId); // Set the selected row ID
    togglePanel();
    console.log(umcIndentId);
  };

  useEffect(() => {
    if (indentno != null) {
      hanldeSearchClick(indentno);
    }
    fetchCsrCategoryList();
    fetchCostCategoryList();
    fetchDocumentsList();
    fetchCurrencyList();
  }, []);
  //--------------------------------Cost Assigment-------------------------//
  const fetchCostCategoryList = async () => {
    try {
      const response = await axios.get(
        `${BaseUrl}api/ShoppingCart/GetCostCategory`
      );
      Setcostcategorylist(response.data.jsonData);
      console.log(response.data.jsonData, "GetCostCategory");
    } catch (error) {
      console.log(error, "GetCostCategory");
    }
  };
  // Function to delete row
  const deleteRow = (id) => {
    const updatedRows = rows.filter((row) => row.Line !== id);
    setRows(updatedRows);
  };
  //------------------------------------Documents---------------------------------//
  const fetchDocumentsList = async () => {
    try {
      const response = await axios.get(
        `${BaseUrl}api/ShoppingCart/GetDocumentsText`
      );
      Setdocumentslist(response.data.jsonData);
      console.log(response.data.jsonData, "fetchDocumentsList");
    } catch (error) {
      console.log(error, "fetchDocumentsList");
    }
  };
  //---------------------------------Sustainability-----------------------------//
  const fetchCsrCategoryList = async () => {
    try {
      const response = await axios.get(
        `${BaseUrl}api/ShoppingCart/GetCostCsrCategory`
      );
      Setcsrcategorylist(response.data.jsonData);
      console.log(response.data.jsonData, "Setcsrsubcategorylist");
    } catch (error) {
      console.log(error, "fetchCsrCategoryList");
    }
  };
  const fetchCsrSubCategoryList = async () => {
    try {
      const response = await axios.get(
        `${BaseUrl}api/ShoppingCart/GetCostCsrSubCategory`
      );
      Setcsrsubcategorylist(response.data.jsonData);
    } catch (error) {
      console.log(error, "GetCostCsrSubCategory");
    }
  };

  const fetchCurrencyList = async () => {
    try {
      const response = await axios.get(
        `${BaseUrl}api/ShoppingCart/GetCurrencyCode`
      );
      Setcurrencylist(response.data.jsonData);
      console.log(response.data.jsonData, "GetCurrencyCode");
    } catch (error) {
      console.log(error, "GetCurrencyCode");
    }
  };

  const fetchCsrSubActivityList = async (CSR_SUB_CODE) => {
    try {
      const response = await axios.get(
        `${BaseUrl}api/ShoppingCart/GetCostCsrSubActivity?CSR_SUB_CODE=${CSR_SUB_CODE}`
      );
      Setcsrsubactivitylist(response.data.jsonData);
      console.log(response.data.jsonData, "fetchCsrSubActivityList");
    } catch (error) {
      console.log(error, "GetCostCsrSubActivity");
    }
  };
  const handleCheckboxChangeforSelect = (id) => {
    debugger;
    const updatedData = workFlowData.map((item) =>
      item.UMC_INDENT_ID === id
        ? { ...item, checked: true }
        : { ...item, checked: false }
    );
    console.log(workFlowData,'workFlowData');
    setWorkFlowData(updatedData);

    const selectedCheckbox = updatedData.find(
      (item) => item.UMC_INDENT_ID === id
    );
  
    if (selectedItemId !== id) {
      // Only update state if a different checkbox is selected
      setSelectedItemId(id);
      setEnablePanel(true);
      setPanelData(selectedCheckbox.data);
      setDocumentType(selectedCheckbox.DOCUMENT_TYPE_DESC);
      setStorageLocation(selectedCheckbox.SLOC_DESC);
      setPurchaseGroup(selectedCheckbox.PG_DESC);
      setProcurementType(selectedCheckbox.PROC_TYPE);
      setRequirementDate(selectedCheckbox.REQUIREMENT_DATE);
      setShoppingCartNo(selectedCheckbox.SCH_CART_NO);
      setUnderConsumption(selectedCheckbox.SPARE);
      Setscqty(selectedCheckbox.QTY);
      Setpriceperitem(selectedCheckbox.PRICE_PER_ITEM);
    } else {
      // Deselect the checkbox if it was already selected
      setSelectedItemId(null);
      setEnablePanel(false);
      setPanelData("");
      setDocumentType("");
      setStorageLocation("");
      setPurchaseGroup("");
      setProcurementType("");
      setRequirementDate("");
      setShoppingCartNo("");
      setUnderConsumption("");
      Setscqty("");
    }
    // const filteredData = workFlowData.filter((item) => item.ISACTIVE === "Y");
    // const totalPage = Math.ceil(filteredData.length / itemsPerPage);
    // console.log(totalPage,'totalPage');
    // setCurrentPage(totalPage);
  };
  const isChecked = (value) => selectedOptions.includes(value);
  const handleCheckboxChange = (value) => {
    debugger;
    console.log(value, "None");
    if (value == "01") {
      fetchCsrSubCategoryList();
      isChecked(true);
    } else {
      Setcsrsubcategorylist([]);
      Setcsrsubactivitylist([]);
    }
    // if (value === "all") {
    //   // console.log("None");
    //   // setSelectedOptions([]);

    //   // Setcsrsubcategorylist([]);
    //   // Setcsrsubactivitylist([]);
    //   if (selectedOptions.length === CsrCategoryList.length) {
    //     setSelectedOptions([]);
    //   } else {
    //     setSelectedOptions(CsrCategoryList.map((option) => option.VALUE));
    //   }
    // } else {
    //   if (selectedOptions.includes(value)) {
    //     setSelectedOptions(
    //       selectedOptions.filter((option) => option !== value)
    //     );
    //   } else {
    //     setSelectedOptions([...selectedOptions, value]);
    //   }
    //   //fetchCsrSubCategoryList();
    // }
  };
  const handleRadioChange = (value) => {
    setSelectedOption(value);
    fetchCsrSubActivityList(value);
  };
  const handleSubActivityRadioChange = (value) => {
    setSubActivitySelectedOption(value);
  };

  // Function to handle input changes
  const handleInputChangePrice = (event) => {
    Setpriceperitem(event.target.value); // Update the state with input value
  };
  const handleInputChange = (id, field, value) => {
    const updatedRows = rows.map((row) => {
      if (row.Line === id) {
        return { ...row, [field]: value };
      }
      return row;
    });
    console.log(updatedRows);
    setRows(updatedRows);
  };

  //---------------------Back To IntelliBuy-------------------------------
  const handleBackToIntelliBuy = async () => {
    navigate("/SIS/IntelliBuySystemChecks");
  };

  //---------------------Save As Draft-------------------------------
  const handleSaveAsDraft = async () => {
    //  setisLoading(true);
    // prop.showLoader();
    var formDetails = {
      ObjIntelliBuyChecksHeader: {
        INDENT_ID: indentno,
        INDENTER_LOC: workFlowData[0].INDENTER_LOC,
        INDENTOR_PLANT: workFlowData[0].INDENTOR_PLANT,
        INDENTER_DEPT: workFlowData[0].INDENTER_DEPT,
        INDENT_DESC: workFlowData[0].INDENT_DESC,
        INDENT_REMARKS: workFlowData[0].INDENT_REMARKS,
        INDENT_CRT_BY: workFlowData[0].INDENT_CRT_BY,
        INDENT_MOD_BY: workFlowData[0].INDENT_MOD_BY,
        INDENT_STATUS: "25",
        SCH_CART_NO: "",
        SCH_CRT_DT: "",
        SCH_USR_NAME: "",
        ISACTIVE: "Y",
      },
      ObjIntelliBuyIndentDetails: workFlowData,
      IsDraft: "Y",
    };
    ////console.log("wfdata", workFlowData);
    try {
      axios
        .post(
          `${BaseUrl}api/IntelliBuyChecks/InsertIntelliBuyCheckItem`,
          formDetails
        )

        .then((response) => {
          if (response.statusText === "OK") {
            // fetchSavedDraftData();
            setisLoading(false);
            prop.hideLoader();
            Swal.fire("", "Items Saved Successfully", "success");
          } else {
            prop.hideLoader();
          }
        });
    } catch (error) {
      prop.hideLoader();
      setisLoading(false);
    }
  };

  return (
    <div>
      {/* <Navbar />
      <TabMenu prop={"IntelliBuySystemChecks"} /> */}
      {!state ? (
        <>
          <div
            className="container"
            style={{ marginTop: "8px", marginLeft: "2px", maxWidth: "100%" }}
          >
            <div className="card">
              <div className="card-body" style={{ maxWidth: "100%" }}>
                <div className="row">
                  <div className="col-md-6"></div>
                  <div className="col-md-3">
                    {/* <label
                      style={{
                        textAlign: "center",
                        fontSize: "20px",
                        fontWeight: "bold",
                        color: "black",
                      }}
                    >
                      {" "}
                      Department:
                    </label>
                    <label
                      style={{
                        textAlign: "center",
                        fontSize: "20px",
                        fontWeight: "bold",
                        color: "red",
                        marginLeft: "10px",
                      }}
                    >
                      {" "}
                      {indentdept}
                    </label> */}
                  </div>

                  <div className="col-md-3">
                    <label
                      style={{
                        textAlign: "center",
                        fontSize: "20px",
                        fontWeight: "bold",
                        color: "black",
                      }}
                    >
                      {" "}
                      Shopping Cart No:
                    </label>
                    <label
                      style={{
                        textAlign: "center",
                        fontSize: "20px",
                        fontWeight: "bold",
                        color: "red",
                        marginLeft: "10px",
                      }}
                    >
                      {shoppingcartno}
                    </label>
                  </div>
                </div>
                <div className="row">
                  <div className="col-md-8"></div>
                  <div className="col-md-4">
                    <input
                      type="text"
                      value={filterText}
                      onChange={handleFilterChange}
                      className="form-control"
                      placeholder="Enter search text"
                    />
                  </div>
                </div>
                <br></br>
                <div className="row" style={{ overflowX: "auto" }}>
                  <div className="table-responsive table-responsive-sm">
                    <table className="tables table-bordered tb">
                      <thead className="table-primary">
                        <tr>
                          <th> Select</th>
                          <th> Sl No</th>
                          <th> UMC No</th>
                          <th> Description </th>
                          <th> BGG</th>
                          <th>Requrment Date</th>
                          <th> SC Qty</th>
                          <th> Rate Per Item</th>
                          <th> Price</th>
                          <th> Document Type</th>
                          <th> Plant </th>
                        </tr>
                      </thead>

                      <tbody>
                        {" "}
                        {currentData.map((row, index) => (
                          <tr
                            key={index}
                            style={{
                              backgroundColor:
                                selectedRow === index ? "#ddd" : "white",
                            }}
                          >
                            <td style={{ display: "none" }}>
                              {row.UMC_INDENT_ID}
                            </td>
                            <td>
                              <input
                                type="checkbox"
                                defaultChecked="false"
                                checked={selectedItemId === row.UMC_INDENT_ID}
                                onChange={() =>
                                  handleCheckboxChangeforSelect(
                                    row.UMC_INDENT_ID
                                  )
                                }
                              />
                            </td>

                            <td>{row.SRNO}</td>
                            <td>{row.REQ_UMC_NO}</td>
                            <td>{row.REQ_UMC_DESC}</td>

                            <td>{row.REQ_UMC_BGG}</td>
                            <td>{row.REQUIREMENT_DATE}</td>
                            <td>{row.QTY}</td>
                            <td>{row.PRICE_PER_ITEM}</td>
                            <td>
                              {calculatePrice(row.PRICE_PER_ITEM, row.QTY)}
                            </td>
                            <td> {row.DOCUMENT_TYPE_DESC}</td>
                            <td> {row.INDENTOR_PLANT}</td>
                            {/* <td>
                              <button
                                onClick={() => {
                                  handleDeleteRow(row.UMC_INDENT_ID);
                                }}
                                style={{
                                  width: "25px",
                                  height: "25px",
                                  padding: "0px",
                                }}
                                class="btn btn-danger btn-sm"
                                type="button"
                                data-toggle="tooltip"
                                data-placement="top"
                                title="Delete"
                              >
                                <i class="fa fa-trash"></i>
                              </button>
                            </td> */}
                          </tr>
                        ))}{" "}
                      </tbody>
                    </table>
                  </div>
                </div>
                <div className="row mt-2">
                  <div className="col-10"></div>
                  <div className="col-2">
                    <div className="pagination">
                      {Array.from({ length: totalPages }, (_, index) => (
                        <button
                          key={index}
                          onClick={() => handlePageChange(index + 1)}
                          className={`page-link ${
                            currentPage === index + 1 ? "active" : ""
                          }`}
                        >
                          {index + 1}
                        </button>
                      ))}
                    </div>
                  </div>
                </div>

                <div className="row mt-3">
                  <div className="col-8"></div>
                  <div className="col-1">
                    {/* <button
                      type="button"
                      className="btn btn-primary"
                      onClick={() => handleBackToIntelliBuy()}
                    >
                      Back to IntelliBuy
                    </button> */}
                  </div>
                  <div className="col-2 d-flex justify-content-end">
                    <button
                      type="button"
                      className="btn btn-success"
                      onClick={() => handleSaveAsDraft()}
                    >
                      Save
                    </button>
                  </div>

                  <div className="col-2 d-flex justify-content-start"></div>
                </div>
              </div>
            </div>
            {enablePanel && (
              <div className="panel">
                <div className="card mt-3" style={{ maxWidth: "100%" }}>
                  <div
                    className="card-heading"
                    onClick={togglePanel}
                    style={{ backgroundColor: "#0d6efd", height: "34px" }}
                  >
                    <h6 className="mt-2" style={{ color: "white" }}>
                      &nbsp;{" "}
                      {open ? (
                        <i className="fa fa-minus text-blue"></i>
                      ) : (
                        <i className="fa fa-plus text-blue"></i>
                      )}
                      &nbsp; Indent Item Details
                    </h6>
                  </div>
                  <Collapse in={open}>
                    <div className="card-body">
                      {/* ----------Start Nav Tab---------- */}
                      <div className="col-12">
                        <Tabs
                          defaultActiveKey="SSA"
                          id="uncontrolled-tab-example"
                          className="my-tab position-relative"
                        >
                          <Tab
                            eventKey="SSA"
                            title={
                              <div style={{ padding: "0px 80px 0px 80px" }}>
                                Basic Data
                              </div>
                            }
                            className="act-clr"
                          >
                            <br />
                            <div className="row">
                              <div className="col-6">
                                <div class="row">
                                  <div class="col-md-6">
                                    <label className="form-label label-font">
                                      Storage location
                                    </label>
                                  </div>
                                  <div class="col-md-6">
                                    <label className="form-label label-font">
                                      {StorageLocation}{" "}
                                    </label>
                                  </div>
                                </div>

                                <div class="row">
                                  <div class="col-md-6">
                                    <label className="form-label label-font">
                                      Document type
                                    </label>
                                  </div>
                                  <div class="col-md-6">
                                    <label className="form-label label-font">
                                      {DocumentType}{" "}
                                    </label>
                                  </div>
                                </div>
                                <div class="row">
                                  <div class="col-md-6">
                                    <label className="form-label label-font">
                                      Purchase Group
                                    </label>
                                  </div>
                                  <div class="col-md-6">
                                    <label className="form-label label-font">
                                      {" "}
                                      {PurchaseGroup}
                                    </label>
                                  </div>
                                </div>
                                <div class="row mt-1">
                                  <div class="col-md-6">
                                    <label className="form-label label-font">
                                      Shopping Cart Qty
                                    </label>
                                  </div>
                                  <div class="col-md-3">
                                    <label className="form-label label-font">
                                      {scqty}
                                    </label>
                                    <label className="form-label label-font">
                                    {" "}  NO
                                    </label>
                                  </div>
                                  
                                </div>

                                <div class="row mt-1">
                                  <div class="col-md-6">
                                    <label className="form-label label-font">
                                      Unit price of the item
                                    </label>
                                  </div>
                                  <div class="col-md-6">
                                    <input
                                      className="form-control form-control-sm"
                                      value={priceperitem} // Bind input value to state variable
                                      onChange={handleInputChangePrice} // Handle input change
                                    ></input>
                                  </div>
                                  
                                </div>

                                {/* <div class="row">
                              <div class="col-md-6">
                                <label className="form-label label-font">
                                  Required qty.
                                </label>
                              </div>
                              <div class="col-md-6">
                                <label className="form-label label-font"> </label>
                              </div>
                            </div> */}

                                {/* <div class="row mt-1">
                                  <div class="col-md-6">
                                    <label className="form-label label-font">
                                      Refurbish Spare Qty
                                    </label>
                                  </div>
                                  <div class="col-md-6">
                                    <input className="form-control form-control-sm"></input>
                                  </div>
                                </div> */}
                                <div
                                  class="row mt-1"
                                  style={{ display: openimport }}
                                >
                                  <div class="col-md-6">
                                    <label className="form-label label-font">
                                      Material Consumption Plan
                                    </label>
                                  </div>
                                  <div class="col-md-6">
                                    <select
                                      name="category"
                                      id="category"
                                      className="form-control form-control-sm"
                                      type="text"
                                    >
                                      <option> --Select-- </option>
                                      <option Value="MTRCL">
                                        Material consumtion within 33 month of
                                        Import{" "}
                                      </option>
                                      <option Value="0"> Other</option>
                                    </select>
                                  </div>
                                </div>
                              </div>
                              <div className="col-6">
                                <div class="row">
                                  <div class="col-md-6">
                                    <label className="form-label label-font">
                                      Procurement Type
                                    </label>
                                  </div>
                                  <div class="col-md-6">
                                    <label className="form-label label-font">
                                      {ProcurementType}
                                    </label>
                                  </div>
                                </div>
                                <div class="row">
                                  <div class="col-md-6">
                                    <label className="form-label label-font">
                                      Spare Categorization
                                    </label>
                                  </div>
                                  <div class="col-md-6">
                                    <label className="form-label label-font">
                                      {UnderConsumption}
                                    </label>
                                  </div>
                                </div>

                                <div class="row mt-1">
                                  <div class="col-md-6">
                                    <label className="form-label label-font">
                                      Requirement Date
                                    </label>
                                  </div>
                                  <div class="col-md-6">
                                    <label className="form-label label-font">
                                      {RequirementDate}
                                    </label>
                                  </div>
                                </div>
                                <div class="row mt-1">
                                  <div class="col-md-6">
                                    <label className="form-label label-font">
                                      Installed Qty
                                    </label>
                                  </div>
                                  <div class="col-md-6">
                                    <input className="form-control form-control-sm"></input>
                                  </div>
                                </div>
                               
                                <div class="row mt-1">
                                <div class="col-md-6">
                                    <label className="form-label label-font">
                                      Celling Price
                                    </label>
                                  </div>
                                  <div class="col-md-2">
                                  <input className="form-control form-control-sm"></input>
                                  </div>
                                  <div class="col-md-1">
                                    <label className="form-label label-font">
                                      Currency
                                    </label>
                                  </div>
                                  <div class="col-md-2 d-flex justify-content-end">
                                    <select
                                      name="category"
                                      id="category"
                                      className="form-control form-control-sm"
                                      type="text"
                                    >
                                      <option>Select</option>
                                      <option value="INR"> INR </option>
                                      {CurrencyList.map((jsonData, id) => (
                                        <option key={id} value={jsonData.FCURR}>
                                          {jsonData.FCURR}
                                        </option>
                                      ))}
                                    </select>
                                  </div>
                                </div>
                               
                                <div
                                  class="row mt-1"
                                  style={{ display: openimport }}
                                >
                                  <div class="col-md-6">
                                    <label className="form-label label-font">
                                      Imported Plant And Machineary
                                    </label>
                                  </div>
                                  <div class="col-md-6">
                                    <select
                                      name="category"
                                      id="category"
                                      className="form-control form-control-sm"
                                      type="text"
                                    >
                                      <option> --Select-- </option>
                                      <option Value="Y">Yes</option>
                                      <option Value="N">No</option>
                                    </select>
                                  </div>
                                </div>
                              </div>
                            </div>

                            <p style={{ float: "right" }}>
                              <button
                                type="button"
                                className="btn btn-primary mt-2"
                              >
                                Next
                              </button>
                            </p>
                          </Tab>
                          <Tab
                            eventKey="CRA"
                            title={
                              <div style={{ padding: "0px 80px 0px 80px" }}>
                                Cost Assignment
                              </div>
                            }
                            className="tab-txt-clr act-clr"
                          >
                            <div>
                              <label
                                style={{ fontSize: "16px", fontWeight: "bold" }}
                              >
                                You can see who bears the costs and, if
                                necessary, you can distribute the costs to
                                several cost centers.
                              </label>
                              <div className="row mt-3">
                                <div className="col-2">
                                  <label>Category</label>
                                </div>
                                <div className="col-3">
                                  <select
                                    name="category"
                                    id="category"
                                    className="form-control form-control-sm"
                                    type="text"
                                  >
                                    <option> --Select-- </option>
                                    {CostCategoryList.map((jsonData, id) => (
                                      <option
                                        key={id}
                                        value={jsonData.CostCategoryList}
                                      >
                                        {jsonData.ACCT_ASGNMT_DESC}
                                      </option>
                                    ))}
                                  </select>
                                </div>
                                <div className="col-2">
                                  <label>Cost Distribution</label>
                                </div>
                                <div className="col-3">
                                  <select className="form-control form-control-sm">
                                    <option> --Select-- </option>
                                    <option>Percentage </option>
                                    <option> Quantity </option>
                                    <option VALUE="V"> Value </option>
                                  </select>
                                </div>
                              </div>
                              <button
                                className="btn btn-primary mb-3"
                                onClick={addRow}
                              >
                                Add New Row
                              </button>
                              <div className="tables table-responsive">
                                <table className="table table-bordered">
                                  <thead>
                                    <tr>
                                      <th>Line</th>
                                      <th>Percentage</th>
                                      <th>Assigned To</th>
                                      <th>Delete</th>
                                    </tr>
                                  </thead>
                                  <tbody>
                                    {rows.map((row, index) => (
                                      <tr key={row.id}>
                                        <td>{index + 1}</td>
                                        <td>
                                          <input
                                            type="text"
                                            className="form-control form-control sm"
                                            value={row.Percentage}
                                            onChange={(e) =>
                                              handleInputChange(
                                                row.Line,
                                                "Percentage",
                                                e.target.value
                                              )
                                            }
                                          />
                                        </td>
                                        <td>
                                          <input
                                            type="text"
                                            className="form-control form-control sm"
                                            value={row.Assigned}
                                            onChange={(e) =>
                                              handleInputChange(
                                                row.Line,
                                                "Assigned",
                                                e.target.value
                                              )
                                            }
                                          />
                                        </td>
                                        <td>
                                          <button
                                            onClick={() => {
                                              deleteRow(row.Line);
                                            }}
                                            style={{
                                              width: "25px",
                                              height: "25px",
                                              padding: "0px",
                                            }}
                                            class="btn btn-danger btn-sm"
                                            type="button"
                                            data-toggle="tooltip"
                                            data-placement="top"
                                            title="Delete"
                                          >
                                            <i class="fa fa-trash"></i>
                                          </button>
                                        </td>
                                      </tr>
                                    ))}
                                  </tbody>
                                </table>
                              </div>
                            </div>
                            <p style={{ float: "right" }}>
                              <button type="button" className="btn btn-primary">
                                Next
                              </button>
                            </p>
                          </Tab>
                          <Tab
                            eventKey="IBCA"
                            title={
                              <div style={{ padding: "0px 80px 0px 80px" }}>
                                Documents
                              </div>
                            }
                            className="tab-txt-clr act-clr"
                          >
                            <div>
                              <div className="row mt-3">
                                <div className="col-3">
                                  <select
                                    name="category"
                                    id="category"
                                    className="form-control form-control-sm"
                                    type="text"
                                  >
                                    <option> --Select-- </option>
                                    {DocumentsList.map((jsonData, id) => (
                                      <option key={id} value={jsonData.TEXT_ID}>
                                        {jsonData.TXT_DESC}
                                      </option>
                                    ))}
                                  </select>
                                </div>
                                <div className="col-5">
                                  <textarea
                                    className="form-control form-control sm"
                                    rows={4}
                                    cols={40}
                                  />
                                </div>
                              </div>
                              <p style={{ float: "right" }}>
                                <button
                                  type="button"
                                  className="btn btn-primary"
                                >
                                  Next
                                </button>
                              </p>
                            </div>
                          </Tab>
                          <Tab
                            eventKey="SCA"
                            title={
                              <div style={{ padding: "0px 80px 0px 80px" }}>
                                Sustainibility
                              </div>
                            }
                            className="tab-txt-clr act-clr"
                          >
                            <div className="row">
                              <div className="col-4">
                                <Form>
                                  <Form.Check type="checkbox" />
                                  {CsrCategoryList.map((option) => (
                                    <Form.Check
                                      key={option.VALUE}
                                      type="checkbox"
                                      label={option.LABEL}
                                      onChange={() =>
                                        handleCheckboxChange(option.VALUE)
                                      }
                                      //checked={isChecked(option.VALUE)}
                                    />
                                  ))}
                                </Form>
                                <p>
                                  {selectedOptions.length} /{" "}
                                  {CsrCategoryList.length} selected
                                </p>
                              </div>
                              <div className="col-4">
                                <Form>
                                  {CsrSubCategoryList.map((option, index) => (
                                    <Form.Check
                                      key={index}
                                      type="radio"
                                      label={option.LABEL}
                                      name="radioGroup"
                                      value={option.VALUE}
                                      checked={selectedOption === option.VALUE}
                                      onChange={() =>
                                        handleRadioChange(option.VALUE)
                                      }
                                    />
                                  ))}
                                </Form>
                                <p>Selected option: {selectedOption}</p>
                              </div>
                              <div className="col-4">
                                <Form>
                                  {CsrSubActivityList.map((option, index) => (
                                    <Form.Check
                                      key={index}
                                      type="radio"
                                      label={option.LABEL}
                                      name="radioGroupAct"
                                      value={option.VALUE}
                                      checked={
                                        subactivityselectedOption ===
                                        option.VALUE
                                      }
                                      onChange={() =>
                                        handleSubActivityRadioChange(
                                          option.VALUE
                                        )
                                      }
                                    />
                                  ))}
                                </Form>
                                <p>
                                  Selected option: {subactivityselectedOption}
                                </p>
                              </div>
                            </div>
                          </Tab>
                          {openimport && (
                            <Tab
                              eventKey="CLA"
                              title={
                                <div style={{ padding: "0px 80px 0px 80px" }}>
                                  Classification
                                </div>
                              }
                              className="tab-txt-clr act-clr"
                            >
                              <div>
                                <div className="row mt-2">
                                  <div className="col-3">
                                    <label className="form-label label-font d-flex justify-content-end">
                                      HSN No.
                                    </label>
                                  </div>
                                  <div className="col-6">
                                    <input className="form-control"></input>
                                  </div>
                                </div>
                                <div className="row mt-2">
                                  <div className="col-3">
                                    <label className="form-label label-font d-flex justify-content-end">
                                      Characteristics
                                    </label>
                                  </div>
                                  <div className="col-6">
                                    <textarea
                                      className="form-control form-control-sm"
                                      style={{ width: "400", height: "100px" }}
                                      placeholder="Characteristics"
                                    ></textarea>
                                  </div>
                                </div>
                                <div className="row mt-2">
                                  <div className="col-3">
                                    <label className="form-label label-font d-flex justify-content-end">
                                      Composition
                                    </label>
                                  </div>
                                  <div className="col-6">
                                    <textarea
                                      className="form-control form-control-sm"
                                      style={{ width: "400", height: "100px" }}
                                      placeholder="Composition"
                                    ></textarea>
                                  </div>
                                </div>
                                <div className="row mt-2">
                                  <div className="col-3">
                                    <label className="form-label label-font d-flex justify-content-end">
                                      End use :
                                    </label>
                                  </div>
                                  <div className="col-6">
                                    <textarea
                                      className="form-control form-control-sm"
                                      style={{ width: "400", height: "100px" }}
                                      placeholder="   End use :	"
                                    ></textarea>
                                  </div>
                                </div>
                                <div className="row mt-2">
                                  <div className="col-3">
                                    <label className="form-label label-font d-flex justify-content-end">
                                      Function
                                    </label>
                                  </div>
                                  <div className="col-6">
                                    <textarea
                                      className="form-control form-control-sm"
                                      style={{ width: "400", height: "100px" }}
                                      placeholder="Function"
                                    ></textarea>
                                  </div>
                                </div>
                              </div>
                            </Tab>
                          )}
                        </Tabs>
                      </div>
                      {/*----End Nav Tab-----*/}
                    </div>
                  </Collapse>
                </div>
                {/*----Document Upload Section-----*/}
                <div className="card mt-3" style={{ maxWidth: "100%" }}>
                  <div
                    onClick={togglePanelDoc}
                    className="card-heading"
                    style={{ backgroundColor: "#0d6efd", height: "34px" }}
                  >
                    <h6 className="mt-2" style={{ color: "white" }}>
                      &nbsp;{" "}
                      {opendoc ? (
                        <i className="fas fa-angle-down text-blue"></i>
                      ) : (
                        <i className="fas fa-angle-up text-blue"></i>
                      )}
                      &nbsp; &nbsp;Document Upload Section
                    </h6>
                  </div>
                  <Collapse in={opendoc}>
                    <div className="card-body">
                      <div className="row mt-2">
                        <div class="col-md-3">
                          <label className="form-label label-font">
                            Select File to Upload
                          </label>
                        </div>
                        <div class="col-md-3">
                          <input
                            type="file"
                            multiple
                            accept=".pdf, .jpg, .jpeg, .gif, .bmp, .png"
                          />
                          <br />
                          <span style={{ color: "Red", fontSize: "14px" }}>
                            Only .pdf, .jpg, .jpeg, .gif, .bmp, .png
                          </span>
                        </div>
                        <div class="col-md-6">
                          <textarea
                            className="form-control form-control-sm"
                            style={{ width: "400", height: "100px" }}
                            //  onChange={handleRemarksChange}
                            placeholder="Remarks"
                          ></textarea>
                        </div>
                      </div>
                    </div>
                  </Collapse>
                </div>
                {/*----Document Upload Section-----*/}
              </div>
            )}
          </div>
        </>
      ) : (
        <ApprovalScreen />
      )}
    </div>
  );
};

export default ShoppingCart;
