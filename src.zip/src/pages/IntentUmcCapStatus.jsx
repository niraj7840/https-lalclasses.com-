import React, { useState, useEffect } from 'react';
import Navbar from '../components/Navbar/Navbar';
import LoadingBar from 'react-top-loading-bar';
import { BaseUrl } from "../constants/BaseURL";
import { useNavigate } from "react-router-dom";
import "../pages/IntentUmcCapStatus.css";
import TabMenu from "../components/TabMenu/TabMenu";
import axios from "axios";
import { useSelector } from "react-redux";

const IntentUmcCapStatus = ({ setComponentToShow, setShowViewCapReq }) => {
    const indentId = useSelector((state) => state.indent ? state.indent.indentId : '');
    const [indent, setIndent] = useState(indentId);
    const [requestData, setRequestData] = useState([]);
    const [progress, setProgress] = useState(0);
    const [show, setShow] = useState(false);
    const [isLoading, setIsLoading] = useState(false);
    const [statuses, setStatuses] = useState({});
    const navigate = useNavigate();



    useEffect(() => {
        console.log("IndentId", indentId)
        if (indentId) {

            console.log("indent123", indent)
            handleSubmit();
        }
    }, [indentId])

    const getStatus = (status) => {
        switch (status) {
            case '1':
                return (
                    // <button id="buttonIntent" onClick={() => navigate('/SIS/ViewCapitalRequest')}>
                    //     Request No is pending with Capex team
                    // </button>

                    // <button id="buttonIntent" onClick={handlePendingWithClick}>
                    //     Request No is pending with Capex team
                    // </button>
                    "Request No is pending with Level 1"
                );
            case '2':
                return (
                    // <button id="buttonIntent" onClick={handlePendingWithClick}>
                    //     Request No is pending with VP
                    // </button>
                    "Request No is pending with Level 2"
                )
            case '3':
                return (
                    "Request No is pending with BAG"
                    // <button id="buttonIntent" onClick={() => navigate('/SIS/ViewCapitalRequest')}>
                    //     Request No is Closed
                    // </button>
                )
            case '4':
                return (
                    "Closed"
                    // <button id="buttonIntent" onClick={() => navigate('/SIS/ViewCapitalRequest')}>
                    //     Request No is is Rejected by Capital Accounts
                    // </button>
                )
            // case '5':
            //     return (
            //         <button id="buttonIntent" onClick={() => navigate('/SIS/ViewCapitalRequest')}>
            //             Request No is is Rejected by Capital Accounts
            //         </button>
            //     )
            default:
                return '';
        }
    };

    const handlePendingWithClick=()=>{
        setShowViewCapReq(true);
    }

    const fetchStatusForRequest = async (request) => {
        if (request.TAG === 'N') {
            try {
                const response = await axios(`${BaseUrl}api/IndentUmc/GetStatusOfUMCIndent?umc=${request.REQ_UMC_NO}&indent=${indent}`);
                //const result = await response.json();
                const status = response.data.jsonData;
                console.log("status", status)
                if (status !== "NotFound") {
                    return getStatus(status);
                } else {
                    return (
                        // <button id="buttonIntent" onClick={() => navigate('/SIS/CapitalRequest', { state: { request, indent } })}>
                        //     Raise Capital Item Approval Request for this Umc
                        // </button>
                        <button id="buttonIntent" onClick={handleRaiseCapitalClick}>
                            Raise Capital Item Approval Request for this Umc
                        </button>
                    );
                }
            } catch (error) {
                console.error('Error fetching status:', error);
                return 'Error fetching status';
            }
        } else if (request.TAG === 'C') {
            return 'UMC is already tagged as Capital Item';
        } else if (request.TAG === 'R') {
            return 'UMC is already tagged as Revenue';
        }
        return '';
    };

    const handleRaiseCapitalClick = () => {
        setComponentToShow();
    }

    const handleChange = (e) => {
        setShow(false);
        setRequestData([]);
        setIndent(e.target.value);
    };

    const handleSubmit = async (e) => {
        setIndent(indentId);
        //e.preventDefault();
        setShow(true);
        setProgress(30);
        setIsLoading(true);
        try {
            console.log("indent1236", indent)
            const response = await axios.get(`${BaseUrl}api/IndentUmc/GetUmcsTaggedUnderIntent?intent=${indent}`);
            const data = response.data.jsonData;
            console.log("FilteredData", data)
            setRequestData(data);
            setProgress(100);
            setIsLoading(false);
        } catch (error) {
            setIsLoading(false);
            setProgress(100);
            console.error('Error fetching data:', error);
        }
    };

    const fetchStatuses = async () => {
        const updatedStatuses = {};
        for (const request of requestData) {
            const statusDescription = await fetchStatusForRequest(request);
            updatedStatuses[generateKey(request, requestData.indexOf(request))] = statusDescription;
        }
        setStatuses(updatedStatuses);
    };

    const generateKey = (request, index) => `${request.REQ_UMC_NO}-${index}`;

    useEffect(() => {
        if (requestData.length > 0) {
            fetchStatuses();
        }
    }, [requestData]);

    return (
        <>
            <LoadingBar color='#f11946' progress={progress} onLoaderFinished={() => setProgress(0)} />

            {/* <TabMenu prop={"IndentUMCStatus"} /> */}
            <div className="container" style={{ marginTop: "8px", marginLeft: "2px", maxWidth: "100%" }}>
                <div className="card">
                    <div className="card-body" style={{ paddingTop: "1px" }}>
                        {/* <form onSubmit={handleSubmit}>
                            <div className="row g-0 align-items-center">
                                <div className="col-md-3">
                                    <label htmlFor="indent" className="col-form-label">Indent Number:</label>
                                    <div>
                                        <input
                                            type="text"
                                            id="intent1"
                                            value={indent}
                                            onChange={handleChange}
                                            className="form-control"
                                            placeholder='Enter an Indent Number'
                                        />
                                    </div>
                                </div>
                                <div className="col-md-3">
                                    <button id="submit" type="submit" style={{ marginTop: "40px" }} className="btn btn-primary">Search</button>
                                </div>
                            </div>
                        </form> */}
                        {show &&
                            <section className="requestTable mt-2">
                                <table className="table text-center table-bordered">
                                    <thead className="table-primary">
                                        <tr>
                                            <th style={{ fontWeight: 500 }}>SL NO</th>
                                            <th style={{ fontWeight: 500 }}>UMC NO</th>
                                            <th style={{ fontWeight: 500 }}>Description</th>
                                            <th style={{ fontWeight: 500 }}>Status</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        {requestData.map((request, index) => (
                                            <tr key={generateKey(request, index)}>
                                                <td>{index + 1}</td>
                                                <td>{request.REQ_UMC_NO}</td>
                                                <td>{request.DESCRIPTION}</td>
                                                <td>{statuses[generateKey(request, index)] || 'Loading status...'}</td>
                                            </tr>
                                        ))}
                                    </tbody>
                                </table>
                            </section>
                        }
                    </div>
                </div>
            </div>
        </>
    );
};

export default IntentUmcCapStatus;
