import React, { useState, useEffect } from "react";
import Navbar from "../components/Navbar/Navbar";
import axios from "axios";
import "bootstrap-select";
import "bootstrap-select/dist/css/bootstrap-select.min.css";
import "./PopupStyle.css";
import "./RaiseRequest.css";
import $ from "jquery";
import { Link, useNavigate } from "react-router-dom";
import { BaseUrl } from "../constants/BaseURL";
import * as comman from "../constants/CommanConstant";
import Autocomplete from "../components/UMCSearchBar/Autocomplete";
import { setIndentId,clearIndentId } from "../store/indentSlice";
import Swal from "sweetalert2";
import * as moment from 'moment'
import TabMenu from "../components/TabMenu/TabMenu";
import { useDispatch, useSelector } from "react-redux";

const RaiseRequest = (prop) => {


   const dispatch=useDispatch();
   const navigate=useNavigate();

  const [selectedMaterialArray, setSelectedMaterialArray] = useState([]);
  const [userInput, setUserInput] = useState("");
  const [returnMaxIndentId, setReturnMaxIndentId] = useState("");
  const user = useSelector((state) => JSON.parse(state.auth.userData));
 
  const [isLoading, setisLoading] = useState(true);
  const [errors, setErrors] = useState({});
  const[DocType,setDocType]=useState([]);
  const[fodType,setfodType]=useState([]);
  const [umcForm, setUmcForm] = useState({
    umcNo: "",
    materialDescription: "",
    unitOfMeasurement: "",
    quantity: "",
    
    destinationPlant: sessionStorage.getItem("DeptList")==null?"": sessionStorage.getItem("Plant"),
    destinationDepartment: sessionStorage.getItem("DeptList")==null?"": sessionStorage.getItem("Dept"),
    destinationDepartmentName: sessionStorage.getItem("DeptList")==null?"": sessionStorage.getItem("DeptName"),
   
    destinationStorage: "",
    requirementDate: "",
    consumptionDate: "",
    procurementType: "",
    location: "",
    UMC_INDENT_ID: "",
    REQ_UMC_NO: "",
    INDENT_ID: "",
    DEST_SLOC: "",
    UMC_INDENT_ID: "",
    materialBGG:"",
    currency:"",
    requestedOn: moment().format('YYYY-MM-DD'),
    rate:"",
    docType:"",
    fodType:"",
  });
  const [indentDescription, SetIndentDescription] = useState("");
  const [remarks, SetRemarks] = useState("");
  const [indentData, setIndentData] = useState({
    IndentorLoc: "",
    IndentorPlant: "",
    IndentorDept: "",
  });
  const [indentChildDetails, setIndentChildDetails] = useState([]);
  const [workFlowDetails, setWorkFlowDetails] = useState([]);
  const [show, setShow] = useState(false);
  const [deptshow, setDeptShow] = useState(false);
  const [selectedData, setSelectedData] = useState([]);
  const [selectedModalData, setselectedModalData] = useState([]);

 

  
  const hanldeClick = (selectedRec) => {
    const distinctValues = [
      ...new Set(
        selectedData.map(
          (obj) =>
            `${obj.AuilpQty}~${obj.AvlStk}~${obj.Category}~${obj.DeptCode}~${obj.DeptDesc}~${obj.InputMaterial}~${obj.Werks}~${obj.LocCd}~${obj.TYP}~${obj.UMC_INDENT_ID}~${obj.REQ_UMC_NO}~${obj.INDENT_ID}~${obj.DEST_SLOC}~${obj.REQ_QUANTITY}~${obj.Sloc}~${obj.Uom}`
        )
      ),
    ];

    const distinctObjects = distinctValues.map((value) => {
      const [
        AuilpQty,
        AvlStk,
        Category,
        DeptCode,
        DeptDesc,
        InputMaterial,
        Werks,
        LocCd,
        TYP,
        UMC_INDENT_ID,
        REQ_UMC_NO,
        INDENT_ID,
        DEST_SLOC,
        REQ_QUANTITY,Sloc,Uom
      ] = value.split("~");
      return {
        AuilpQty,
        AvlStk,
        Category,
        DeptCode,
        DeptDesc,
        InputMaterial,
        Werks,
        LocCd,
        TYP,
        UMC_INDENT_ID,
        REQ_UMC_NO,
        INDENT_ID,
        DEST_SLOC,
        REQ_QUANTITY,Sloc,Uom
      };
    });

    setSelectedData(distinctObjects);
   
    const filteredStatus = distinctObjects.filter(
      (item) => item.InputMaterial === selectedRec.umcNo
    ); // selectedRec.umcNo);
    if (filteredStatus.length > 0) {
      setselectedModalData(filteredStatus);
      setShow(true);
    } else {
      Swal.fire("", "No Location Found", "info");
    }
  };
  const fetchSAPData = async (UMC, DEPT) => {
    var AILU = 0;
    var INTRA = 0;
    var INTER = 0;
    let token = sessionStorage.getItem('token');
            const headers = {
            'jwt-token': token      
            };
    try{
      prop.showLoader();
       await  fetch(`${BaseUrl}api/SAP/GetData?UMC=${UMC}&DEPT=${DEPT}`,{headers}, {
        withCredentials: true
       
      })
      .then((response) => response.json())
      .then((data) => {
        //
        if(data.StatusCode=='success')
        {
        var data = JSON.parse(data.Response).d.results;
        for (let index = 0; index < data.length; index++) {
        
          data[index]["TYP"] = data[index].Category;
         
         if (data[index]["TYP"] == comman.AIULP) {
          AILU = AILU + parseFloat(data[index].AuilpQty);
         }
          else if (data[index]["TYP"] == comman.INTRA) {
            INTRA = INTRA + parseFloat(data[index].AvlStk);
          } else if (data[index]["TYP"] == comman.INTER) {
            INTER = INTER + parseFloat(data[index].AvlStk);
          }
          data[index]["UMC_INDENT_ID"] = "";
          data[index]["REQ_UMC_NO"] = data[index].InputMaterial;
          data[index]["INDENT_ID"] = "";
          data[index]["DEST_SLOC"] = data[index].LocCd;
          data[index]["REQ_QUANTITY"]= umcForm.quantity;
          data[index]["WF_CATEGORY"]= data[index].LocCd == umcForm.location ? comman.INTRA : comman.INTER;

          
          //data[index]["SLOC"]= umcForm.quantity;
          

        }
        setSelectedData((prevStatus) => prevStatus.concat(data));
      }
        const newmaterial = {
          umcNo: umcForm.umcNo,
          materailName: umcForm.materailName,
          materialDescription: umcForm.materialDescription,
          unitOfMeasurement: umcForm.unitOfMeasurement,
          quantity: umcForm.quantity,
          destinationPlant: umcForm.destinationPlant,
          destinationDepartment: umcForm.destinationDepartment,
          destinationDepartmentName: umcForm.destinationDepartmentName,
          destinationStorage: umcForm.destinationStorage,
          requirementDate: umcForm.requirementDate,
          consumptionDate: umcForm.consumptionDate,
          procurementType: umcForm.procurementType,
          location: umcForm.location,
          UMC_INDENT_ID: umcForm.UMC_INDENT_ID,
          REQ_UMC_NO: umcForm.umcNo,
          REQ_UMC_DESC: umcForm.materialDescription,
          INDENT_ID: returnMaxIndentId,
          DEST_SLOC: umcForm.destinationStorage,
          WF_TYPE: comman.INTRA,
         
        aiulpInventory:AILU,
        intraInventory:INTRA,
        interInventory:INTER
        };

        setSelectedMaterialArray((prevArray) => [...prevArray, newmaterial]);
        setIndentData({
          IndentorLoc: umcForm.location,
          IndentorPlant: umcForm.destinationPlant,
          IndentorDept: umcForm.destinationDepartment,
        });

        const indentChildDetailsData = {
          EXISTING_UMC: "-",
          EXIS_UMC_DESC: "-",
          DEST_SLOC: umcForm.destinationStorage,
          Uom: umcForm.unitOfMeasurement,
          QTY: umcForm.quantity,
          WF_TYPE: comman.INTRA,
          IS_REFURBISHABLE: "YES",
          IS_CRITICAL: "No",
          IS_PERISHABLE: "YES",
          REQ_DT: "",
          CONSUMP_DT: "",
          PROC_TYPE: umcForm.procurementType,
          CRT_BY: user.User_Id,
          UMC_INDENT_ID: umcForm.UMC_INDENT_ID,
          REQ_UMC_NO: umcForm.umcNo,
          INDENT_ID: returnMaxIndentId,
          DEST_SLOC: umcForm.destinationStorage,
          SRC_LOC_DESC: umcForm.location,
          REQ_UMC_DESC: umcForm.materialDescription,
          aiulpInventory:AILU,
          intraInventory:INTRA,
          interInventory:INTER,
          materialBGG: umcForm.materialBGG,
          currency: umcForm.currency,
          requestedOn: umcForm.requestedOn,
          rate: umcForm.rate,
          docType: umcForm.docType,
          fodType: umcForm.fodType,

        };

        setIndentChildDetails((prevArray) => [
          ...prevArray,
          indentChildDetailsData,
        ]);

        setUmcForm({
          umcNo: "",
          materialDescription: "",
          unitOfMeasurement: "",
          quantity: "",
          destinationStorage: "",
          materialBGG:"",
          currency:"",
          destinationDepartment: umcForm.destinationDepartment,
          destinationDepartmentName: umcForm.destinationDepartmentName,
          destinationPlant: umcForm.destinationPlant,
          requirementDate: "",
          consumptionDate: "",
          procurementType: "",
          location: "TSJ",
          UMC_INDENT_ID: "",
          REQ_UMC_NO: "",
          INDENT_ID: "",
          DEST_SLOC: "",
          rate:"",
          fodType: umcForm.fodType,
          docType:"",
          requestedOn: moment().format('YYYY-MM-DD'),
        });
        setUserInput("");
        prop.hideLoader();
        console.log("selected material ", selectedMaterialArray);

        console.log(selectedData);
      })
      .catch((error) => {
        console.log(error);
      });
    }catch(e){
      Swal.fire('','No Data Found','error');
    }
  };



  const fetchSAPDraftData = async (UMC, DEPT, UMCDATA,i) => {
       var AILU = 0;
        var INTRA = 0;
        var INTER = 0;
        let token = sessionStorage.getItem('token');
            const headers = {
            'jwt-token': token      
            };
    try{
    await fetch(`${BaseUrl}api/SAP/GetData?UMC=${UMC}&DEPT=${DEPT}`,{headers}, {
      withCredentials: true
     
    })
      .then((response) => response.json())
      .then((data) => {
        //
        if(data.StatusCode=='success')
        {
        var data = JSON.parse(data.Response).d.results;
       

        for (let index = 0; index < data.length; index++) {

          data[index]["TYP"] = data[index].Category;
         if (data[index]["TYP"] == comman.AIULP) {
          AILU = AILU + parseFloat(data[index].AuilpQty);
         } 
        else  if (data[index]["TYP"] == comman.INTRA) {
            INTRA = INTRA + parseFloat(data[index].AvlStk);
          } else if (data[index]["TYP"] == comman.INTER) {
            INTER = INTER + parseFloat(data[index].AvlStk);
          }
          data[index]["UMC_INDENT_ID"] = UMCDATA.UMC_INDENT_ID;
          data[index]["REQ_UMC_NO"] = UMCDATA.umcNo;
          data[index]["INDENT_ID"] = UMCDATA.INDENT_ID;
          data[index]["DEST_SLOC"] = UMCDATA.destinationStorage;
          data[index]["REQ_QUANTITY"]= UMCDATA.quantity;
          data[index]["WF_CATEGORY"]= data[index].LocCd == UMCDATA.SRC_LOC_DESC ? comman.INTRA : comman.INTER;

          
        } 

        data[i].aiulpInventory=AILU;
        data[i].intraInventory=INTRA;
        data[i].interInventory=INTER;
   
        $('#tbl tbody tr:eq('+i+') td:eq(4)').text(AILU);
        $('#tbl tbody tr:eq('+i+') td:eq(5)').text(INTRA);
        $('#tbl tbody tr:eq('+i+') td:eq(6)').text(INTER);

        setSelectedData((prevStatus) => prevStatus.concat(data));
        console.log(selectedData);
      }
      })
      .catch((error) => {
        console.log(error);
      });
    }catch(e){

    }
  };
  const hideModal = () => {
    setShow(false);
    setDeptShow(false);
  };

  const handleDelete = (index, e, selectedRec) => {
    const filteredStatus = selectedData.filter(
      (item) => item.InputMaterial !== selectedRec.umcNo
    ); // selectedRec.umcNo);
    if (filteredStatus.length > 0) {
      setSelectedData(filteredStatus);
    }
    setSelectedMaterialArray(
      selectedMaterialArray.filter((v, i) => i !== index)
    );
    setIndentChildDetails(indentChildDetails.filter((v, i) => i !== index));
    setWorkFlowDetails(workFlowDetails.filter((v, i) => i !== index));
  };

  const handleChangeUMC = (e) => {
    const { name, value } = e.target;
    setUmcForm({
      ...umcForm,
      [name]: value,
    });
    
     
    
  };
  const handleChangeDept = (val) => {
    
    setUmcForm({
      ...umcForm,
      "destinationDepartment": val,
    });
    
    hideModal();
  };
  

  const validateForm = () => {
    const newErrors = {};
    if (!umcForm.umcNo.trim()) newErrors.umcNo = "UMC No. is required";
    if (!umcForm.materialDescription.trim()) newErrors.materialDescription = "Material Description is required";
    if (!umcForm.unitOfMeasurement.trim()) newErrors.unitOfMeasurement = "Unit of Measurement is required";
    if (!umcForm.quantity.trim()) newErrors.quantity = "Quantity is required";
    if (!umcForm.destinationPlant.trim()) newErrors.destinationPlant = "Indenter Plant is required";
    if (!umcForm.destinationDepartment.trim()) newErrors.destinationDepartment = "Destination Department is required";
    if (!umcForm.destinationStorage.trim()) newErrors.destinationStorage = "Destination Storage is required";
    if (!umcForm.procurementType.trim()) newErrors.procurementType = "Procurement Type is required";
    if (!umcForm.rate.trim()) newErrors.rate = "Rate is required";
    if (!umcForm.docType.trim()) newErrors.docType = "Document is required";
    if (!umcForm.fodType.trim()) newErrors.fodType = "FOD is required";
    if (!umcForm.requestedOn.trim()) newErrors.requestedOn = "Rate is required";
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };
  const handleSubmit = (e) => {
    e.preventDefault();
    
    if(umcForm.umcNo.length==0){
      setUserInput("");
    }
    if (!validateForm()) {
      Swal.fire('', 'Please fill all  fields', 'error');
      return;
    }
    fetchSAPData(umcForm.umcNo, umcForm.destinationDepartment);
  };

  useEffect(() => {
    // Initialize bootstrap-select
    $(".selectpicker").selectpicker();
   
  }, []);


  //---------------------Save As Draft-------------------------------
  const handleSaveAsDraft = async () => {
    setisLoading(true);
    prop.showLoader();
    var formDetails = {
      T_SII_INDENT_DETAILS: {
        IndentorLoc: indentData.IndentorLoc,
        IndentorPlant: indentData.IndentorPlant,
        IndentorDept: indentData.IndentorDept,
        IndentDesc: indentDescription,
        IndentRemarks: remarks,
        UserName: user.User_Id,
        IndentId: returnMaxIndentId,
      },
      WorkFlowModel: [{ WF_ID: "" }],
      T_SIS_UMC_INDENT_DETAILS: indentChildDetails,
      T_SII_WORK_FLOW: workFlowDetails,
      IsDraft: "Y",
    };

    try {
      
      axios.post(`${BaseUrl}api/Indent/SaveIndent`, formDetails)

        .then((response) => {
          if (response.data.StatusCode === "OK") {
            fetchSavedDraftData();
            setisLoading(false);
            prop.hideLoader();
            Swal.fire("", "Indent Drafted Successfully", "success");
          } else {
            prop.hideLoader();
            Swal.fire("", "Something went wrong", "error");
           
          }
        });
    } catch (error) {
      prop.hideLoader();
      Swal.fire("", "Something went wrong", "error");
      setisLoading(false);
    }


  };
  const handelFinalRaiseIndent=async(formDetails)=>{
    
    try {
      
      axios.post(`${BaseUrl}api/Indent/SaveIndent`, formDetails)

        .then((response) => {
          if (response.data.StatusCode === "OK") {
            fetchSavedDraftData();
            setSelectedMaterialArray([]);
            setIndentChildDetails([]);
            setSelectedData([]);

            //alert('Indent Raised Successfully');
            setisLoading(false);
            Swal.fire(
              {title:"",
              text: "Indent Raised Successfully With Indent Id :"+response.data.data,
              icon: "success",
            confirmButtonText:"Ok"}
              ).then((result)=>{
                if(result.isConfirmed){
                  dispatch(setIndentId(response.data.data));
     navigate("/SIS/SmartIndenting");
                }
              });
            SetIndentDescription("");
            SetRemarks("");
            setReturnMaxIndentId("");
            prop.hideLoader();
          } else {
            Swal.fire("", "Something went wrong", "error");
            prop.hideLoader();
          }
        });
    } catch (error) {
      prop.hideLoader();
      Swal.fire("", "Something went wrong", "error");
      setisLoading(false);
    }
  }
  const handleRaiseIndent = async () => {
    prop.showLoader();
    setisLoading(true);
    setWorkFlowDetails([]);
      const distinctValues = [
      ...new Set(
        selectedData.map(
          (obj) =>
            `${obj.Sloc}~${obj.WF_CATEGORY}~${obj.AuilpQty}~${obj.AvlStk}~${obj.Category}~${obj.DeptCode}~${obj.DeptDesc}~${obj.InputMaterial}~${obj.Werks}~${obj.LocCd}~${obj.TYP}~${obj.UMC_INDENT_ID}~${obj.REQ_UMC_NO}~${obj.INDENT_ID}~${obj.DEST_SLOC}~${obj.REQ_QUANTITY}`
        )
      ),
    ];

    const distinctObjects = distinctValues.map((value) => {
      const [
        Sloc,
        WF_CATEGORY,
        AuilpQty,
        AvlStk,
        Category,
        DeptCode,
        DeptDesc,
        InputMaterial,
        Werks,
        LocCd,
        TYP,
        UMC_INDENT_ID,
        REQ_UMC_NO,
        INDENT_ID,
        DEST_SLOC,
        REQ_QUANTITY
      ] = value.split("~");
      return {
        Sloc,
        WF_CATEGORY,
        AuilpQty,
        AvlStk,
        Category,
        DeptCode,
        DeptDesc,
        InputMaterial,
        Werks,
        LocCd,
        TYP,
        UMC_INDENT_ID,
        REQ_UMC_NO,
        INDENT_ID,
        DEST_SLOC,
        REQ_QUANTITY
      };
    });
    var UmcChildData=indentChildDetails;
    var wfList=[];
    var flt=comman.HOD;
    var IndentStatus="";
    var fltData=distinctObjects.filter(obj=> obj.TYP==comman.AIULP);
    if(fltData.length>0)
    {
    flt=comman.MR;
    IndentStatus=comman.AIULPPENDING;
    
    }
    if(fltData.length==0){
      fltData=distinctObjects.filter(obj=> obj.TYP==comman.INTRA);
      IndentStatus=comman.INTRAPENDING;
    }
    if(fltData.length==0){
      fltData=distinctObjects.filter(obj=> obj.TYP==comman.INTER);
      IndentStatus=comman.INTERPENDING;
    }
    if(fltData.length==0){
      IndentStatus=comman.CAPEXPENDING;
    }
    for (let index = 0; index < UmcChildData.length; index++) {
      if(fltData.length>0){
      const element = fltData.filter(obj=>obj.InputMaterial== UmcChildData[index].REQ_UMC_NO);
      if(element.length>0){
        UmcChildData[index]["UMC_STATUS"]=comman.WIP;
      }else{
        UmcChildData[index]["UMC_STATUS"]=comman.WAIT;
      }}else{
        UmcChildData[index]["UMC_STATUS"]=comman.WIP;
      }
      UmcChildData[index]["aiulpInventory"]=$('#tbl tbody tr').eq(index).find('td').eq(4).text();
      UmcChildData[index]["intraInventory"]=$('#tbl tbody tr').eq(index).find('td').eq(5).text();
      UmcChildData[index]["interInventory"]=$('#tbl tbody tr').eq(index).find('td').eq(6).text();
      
    
    }
    //distinctObjects=fltData;
for (let index = 0; index < fltData.length; index++) {
  const workFlowDetailsData = {
    SRC_LOC_ID: "",
    SRC_LOC_DESC: fltData[index].LocCd,
    SRC_PLANT_ID: fltData[index].Werks,
    SRC_PLANT_DESC: "",
    SRC_DEPT_ID: fltData[index].DeptCode,
    SRC_DEPT_DESC: fltData[index].DeptDesc,
    REQ_QUANTITY: fltData[index].REQ_QUANTITY,
    APPROVED_QTY: "",
    WF_TYPE: fltData[index]["TYP"],
    WF_STATUS: flt,
    WF_EXPIRY_DT: "",
    WF_REMARKS: "",
    CRT_BY: "",
    UMC_INDENT_ID:fltData[index].UMC_INDENT_ID,
    REQ_UMC_NO: fltData[index].REQ_UMC_NO,
    INDENT_ID: returnMaxIndentId,
    DEST_SLOC: fltData[index].DEST_SLOC,
    SLOC:fltData[index].Sloc,
    WF_CATEGORY:fltData[index].WF_CATEGORY,
    
    
  };
  wfList.push(workFlowDetailsData);
  
  
}
var formDetails = {
  T_SII_INDENT_DETAILS: {
    IndentorLoc: indentData.IndentorLoc,
    IndentorPlant: indentData.IndentorPlant,
    IndentorDept: indentData.IndentorDept,
    IndentDesc: indentDescription,
    IndentRemarks: remarks,
    UserName: user.User_Id,
    IndentId: returnMaxIndentId,
    STATUS:IndentStatus
  },
  WorkFlowModel: [{ WF_ID: "" }],
  T_SIS_UMC_INDENT_DETAILS: UmcChildData,
  T_SII_WORK_FLOW: wfList,
  IsDraft: "N",
};

try {
      
  
        handelFinalRaiseIndent(formDetails);
      
} catch (error) {
  prop.hideLoader();
  Swal.fire("", "Something went wrong", "error");
  setisLoading(false);
}

   
  };

  useEffect(() => {
    setUmcForm((prevState) => ({
      ...prevState,
      location: "TSJ",
    }));
   
    fetchDoctumentList();
    fetchFODList();
    //fetchPlantList();
    fetchSavedDraftData();
  }, []);

 
  const [deptList, setDeptList] = useState([]);

  


  const fetchDoctumentList = async () => {
    try {
      const response = await axios.get(`${BaseUrl}api/Master/GetCodeList?CODE=${comman.DocumentTypeCode}`);
      const data = response.data;
     
      setDocType(data);
      
    } catch (error) {
      console.log(error);
    }
  };
  const fetchFODList = async () => {
    try {
      const response = await axios.get(`${BaseUrl}api/Master/GetCodeList?CODE=${comman.FODCode}`);
      const data = response.data;
     
    setfodType(data);
      
    } catch (error) {
      console.log(error);
    }
  };



  
const fetchSavedDraftData = async () => {
  try {
    const response = await axios.get(`${BaseUrl}api/Master/GetDraftedList?DEPT=${umcForm.destinationDepartment}&&USERNAME=${user.User_Id}`);
    const data = response.data;

    setisLoading(false);
    console.log("data", data);
    
    setIndentChildDetails(data);
    SetRemarks(data[0]["INDENT_REMARKS"]);
    SetIndentDescription(data[0]["INDENT_DESC"]);
    setReturnMaxIndentId(data[0]["INDENT_ID"]);
    setWorkFlowDetails([]);
    setSelectedData([]);

    for (let index = 0; index < data.length; index++) {
      fetchSAPDraftData(
        data[index].umcNo,
        data[index].SRC_DEPT_ID,
        data[index],
        index,
        data
      );
    }
    setSelectedMaterialArray(data);
  } catch (error) {
    console.log(error);
  }
  console.log("selected", selectedMaterialArray);
};


  return (
    <>
      {isLoading ? <div></div> : <></>}
      <>
        <Navbar />
        {/* <TabMenu prop={"RaiseIndent"}/> */}
        <div
          className="container"
          style={{ marginTop: "8px", maxWidth: "100%" }}
        >
          <div className="card">
             <div
              className="card-heading"
              style={{
                backgroundColor: "white",
                height: "44px",
                marginLeft:"3px",
                textAlign: "center",
              }}
            >
              <div className="row">
                <div className="col-md-4 mt-2">
                   <h5>Department :<label>{umcForm.destinationDepartmentName}({umcForm.destinationDepartment})</label></h5>
                  
                 
                
                </div>
                
                <div className="col-md-4 mt-2">
                  <h5>Plant :<label>{umcForm.destinationPlant}</label></h5>
                </div>
                <div className="col-md-4 mt-2">
                  <h5>Location :<label>{umcForm.location}</label></h5>
                </div>
              </div>
            </div>
            <form
              onSubmit={handleSubmit}
              style={{ margin: "6px" }}
              className="form"
            >
              <div style={{ border: "0px solid wheat", padding: "10px" }}>
                <div className="row">
                  <div className="col-md-6">
                    {/*-------------------Autocomplete-------- */}
                    <div className="RaiseRequest">
                      <label>Search for the UMC Details</label>
                      <Autocomplete
                    
                        umcForm={umcForm}
                        setUmcForm={setUmcForm}
                        selectedMaterialArray={selectedMaterialArray}
                        userInput={userInput}
                        setUserInput={setUserInput}
                        showLoader={prop.showLoader}
                        hideLoader={prop.hideLoader}
                      />
                    </div>
                  </div>
                  {/*-------------------End Autocomplete-------- */}

                  <div className="col-md-3" style={{display:"none"}}>
                    <label> Location </label>
                    <select
                      id="location"
                      name="location"
                      className="form-control"
                      value={umcForm.location}
                      onChange={handleChangeUMC}
                    >
                      <option> TSJ </option>
                    </select>
                  </div>
                  <div className="col-md-3"  style={{display:"none"}}>
                    <label>Indentor Plant</label>
                    <select
                      name="destinationPlant"
                      value={umcForm.destinationPlant}
                      onChange={handleChangeUMC}
                      id="destinationPlant"
                      className="form-control"
                      type="text"
                      
                    >
                      <option> --Select-- </option>
                      
                    </select>
                  </div>
                  <div className="col-md-3">
                    <label>Storage Location</label>
                    <input
                      id="destinationStorage"
                      name="destinationStorage"
                      className="form-control"
                      value={umcForm.destinationStorage}
                      onChange={handleChangeUMC}
                    />
                  </div>
                  <div className="col-md-3">
                    <label> Requested Quantity</label>
                    <input
                      id="quantity"
                      name="quantity"
                      className="form-control"
                      type="text"
                      value={umcForm.quantity}
                      onChange={handleChangeUMC}
                    />
                  </div>
                </div>
                <br />
                <div className="row" >
                  <div className="col-md-3" style={{display:"none"}}>
                    <label>Indentor Department</label>
                    
                  </div>
                 

                  <div className="col-md-2">
                    <label>Procurement Type</label>
                    <select
                      id="procurementType"
                      className="form-control"
                      name="procurementType"
                      value={umcForm.procurementType}
                      onChange={handleChangeUMC}
                    >
                      <option>Select Type</option>
                      <option>Routine</option>
                      <option>Break Down</option>
                    </select>
                  </div>
                  <div className="col-md-2">
                    <label>Required On</label>
                    <input type="date" style={{height:"41px !important"}}
                      id="requestedOn"
                      className="dateText"
                      name="requestedOn"
                      value={umcForm.requestedOn}
                      onChange={handleChangeUMC}
                    />
                      
                  </div>
                  <div className="col-md-2">
                    <label>Rate/Item</label>
                    <input type="number"
                      id="rate"
                      className="form-control"
                      name="rate"
                      value={umcForm.rate}
                      min="0"
                      onChange={handleChangeUMC}
                    />
                      
                  </div>
                  <div className="col-md-3">
                    <label>Document type</label>
                    <select
                      name="docType"
                      value={umcForm.docType}
                      onChange={handleChangeUMC}
                      id="docType"
                      className="form-control"
                      type="text"
                      
                    >
                      <option> --Select-- </option>
                      {DocType.map((itm, id) => (
                        <option key={id} value={itm.ID}>
                          {itm.VAL}
                        </option>
                      ))}
                    </select>
                  </div>
                  <div className="col-md-3">
                    <label>FOD type</label>
                    <select
                      name="fodType"
                      value={umcForm.fodType}
                      onChange={handleChangeUMC}
                      id="fodType"
                      
                      className="form-control"
                      type="text"
                      
                    >
                      <option> --Select-- </option>
                      {fodType.map((itm, id) => (
                        <option key={id} value={itm.ID}>
                          {itm.VAL}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>
                <div className="row">
                  <div className="col-md-12 center">
                    <button type="submit" className="btn btn-primary mt-4">
                      &nbsp;<i className="fas fa-plus-circle"></i>&nbsp;Add
                      Material
                    </button>
                  </div>
                </div>
                <div className="row"></div>
              </div>
            </form>
            <div className="card-body App">
              <section className="materialTable">
                <table className="table table-bordered" id="tbl">
                  <thead className="table-primary">
                    <tr>
                      <th></th>
                      <th>Umc Number</th>
                      <th>Umc Description</th>
                      <th>Procurment Type</th>
                      <th>AIULP Inventory</th>
                      <th>Intra Loction Inventory</th>
                      <th>Inter Loction Inventory</th>
                      <th>Existing UMC</th>
                      <th>Exisitng UMC Desc</th>
                      <th>Storage Location</th>
                      <th>Req Quantity</th>
                      <th>Uom</th>
                      <th></th>
                    </tr>
                  </thead>
                  <tbody>
                    {selectedMaterialArray.map((item, index) => {
                      return (
                        <tr key={index}>
                          <td>
                            <Link
                              href=""
                              onClick={() => hanldeClick(item)}
                              className="btn btn-info"
                            >
                              View{" "}
                            </Link>{" "}
                          </td>
                          <td>{item.umcNo}</td>
                          <td>{item.materialDescription}</td>
                          <td>{item.procurementType}</td>
                          
                          <td> {item.aiulpInventory} </td>
                          <td> {item.intraInventory} </td>
                          <td> {item.interInventory} </td>
                          <td> - </td>
                          <td> - </td>
                          <td> {item.destinationStorage} </td>
                          <td> {item.quantity} </td>
                          <td> {item.unitOfMeasurement} </td>
                          <td>
                            <button
                              onClick={(e) => handleDelete(index, e, item)}
                              className=" btn btn-danger"
                            >
                              Remove
                            </button>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
                {show && (
                  <Modal
                    details={selectedModalData}
                    umcForm={umcForm}
                    handleClose={hideModal}
                  />
                )}

              </section>
              <div className="row">
                <div className="col-md-6">
                  <label> Indent Description</label>
                  <input
                    id="IndentDescription"
                    name="IndentDescription"
                    className="form-control"
                    type="text"
                    value={indentDescription}
                    onChange={(e) => SetIndentDescription(e.target.value)}
                  />
                </div>
                <div className="col-md-6">
                  <label> Remarks</label>
                  <input
                    id="IndentRemarks"
                    name="IndentRemarks"
                    className="form-control"
                    type="text"
                    value={remarks}
                    onChange={(e) => SetRemarks(e.target.value)}
                  />
                </div>
              </div>
              <div className="row">
                <div className="col-md-12 center">
                  <button
                    type="submit"
                    className="btn btn-primary mt-4"
                    onClick={() => handleSaveAsDraft()}
                  >
                    &nbsp;<i className="fas fa-plus-circle"></i>&nbsp;Save As
                    Draft
                  </button>{" "}
                  &nbsp;{" "}
                  <button
                    type="submit"
                    className="btn btn-primary mt-4"
                    onClick={() => handleRaiseIndent()}
                  >
                    &nbsp;<i className="fas fa-plus-circle"></i>&nbsp;Raise
                    indent Request
                  </button>
                </div>
              </div>
            </div>
          </div>
          
        </div>
      </>
    </>
  );
};

const Modal = ({ handleClose, details, umcForm }) => {
  return (
    <div className="modal display-block">
      <section className="modal-main">
        <div className="App">
          <table class="table table-header">
            <thead>
              <tr>
                <th scope="col">UMC No.</th>
                <th scope="col">Source Location</th>
                <th scope="col">Source Plant</th>
                <th scope="col">Source Dept </th>
                <th scope="col">Storage Loction </th>
                <th scope="col">Quantity</th>
                <th scope="col">Uom</th>
                <th scope="col">Category </th>
              </tr>
            </thead>
            <tbody>
              {details.map((item, index) => {
                return (
                  <tr>
                    {/* <td>{details?.destinationStorage}</td>
                <td>{details?.destinationPlant}</td>
                <td>{details?.destinationPlant}</td>
                <td>{details?.quantity}</td>
                <td>{comman.INTRA}</td> */}
                    <td>{item.InputMaterial}</td>
                    <td>{item.LocCd}</td>
                    <td>{item.Werks}</td>
                    <td>{item.DeptDesc}({item.DeptCode})</td>
                    <td>{item.Sloc}</td>
                    <td>{parseFloat(item.AuilpQty)>0?item.AuilpQty: item.AvlStk}</td>
                    <td>{item.Uom}</td>
                    <td>{item.TYP}</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
        <button onClick={handleClose} className="btn btn-dark btn-cls">
          Close
        </button>
      </section>
    </div>
  );
};



export default RaiseRequest;
