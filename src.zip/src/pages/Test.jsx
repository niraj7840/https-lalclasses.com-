import React, { useState } from 'react';

const ApprovalScreen = () => {
  const [selectedOption, setSelectedOption] = useState('');
  const [remarks, setRemarks] = useState('');

  const handleOptionChange = (e) => {
    setSelectedOption(e.target.value);
  };

  const handleRemarksChange = (e) => {
    setRemarks(e.target.value);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    console.log('Selected Option:', selectedOption);
    console.log('Remarks:', remarks);
    // Add your form submission logic here
  };

  return (
    <form onSubmit={handleSubmit}>
      <div>
        <label>
          <input
            type="radio"
            value="Approval"
            checked={selectedOption === 'Approval'}
            onChange={handleOptionChange}
          />
          Approval
        </label>
      </div>
      <div>
        <label>
          <input
            type="radio"
            value="Reject"
            checked={selectedOption === 'Reject'}
            onChange={handleOptionChange}
          />
          Reject
        </label>
      </div>
      <div>
        <label>
          <input
            type="radio"
            value="Return"
            checked={selectedOption === 'Return'}
            onChange={handleOptionChange}
          />
          Return
        </label>
      </div>
      <div>
        <label>
          Remarks:
          <textarea
            value={remarks}
            onChange={handleRemarksChange}
          />
        </label>
      </div>
      <button type="submit">Submit</button>
    </form>
  );
};

export default ApprovalScreen;
