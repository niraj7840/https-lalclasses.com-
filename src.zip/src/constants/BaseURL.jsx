//export const BaseUrl = 'https://dlmstest.corp.tatasteel.com/SISBackend/'
export const BaseUrl =  'http://localhost:54775/'
export const clientUrl = 'http://localhost:3000/SIS/'
//export const clientUrl = 'https://dlmstest.corp.tatasteel.com/SIS/'
export const PUBLIC_KEY = 'MFswDQYJKoZIhvcNAQEBBQADSgAwRwJAew3mrkAG4Qin9CwrElbcr3bfkh0dbRk/c26yw3y/DtLfXDaViZ3xTliXrEmLWuOy63GQXDqA6KPL2JU+FQAMuQIDAQAB'
export const PRIVATE_KEY = 'V4U>rOn:)}16jrQ8'

