import React, { useState } from "react";
import { DateInput } from "react-aria-components";
import "./Modal.css";

import * as moment from "moment";

const RequirmentConsumptionModal = ({
  handleClose,
  requirmentConsumptionData,
  handleCellChange,
  OnDeleteRow,
}) => {
  // const fetchChangeQty=requirmentConsumptionData.ChangedQty;
  console.log(requirmentConsumptionData[0].REQUIREMENT_DATE, "ss");
  const [changedDate, setChangedQty] = useState({});


  const handleCellChanges = (index, field, SysReqDTT, SysConsumDTT,ChangeReqDTT,changeConsumDTT) => {
    handleCellChange(index, field, SysReqDTT, SysConsumDTT,ChangeReqDTT,changeConsumDTT);
  };
  // Helper function to format date to YYYY-MM-DD
  function formatDateToInput(date) {
    const d = new Date(date);
    const month = String(d.getMonth() + 1).padStart(2, "0");
    const day = String(d.getDate()).padStart(2, "0");
    const year = d.getFullYear();
    return `${year}-${month}-${day}`;
  }
  return (
    <div>
      <div
        className="modal display-block"
        id="MyModal"
        tabindex="-1"
        aria-labelledby="exampleModalLabel"
        aria-hidden="true"
        
      >
        <div class="modal-dialog modal-xl">
          <div class="modal-content" >
            <div class="modal-header">
              <h5 class="modal-title" id="exampleModalLabel">
                Requirement & Consumption date check
              </h5>
              <button
                onClick={handleClose}
                type="button"
                class="btn-close"
                data-bs-dismiss="modal"
                aria-label="Close"
              ></button>
            </div>
            <div class="modal-body">
              <div className="table-responsive" style={{overflowX:"auto",maxHeight:"600px"}}>
                <table
                  className="tables">
                  <thead
                    className="table-primary"
                    style={{ whiteSpace: "nowrap" }}
                  >
                    <tr>
                      <th>Sl No</th>
                      <th>UMC No</th>
                      <th>Description</th>
                      {/* <th>Tagged UMC</th> */}
                      <th>Sys Requi Dt</th>
                      <th>Sys Consum Dt</th>

                      <th>Indent Requi Dt</th>
                      <th>Indent Consum Dt</th>
                      <th >Smart Nudges</th>
                      <th>Status</th>
                      <th >User Justification</th>
                      <th>Action</th>
                    </tr>
                  </thead>
                  <tbody style={{whiteSpace:"nowrap"}}>
                    {requirmentConsumptionData
                      .filter((item) => item.ISACTIVE === "Y")
                      .map((row, index) => (
                        <tr key={index}>
                          <td>{row.SRNO}</td>
                          <td>{row.REQ_UMC_NO}</td>
                          <td>{row.REQ_UMC_DESC}</td>
                          {/* <td>{row.TaggedUMC}</td> */}
                          <td>{moment(row.ReqDate).format("DD/MM/YYYY")}</td>
                          <td>
                            {row.ConsDate
                              ? moment(row.ConsDate).format("DD/MM/YYYY")
                              : ""}
                          </td>
                          <td>
                            <input
                              value={
                                row.REQUIREMENT_DATE
                                  ? moment(row.REQUIREMENT_DATE).format(
                                      "YYYY-MM-DD"
                                    )
                                  : ""
                              } // Convert to 'YYYY-MM-DD' format
                              style={{ height: "41px !important" }}
                              name={`changeqtys_${row.SLNo}`}
                              type="date"
                              className="form-control"
                              onChange={(event) =>
                                handleCellChanges(
                                  index,
                                  "REQUIREMENT_DATE",
                                  row.ReqDate,row.ConsDate,event.target.value,row.CONSUMP_DT
                                )                              
                              }
                            />
                          </td>

                          <td>
                            <input
                              value={
                                row.CONSUMP_DT
                                  ? moment(row.CONSUMP_DT).format("YYYY-MM-DD")
                                  : ""
                              } // Convert to 'YYYY-MM-DD' format
                              style={{ height: "41px !important" }}
                              name={`changeqtys_${row.SLNo}`}
                              type="date"
                              className="form-control"
                              onChange={(event) =>
                                handleCellChanges(
                                  index,
                                  "CONSUMP_DT",                                 
                                  row.ReqDate,row.ConsDate,row.REQUIREMENT_DATE, event.target.value
                                )
                              }
                             
                            />
                          </td>
                          <td
                            style={{ padding:"0px",margin:"0px",
                              backgroundColor:
                              row.RCM_CHECKS_Status === false ? "orange" : "",
                                
                                 fontSize: "12px"
                            }}
                          >
                            { row.RCM_CHECKS_Status === false
                              ? <p>Please amend your requirement date as per the requirement date recommended by the system;<br/> however if you want to proceed this indent/ shopping cart will be escalated to Area Chief for approval.</p>
                              : ""}
                          </td>
                          <td
                            style={{
                              backgroundColor: 
                              row.RCM_CHECKS_Status === false ? "red" : "green",                         
                            }}
                          ></td>
                          <td >
                            <textarea rows="1" style={{width:"300px"}} type="text" className="form-control form-control-sm" />
                          </td>
                          <td>
                            {" "}
                            <button
                              onClick={() => {
                                OnDeleteRow(row.UMC_INDENT_ID);
                              }}
                              style={{
                                width: "25px",
                                height: "25px",
                                padding: "0px",
                              }}
                              class="btn btn-danger btn-sm"
                              type="button"
                              data-toggle="tooltip"
                              data-placement="top"
                              title="Delete"
                            >
                              <i class="fa fa-trash"></i>
                            </button>
                          </td>
                        </tr>
                      ))}
                  </tbody>
                </table>
              </div>
            </div>
            <div class="modal-footer ml-0">
              <span
                className="me-auto"
                style={{
                  color: "orangered",
                  marginLeft: "0px",
                  whiteSpace: "pre-line",
                }}
              >
                <b>Escalate when </b>
                <br></br>
                User Requirement Date - System requirement date is &gt;=3 months
                <br></br>
                User Requirement Date - System requirement date &lt; = 0.
              </span>
              {/* <button type="button" class="btn btn-primary">
                Save
              </button> */}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default RequirmentConsumptionModal;
