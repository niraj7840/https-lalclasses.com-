import React, { useState } from "react";
import "./Modal.css";

const VMIModal = ({ handleClose, VMIData, OnDeleteRow }) => {
  return (
    <div>
      <div
        className="modal display-block"
        id="MyModal"
        tabindex="-1"
        aria-labelledby="exampleModalLabel"
        aria-hidden="true"
      >
         <div class="modal-dialog modal-xl">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title" id="exampleModalLabel">
                VMI Check
              </h5>
              <button
                onClick={handleClose}
                type="button"
                class="btn-close"
                data-bs-dismiss="modal"
                aria-label="Close"
              ></button>
            </div>
            <div class="modal-body">
            <div className="table-responsive table-responsive-sm">
                <table className="tables table-bordered tb" style={{overflowX:"auto",maxHeight:"600px"}}>
                <thead className="table-primary">
                  <tr>
                    <th> Sl No</th>
                    <th>UMC No</th>
                    <th> Description </th>
                    <th> Past / Current ARC</th>
                    <th > Smart Nudges</th>
                    <th> Status </th>
                    <th> Delete</th>
                  </tr>
                </thead>
                <tbody style={{ whiteSpace: "nowrap" }}>
                  {" "}
                  {VMIData.filter((item) => item.ISACTIVE === "Y").map(
                    (row, index) => (
                      <tr key={index}>
                       <td>{row.SRNO}</td>
                        <td>{row.REQ_UMC_NO}</td>
                        <td>{row.REQ_UMC_DESC}</td>
                        <td>{row.ARC_VMI ==="FALSE" ? "Pass" : "Fail"}</td>
                        <td
                           style={{
                            backgroundColor: row.ARC_VMI ==="FALSE" ? "" : "orange",fontSize:"12px", padding: "0px",whiteSpace: "normal",
                            margin: "0px"
                          }}
                        >
                         {row.ARC_VMI ==="FALSE" ? "" : "This UMC (Spare/Item) is either fast moving or is procured through ARC/VMI route at your location; so you are suggested to procure it through ARC/VMI by taking necessary actions."}
                        </td>
                        <td
                          style={{
                            backgroundColor: row.ARC_VMI ==="FALSE" ? "green" : "red",
                          }}
                        ></td>
                        <td>
                          {" "}
                          <button
                            onClick={() => {
                              OnDeleteRow(row.UMC_INDENT_ID);
                            }}
                            style={{
                              width: "25px",
                              height: "25px",
                              padding: "0px",
                            }}
                            class="btn btn-danger btn-sm"
                            type="button"
                            data-toggle="tooltip"
                            data-placement="top"
                            title="Delete"
                          >
                            <i class="fa fa-trash"></i>
                          </button>
                        </td>
                      </tr>
                    )
                  )}
                </tbody>
              </table>
            </div>
            </div>
            <div class="modal-footer ml-0">
              <span
                className="me-auto"
                style={{ color: "orangered", marginLeft: "0px" }}
              >
                Parallel/Past ARCs for same UMC (Tagged UMCs) for a location or
                GI &gt;=2/yr (past 3 years 6 consumption), multiple PRs in the
                last 6 months.Also, GI&gt;8/2 year and usage in 2 or more depts
              </span>
              {/* <button type="button" class="btn btn-primary">Save</button> */}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default VMIModal;
