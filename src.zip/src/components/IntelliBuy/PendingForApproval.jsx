import React, { useState } from "react";
import { Link } from "react-router-dom";
import Navbar from "../components/Navbar/Navbar";
import Tabs from 'react-bootstrap/Tabs';
import Tab from 'react-bootstrap/Tab';

const PendingForApproval = () => {
  const data = [
    { requestNo: 1234, indentNo: 11223344, department: 164, indentValue: 50, justification: 'Yes', requestDate: '10-06-2024' },
    { requestNo: 2345, indentNo: 123456, department: 164, indentValue: 60, justification: 'Yes', requestDate: '10-06-2024' }
  ];

  const [data2] = useState([
    { id: 1, name: 'Item 1' },
    { id: 2, name: 'Item 2' },
    { id: 3, name: 'Item 3' },
  ]);

  return (
    <div>
      <Navbar />
      <div className="container" style={{ marginTop: "8px", marginLeft: "0px", maxWidth: "100%" }}>
        <div className="card">
          <div className="card-heading" style={{ backgroundColor: "lightgray", height: "44px" }}>
            <h4 className="mt-2">
              {" "}
              &nbsp;&nbsp;<i className="fas fa-copy text-info"></i>&nbsp;Pending For My Approval
            </h4>
          </div>

          <div className="card-body">
            {/* ----------Start Nav Tab---------- */}
            <div className="col-12">
              <Tabs defaultActiveKey="SSA" id="uncontrolled-tab-example" className="my-tab position-relative">
            
                <Tab eventKey="SSA" title={
                    <div>
                    Spare Sharing Approval <span className="badge bg-secondary">2</span>
                  </div>
                  }  className="tab-txt-clr act-clr" >
               
                  <br />

                  <p style={{ textAlign: "center" }}>
                    <button type="button" class="btn btn-secondary">Pending Approval</button>
                    &nbsp;&nbsp;<button type="button" class="btn btn-success">Complete Approval</button>
                  </p>
                  <table className="table table-bordered">
                    <thead className="table-primary">

                      <tr>
                        <th></th>
                        <th>Request No.</th>
                        <th>Indent No.</th>
                        <th>Department</th>
                        <th>Indent Value</th>
                        <th>Intelliby Check Validation Justification</th>
                        <th>Request Date</th>
                      </tr>
                    </thead>
                    <tbody>
                      {data.map((item, index) => (
                        <tr key={index}>
                          <td><input type="checkbox" /></td>
                          <td><Link to={`/detail/${item.requestNo}`}>{item.requestNo}</Link></td>
                          <td>{item.indentNo}</td>
                          <td>{item.department}</td>
                          <td>{item.indentValue}</td>
                          <td>{item.justification}</td>
                          <td>{item.requestDate}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                  <p style={{ float: "right" }}>
                    <button type="button" className="btn btn-primary">Approve</button>
                  </p>

                </Tab>
                <Tab eventKey="CRA" title={
                    <div>
                    Capital Request Approval <span className="badge bg-secondary">3</span>
                  </div>
                  }               
                className="tab-txt-clr act-clr">
                  <div>
                    <br />
                    <p style={{ textAlign: "center" }}>
                      <button type="button" class="btn btn-secondary">Pending Approval</button>
                      &nbsp;&nbsp;<button type="button" class="btn btn-success">Complete Approval</button>
                    </p>
                    <table className="table table-bordered">
                      <thead className="table-primary">


                        <tr>
                          <th></th>
                          <th>ID</th>
                          <th>Name</th>
                        </tr>
                      </thead>
                      <tbody>
                        {data2.map(item => (
                          <tr key={item.id}>
                            <td><input type="checkbox" /></td>
                            <td><Link to={`/detail/${item.id}`}>{item.id}</Link></td>
                            <td>{item.name}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                    <p style={{ float: "right" }}>
                      <button type="button" className="btn btn-primary">Approve</button>
                    </p>
                  </div>
                </Tab>
                <Tab eventKey="IBCA" 
                title={
                  <div>
                  Intelli By Check Approval <span className="badge bg-secondary">5</span>
                </div>
                }               
              
                className="tab-txt-clr act-clr">
                <div>
                    <br />
                    <p style={{ textAlign: "center" }}>
                      <button type="button" class="btn btn-secondary">Pending Approval</button>
                      &nbsp;&nbsp;<button type="button" class="btn btn-success">Complete Approval</button>
                    </p>
                    <table className="table table-bordered">
                      <thead className="table-primary">
                        <tr>
                          <th></th>
                          <th>ID</th>
                          <th>Name</th>
                        </tr>
                      </thead>
                      <tbody>
                        {data2.map(item => (
                          <tr key={item.id}>
                            <td><input type="checkbox" /></td>
                            <td><Link to={`/detail/${item.id}`}>{item.id}</Link></td>
                            <td>{item.name}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                    <p style={{ float: "right" }}>
                      <button type="button" className="btn btn-primary">Approve</button>
                    </p>
                  </div>
                </Tab>
                <Tab eventKey="SCA" 
                title={
                  <div>
                  Shopping Cart Approval <span className="badge bg-secondary">2</span>
                </div>
                }    
                className="tab-txt-clr act-clr">
                <div>
                    <br />
                    <p style={{ textAlign: "center" }}>
                      <button type="button" class="btn btn-secondary">Pending Approval</button>
                      &nbsp;&nbsp;<button type="button" class="btn btn-success">Complete Approval</button>
                    </p>
                    <table className="table table-bordered">
                      <thead className="table-primary">
                        <tr>
                          <th></th>
                          <th>ID</th>
                          <th>Name</th>
                        </tr>
                      </thead>
                      <tbody>
                        {data2.map(item => (
                          <tr key={item.id}>
                            <td><input type="checkbox" /></td>
                            <td><Link to={`/detail/${item.id}`}>{item.id}</Link></td>
                            <td>{item.name}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                    <p style={{ float: "right" }}>
                      <button type="button" className="btn btn-primary">Approve</button>
                    </p>
                  </div>
                </Tab>
              </Tabs>
            </div>
            {/*----End Nav Tab-----*/}
          </div>
        </div>
      </div>
    </div>
  );
};

export default PendingForApproval;
