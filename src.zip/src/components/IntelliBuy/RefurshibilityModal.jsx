import React, { useState } from "react";
import "./Modal.css";
const RefurshibilityModal = ({
  handleClose,
  details,
  requirmentConsumptionData,
  handleDeleteRows,
}) => {
  // const fetchChangeQty=requirmentConsumptionData.ChangedQty;
  console.log(
    requirmentConsumptionData[0].IS_REFURBISHABLE,
    "IS_REFURBISHABLE"
  );
  const [changedDate, setChangedQty] = useState({});

  const handleDeleteRow = (SLNo) => {
    handleDeleteRows(SLNo);
  };
  const handleCellChange = (id, value) => {
    console.log(id, value, "Test");
    setChangedQty((prevState) => ({
      ...prevState,
      [id]: value,
    }));
  };

  return (
    <div>
      <div
        className="modal display-block"
        id="MyModal"
        tabindex="-1"
        aria-labelledby="exampleModalLabel"
        aria-hidden="true"
      >
        <div class="modal-dialog modal-xl" >
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title" id="exampleModalLabel">
                Refurshibility Check
              </h5>
              <button
                onClick={handleClose}
                type="button"
                class="btn-close"
                data-bs-dismiss="modal"
                aria-label="Close"
              ></button>
            </div>
            <div class="modal-body ">
              <div className="table-responsive table-responsive-sm" style={{overflowX:"auto",maxHeight:"600px"}}>
                <table className="tables table-bordered tb">
                  <thead className="table-primary">
                    <tr>
                      <th> Sl No</th>
                      <th>UMC No</th>
                      <th> Description </th>
                      <th> Refurbishable  /Non Refurbishable  </th>
                      <th > Smart Nudges</th>
                      <th> Status </th>
                      <th> Delete</th>
                    </tr>
                  </thead>
                  <tbody style={{ padding: "0px",whiteSpace:"nowrap" }}>
                    {requirmentConsumptionData.map((row, index) => (
                      <tr key={index}>
                       <td>{row.SRNO}</td>
                        <td>{row.REQ_UMC_NO}</td>
                        <td>{row.REQ_UMC_DESC}</td>
                        <td>
                          {row.IS_REFURBISHABLE === "R"
                            ? "Refurbishable  "
                            : row.IS_REFURBISHABLE === "N"
                            ? "Non Refurbishable  "
                            : row.IS_REFURBISHABLE}
                        </td>
                        <td
                          style={{
                            backgroundColor:
                              row.IS_REFURBISHABLE === "R" ? "orange" : "",
                            padding: "0px",
                            margin: "0px",fontSize:"12px",whiteSpace: "normal"
                          }}
                        >
                          {row.IS_REFURBISHABLE === "R"
                            ? "This UMC (Spare/item) is refurbishable in nature; however, indenter/dept. is trying to procure a new one; requesting you to review the requirement."
                            : row.IS_REFURBISHABLE === "N"
                            ? ""
                            : row.IS_REFURBISHABLE}
                        </td>
                        <td
                          style={{
                            backgroundColor:
                              row.IS_REFURBISHABLE != "R" ? "green" : "red",
                            padding: "0px",
                          }}
                        ></td>
                        <td>
                          {" "}
                          <button
                            onClick={() => {
                              handleDeleteRow(row.SLNo);
                            }}
                            style={{
                              width: "25px",
                              height: "25px",
                              padding: "0px",
                            }}
                            class="btn btn-danger btn-sm"
                            type="button"
                            data-toggle="tooltip"
                            data-placement="top"
                            title="Delete"
                          >
                            <i class="fa fa-trash"></i>
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default RefurshibilityModal;
