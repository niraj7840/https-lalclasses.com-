import React from "react";
import { FaSearch } from "react-icons/fa";
import "./SearchBar.css";
import {LocalUrl,BaseUrl} from '../../constants/BaseURL'

const SearchBar = ({setResults,input,setInput}) => {
  
  const fetchData =  (value) => {
     fetch(`${BaseUrl}api/Master/GetMaterial?adid=163402`).then((response) =>
      response.json().then((json) => {
        const results = json.filter((material) => {
          return (
            value &&
            material &&
            (material.umcno && material.umcno.toString().includes(value))
          );
        });
        setResults(results);
      })
    );
  };

  const handleChange = (value) => {
    setInput(value);
    if(value.length >= 3){
      fetchData(value);
    }
    else{
      setResults([])
    }
    
  };
  return (
    <div className="input-wrapper">
      <FaSearch id="search_icon" />
      <input
        placeholder="Enter Material name or UMC No"
        type="text"
        value={input}
        onChange={(e) => {
          handleChange(e.target.value);
        }}
      />
    </div>
  );
};

export default SearchBar;
