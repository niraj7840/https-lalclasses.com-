import React, { useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { FaHome } from "react-icons/fa";
import { NavLink } from "react-router-dom";
import { FaRegSquarePlus } from "react-icons/fa6";
import tataLogo from "../../Data/IMG/tata_logo.png";
import tataSteelLogo from "../../Data/IMG/tata-steel-logo.png";
import { useSelector, useDispatch } from "react-redux";
import { FaBars } from "react-icons/fa";
import { isOpen } from "../../store/menuSlice";
import { GrStatusInfo } from "react-icons/gr";
import { MdCallToAction } from "react-icons/md";
import { Tooltip } from 'react-tooltip';
import "react-tooltip/dist/react-tooltip.css"; // Ensure CSS is imported
import { RiAddBoxFill } from "react-icons/ri";
import { CiViewBoard } from "react-icons/ci";
import { SiTicktick } from "react-icons/si";
import { FaSearch } from "react-icons/fa";
import "./Menu.css";


const routes = [
    {
        path: "/SIS/",
        name: "Home Page",
        icon: <FaHome />,
        tooltip: "Go to Home Page"
    },
    // {
    //     path: "/SIS/SmartIndenting",
    //     name: "Smart Indenting",
    //     icon: <FaRegSquarePlus />,
    //     tooltip: "Master Page of Smart Indenting Page"
    // },
    
    {
        path: "/SIS/RaiseIndent",
        name: "Raise Indent",
        icon: <FaRegSquarePlus />,
        tooltip: "Raise Indent"
    },
    {
        path: "/SIS/SearchIndent",
        name: "Search Indent",
        icon: <FaSearch />,
    },
    {
        path: "/SIS/MyAction",
        name: "My Action",
        icon: <MdCallToAction />,
        tooltip: "View my actions"
    },
    {
        path: "/SIS/CapitalRequest",
        name: "Raise Cap Req",
        icon: <RiAddBoxFill />,
    },
    {
        path: "/SIS/ViewCapitalRequest",
        name: "ViewCapReq",
        icon: <CiViewBoard />,
    },
    {
        path: "/SIS/CapApprovalScreen",
        name: "Cap Req Approval",
        icon: <SiTicktick />,
    }

    // {
    //   path: "/SIS/IntentUmcCapStatus",
    //   name: "IndentUMCStatus",
    //   icon: <SiTicktick />,
    // }
    // {
    //     path: "/SIS/IntelliBuySystemChecks",
    //     name: "IntelliBuySystemChecks",
    //     icon: <FaRegSquarePlus />,
    // }
];

const Menu = ({ children }) => {
    const dispatch = useDispatch();
    const isAuthenticated = true;
    const open = useSelector((state) => state.menu.status);
    const [hover, setHover] = useState(false);

    const toggle = () => {
        dispatch(isOpen());
    };

    const handleMouseEnter = () => {
        setHover(true);
        if (!open) {
            dispatch(isOpen());
        }
    };

    const handleMouseLeave = () => {
        setHover(false);
        if (open) {
            dispatch(isOpen());
        }
    };

    const showAnimation = {
        hidden: {
            width: 0,
            opacity: 0,
            transition: {
                duration: 0.5,
            },
        },
        show: {
            width: "auto",
            opacity: 1,
            transition: {
                duration: 0.2,
            },
        },
    };

    return (
        <div className="main-container">
            {isAuthenticated && (<motion.div
                animate={{
                    width: open ? "240px" : "60px",
                    transition: {
                        duration: 0.5,
                        type: "spring",
                        damping: 11,
                    },
                }}
                className="menu"
                onMouseEnter={handleMouseEnter}
                onMouseLeave={handleMouseLeave}
            >
                <div className="top_section">
                    <div className="tata_logo">
                        <img src={tataLogo} alt="Tata Logo" />
                    </div>
                    <AnimatePresence>
                        {open && (
                            <motion.h1
                                className="tata_steel_logo"
                                variants={showAnimation}
                                initial="hidden"
                                animate="show"
                                exit="hidden"
                            >
                                <img src={tataSteelLogo} alt="Tata Steel Logo" />
                            </motion.h1>
                        )}
                    </AnimatePresence>
                </div>

                <section className="routes">
                    <div
                        style={{ marginLeft: open ? "200px" : "20px" }}
                        className="fabar"
                        onClick={toggle}
                    >
                        <FaBars />
                    </div>
                    {routes.map((route) => (
                        <NavLink
                            activeclassname="active"
                            to={route.path}
                            key={route.name}
                            className="link"
                        //  data-tooltip-id={`tooltip-${route.name}`}
                        //  data-tooltip-content={route.tooltip}
                        >
                            <div className="icon">{route.icon}</div>
                            <AnimatePresence>
                                {open && (
                                    <motion.div
                                        variants={showAnimation}
                                        initial="hidden"
                                        animate="show"
                                        exit="hidden"
                                        className="link-text"
                                    >
                                        {route.name}
                                    </motion.div>
                                )}
                            </AnimatePresence>
                            <Tooltip id={`tooltip-${route.name}`} />
                        </NavLink>
                    ))}
                </section>
            </motion.div>)}
            <main>{children}</main>
        </div>
    );
};

export default Menu;
