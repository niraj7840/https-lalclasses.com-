import React from "react";
import "./UMCDetails.css";

const UMCDetails = ({
  results,
  selectedMaterialArray,
  umcForm,
  setUmcForm,
 setInput
}) => {
   const handleClick = (result) => {
    const existingMaterial = selectedMaterialArray.find(
      (item) => item.umcNo === result.umcno
    );
    if(!existingMaterial){
    setUmcForm({
      ...umcForm,
      umcNo : result.umcno,
      materialDescription : result.materialDescription,
      unitOfMeasurement : result.unitOfMeasure,
    })

    setInput(result.umcno)
  }                  
    else{
      alert("This material is already added")
    }
   }
  return (
    <div className="results-list">
      {results.map((result, id) => (
        <div key={id} className="result-item" onClick={()=>handleClick(result)} >
             {result.umcno} - {result.materialDescription}
        </div>
      ))}
    </div>
  );
};

export default UMCDetails;

