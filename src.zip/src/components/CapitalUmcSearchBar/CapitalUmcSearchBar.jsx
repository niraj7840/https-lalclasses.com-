import React, { useState, useEffect, useRef } from 'react';
import axios from 'axios';
import './CapitalUmcSearchBar.css';
import { FaSearch } from "react-icons/fa";
import 'bootstrap/dist/css/bootstrap.css';
import { color } from 'framer-motion';
import { BaseUrl } from '../../constants/BaseURL';

const CapitalUmcSearchBar = ({ capitalForm, setCapitalForm, formNumber }) => {
  const [filteredSuggestions, setFilteredSuggestions] = useState([]);
  const [activeSuggestionIndex, setActiveSuggestionIndex] = useState(0);
  const [showSuggestions, setShowSuggestions] = useState(false);
  const [userInput, setUserInput] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const isSelectingRef = useRef(false); // Use ref to track selection state

  const fetchSuggestions = async (query) => {
    setIsLoading(true);
    try {
      const response = await axios.get(`${BaseUrl}api/Master/GetMaterial?Plant=082`);
      const suggestions = response.data.filter(item => item.umcno.toString().toLowerCase().includes(query.toLowerCase())
       || item.materialDescription.toString().toLowerCase().includes(query.toLowerCase())).map(item => ({
        umcno: item.umcno,
        materialDescription: item.materialDescription,
        suggestionText: `${item.umcno} - ${item.materialDescription}`,
        unitOfMeasure: item.unitOfMeasure,
        currency:item.currency,
        materialBGG:item.materialBGG
      }));
      setFilteredSuggestions(suggestions);
    } catch (error) {
      console.error('Error fetching suggestions:', error);
      setFilteredSuggestions([]);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    if (!isSelectingRef.current && userInput.length > 3) {
      fetchSuggestions(userInput);
      setShowSuggestions(true);
    } else {
      setShowSuggestions(false);
      setFilteredSuggestions([]);
    }
  }, [userInput]);

  const handleChange = (e) => {
    setUserInput(e.currentTarget.value);
    isSelectingRef.current = false; // Reset selection flag on input change
  };

  const handleClick = (suggestion) => {
    setUserInput(suggestion.suggestionText);
    setShowSuggestions(false);
    setFilteredSuggestions([]);
    isSelectingRef.current = true; // Set selection flag on suggestion click

    console.log(suggestion.umcno)
    const updatedForms = [...capitalForm];
    updatedForms[formNumber].UmcNumber = suggestion.umcno;
    setCapitalForm(updatedForms)
    console.log("capitalform", capitalForm)

  };

  const handleKeyDown = (e) => {
    if (e.keyCode === 13) { // Enter key
      const selectedSuggestion = filteredSuggestions[activeSuggestionIndex];
      handleClick(selectedSuggestion);
      setUserInput(selectedSuggestion.suggestionText);
      setShowSuggestions(false);
      setActiveSuggestionIndex(0);
      isSelectingRef.current = true; // Set selection flag on enter key



    } else if (e.keyCode === 38) { // Up arrow
      if (activeSuggestionIndex > 0) {
        setActiveSuggestionIndex(activeSuggestionIndex - 1);
      }
    } else if (e.keyCode === 40) { // Down arrow
      if (activeSuggestionIndex < filteredSuggestions.length - 1) {
        setActiveSuggestionIndex(activeSuggestionIndex + 1);
      }
    }
  };

  const suggestionsListComponent = () => {
    if (showSuggestions && userInput) {
      if (filteredSuggestions.length) {
        return (
          <ul className="suggestions1">
            {filteredSuggestions.map((suggestion, index) => {
              let className;
              if (index === activeSuggestionIndex) {
                className = "suggestion-active";
              }
              return (
                <li
                  className={className}
                  key={index}
                  onClick={() => handleClick(suggestion)}
                >
                  {suggestion.suggestionText}
                </li>
              );
            })}
          </ul>
        );
      } else {
        return (
          <div className="no-suggestions">
            {/* <em>No suggestions available.</em> */}
          </div>
        );
      }
    }
    return null;
  };

  return (
    <div> 

      <div class="form-group has-search">
        <span class="fas fa-search form-control-feedback"></span>




        <input
          type="text" class="form-control" placeholder="Search"
          onChange={handleChange}
          onKeyDown={handleKeyDown}
          value={userInput}
          
        />

        {isLoading && <div>Loading...</div>}
        {suggestionsListComponent()}
      </div>
    </div>
  );
};

export default CapitalUmcSearchBar;