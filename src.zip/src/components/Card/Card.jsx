import React from 'react'
//import "./Card.css"
import { cardsData } from "../../Data/Data"
import Cards from '../Cards/Cards'
 
 
const Card = () => {
    return (
        <div className="row" style={{width:'100%'}}>
            {cardsData.map((card, id) => {
                return (
                    <div className="col-md-3" key={id}>
                        <Cards
                            title={card.title}
                            color={card.color}
                            value={card.value}
                            tag={card.tag}
                            colorForButton={card.colorForButon}
                            iconForCard={card.iconForCard}
                        />
                    </div>
                );
            })}
        </div>
 
    )
}
 
export default Card