import React, { useState, useEffect, useRef } from 'react';
import axios from 'axios';
import './Autocomplete.css';
import 'bootstrap/dist/css/bootstrap.css';
import { BaseUrl } from '../../constants/BaseURL';
import Swal from 'sweetalert2';
import $ from 'jquery';
import { useSelector } from 'react-redux';
 
const Autocomplete = ({ umcForm, setUmcForm, selectedMaterialArray,userInput,setUserInput,showLoader,hideLoader}) => {
  const [filteredSuggestions, setFilteredSuggestions] = useState([]);
  const [UMClist, setUMClist] = useState([]);
  const [activeSuggestionIndex, setActiveSuggestionIndex] = useState(0);
  const [showSuggestions, setShowSuggestions] = useState(false);
  const user = useSelector((state) => JSON.parse(state.auth.userData));
  const [isLoading, setIsLoading] = useState(false);
  const isSelectingRef = useRef(false); // Use ref to track selection state
  const destinationPlant= sessionStorage.getItem("DeptList")==null?"": sessionStorage.getItem("Plant");
  const fetchUMC = async (query) => {
    
    try {
     
      const response = await axios.get(`${BaseUrl}api/Master/GetMaterial?Plant=${destinationPlant}`);
      setUMClist(response.data);
     
    } catch (error) {
      hideLoader();
      console.error('Error fetching suggestions:', error);
     
    } finally {
     
    }
  };
  const fetchSuggestions = async (query) => {
    setIsLoading(true);
    try {
      const suggestions = UMClist.filter(item => item.umcno.toString().toLowerCase().includes(query.toLowerCase()) || item.materialDescription.toString().toLowerCase().includes(query.toLowerCase())).map(item => ({        
        umcno: item.umcno,
        materialDescription: item.materialDescription,
        suggestionText: `${item.umcno} - ${item.materialDescription}`,
        unitOfMeasure: item.unitOfMeasure,
        materialBGG:item.materialBGG,
        currency:item.currency
      }));
      setFilteredSuggestions(suggestions);
    } catch (error) {
      console.error('Error fetching suggestions:', error);
      setFilteredSuggestions([]);
    } finally {
      setIsLoading(false);
    }
  };
  useEffect(() => {
   fetchUMC();
  }, [UMClist]);
  useEffect(() => {
    if (!isSelectingRef.current && userInput.length >= 3) {
      fetchSuggestions(userInput);
      setShowSuggestions(true);
    } else {
      setShowSuggestions(false);
      setFilteredSuggestions([]);
    }
  }, [userInput]);
 
  const handleChange = (e) => {
    setUserInput(e.currentTarget.value);
    isSelectingRef.current = false; // Reset selection flag on input change
  };
 
  const handleClick = (suggestion) => {
    setUserInput(suggestion.suggestionText);
    setShowSuggestions(false);
    setFilteredSuggestions([]);
    isSelectingRef.current = true; // Set selection flag on suggestion click
 
    const existingMaterial = selectedMaterialArray.find(
      (item) => item.umcNo === suggestion.umcno
      
      
    );
    if (!existingMaterial) {
      setUmcForm({
        ...umcForm,
        umcNo: suggestion.umcno,
        materialDescription: suggestion.materialDescription,
        unitOfMeasurement: suggestion.unitOfMeasure,
        materialBGG:suggestion.materialBGG,
        currency:suggestion.currency
      });
    }
    else{
      setUserInput("");
      Swal.fire('','UMC already added','info');
      return;
    }
  };
 
  const handleKeyDown = (e) => {
    if (e.keyCode === 13) { // Enter key
      const selectedSuggestion = filteredSuggestions[activeSuggestionIndex];
      setUserInput(selectedSuggestion.suggestionText);
      setShowSuggestions(false);
      setActiveSuggestionIndex(0);
      isSelectingRef.current = true; // Set selection flag on enter key
 
      const existingMaterial = selectedMaterialArray.find(
        (item) => item.umcNo === selectedSuggestion.umcno
      );
      if (!existingMaterial) {
        setUmcForm({
          ...umcForm,
          umcNo: selectedSuggestion.umcno,
          materialDescription: selectedSuggestion.materialDescription,
          unitOfMeasurement: selectedSuggestion.unitOfMeasure,
          materialBGG:selectedSuggestion.materialBGG,
        currency:selectedSuggestion.currency
        });
      }
      else{
        setUserInput("");
        Swal.fire('','UMC already added','info');
        return;
      }
    } else if (e.keyCode === 38) { // Up arrow
      if (activeSuggestionIndex > 0) {
        setActiveSuggestionIndex(activeSuggestionIndex - 1);
      }
    } else if (e.keyCode === 40) { // Down arrow
      if (activeSuggestionIndex < filteredSuggestions.length - 1) {
        setActiveSuggestionIndex(activeSuggestionIndex + 1);
      }
    }
  };
 
  const suggestionsListComponent = () => {
    if (showSuggestions && userInput) {
      if (filteredSuggestions.length) {
        return (
          <ul className="suggestions">
            {filteredSuggestions.map((suggestion, index) => {
              let className;
              if (index === activeSuggestionIndex) {
                className = "suggestion-active";
              }
              return (
                <li
                  className={className}
                  key={index}
                  onClick={() => handleClick(suggestion)}
                >
                  {suggestion.suggestionText}
                </li>
              );
            })}
          </ul>
        );
      } else {
        return (
          <div className="no-suggestions">
            {/* <em>No suggestions available.</em> */}
          </div>
        );
      }
    }
    return null;
  };
 
  return (
    <div>
       
        <div class="form-group has-search">
    <span class="fas fa-search form-control-feedback"></span>
   
 
 
 
      <input autocomplete="off"
        type="text" class="form-control" placeholder="Search"
        onChange={handleChange}
        onKeyDown={handleKeyDown}
        value={userInput}
        id="umc"
      />
     
      {isLoading && <div>Loading...</div>}
      {suggestionsListComponent()}
    </div>
    </div>
  );
};
 
export default Autocomplete;