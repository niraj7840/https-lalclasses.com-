import React from 'react'
import "./Cards.css"
import { FaArrowCircleRight } from "react-icons/fa";
 
const Cards = (props) => {
 
    const handleClick = () => {
        return console.log("clicked")
    }
 
    return (
        <div className='CompactCard'
            style={
                {
                    background: props.color.backGround,
                    boxShadow: props.color.boxShadow
 
                }
            }>
 
            <div className='headingAndIcon'>
                <div className='headingContainer'>
                    <div className='heading1'>
                        <span className='ValueOfNumber'>{props.value}</span>
                        <span>{props.tag}</span>
                    </div>
                    <div className='description'>{props.title}</div>
                    
                </div>
                <div className='iconForCard'>{props.iconForCard}</div>
            </div>
            <div className='knowMore' onClick={handleClick}
                style={
                    {
                        background: props.colorForButton.backGround
                    }
                }>know more
                <span className='arrowIcon'><FaArrowCircleRight /></span>
            </div>
 
 
        </div>
    )
}
 
export default Cards