import React from "react";
import { useSelector } from "react-redux";
import "./TabMenu.css";

const TabMenu = ({ prop, onTabSelect, indentStatus, dept }) => {
  const indentId = useSelector((state) =>
    state.indent ? state.indent.indentId : ""
  );

  const tabNames = {
    IndentStatus: "Spares Sharing",
    IntentUmcCapStatus: "Capital Planning",
    IntelliBuySystemChecks: "Intellibuy",
    ShoppingCart: "Shopping Cart",
  };

  const getStatusClass = (tabName) => {
    switch (indentStatus) {
      case "Pending for AIULP Spare sharing":
      case "Pending for INTRA Spare sharing":
      case "Pending for INTER Spare sharing":
        if (tabName === "IndentStatus") return "yellow";
        if (tabName === "IntentUmcCapStatus" || tabName === "IntelliBuySystemChecks" || tabName === "ShoppingCart") return "disabled blue";
        break;
      case "Pending for Capex Approval":
        if (tabName === "IntentUmcCapStatus") return "yellow";
        if (tabName === "IndentStatus") return "green";
        if (tabName === "IntelliBuySystemChecks" || tabName === "ShoppingCart") return "disabled blue";
        break
      case "Pending for Intellibuy Check":
        if (tabName === "IntelliBuySystemChecks") return "yellow";
        if (tabName === "IndentStatus" || tabName === "IntentUmcCapStatus") return "green";
        if (tabName === "ShoppingCart") return "disabled blue";
        break;
        case "Pending for Shopping Cart Creation":
        if (tabName === "ShoppingCart") return "yellow";
        if (tabName === "IndentStatus" || tabName === "IntentUmcCapStatus" || tabName === "IntelliBuySystemChecks") return "green";
        //if (tabName === "ShoppingCart") return "disabled blue";
        break;
      default:
        return "";
    }
  };

  return (
    <div>
      <div style={{ margin: "2% 2% 0% 2%" }}>
        <div className="arrow-steps clearfix">
          {Object.keys(tabNames).map((tab) => (
            <div
              key={tab}
              className={`step ${prop === tab ? "current" : ""} ${getStatusClass(tab)}`}
              onClick={() => getStatusClass(tab).includes("disabled") ? null : onTabSelect(tab)}
            >
              <span>{tabNames[tab]}</span>
            </div>
          ))}
        </div>
        <br />
      </div>
      <div id="box">
        <div className="row" id="row1">
          <div className="col-md-3">
            <h6>
              <b>
                Indent Number :
                <span style={{ color: "blue" }}>
                  <b> &nbsp;{indentId}</b>
                </span>
              </b>
            </h6>
          </div>
          <div className="col-md-4">
            <h6>
              <b>
                Department :
                <span style={{ color: "blue" }}>
                  {/* <b> &nbsp;{tabNames[prop]} </b> */}
                  <b> &nbsp;{dept} </b>
                  
                </span>
              </b>
            </h6>
          </div>

          <div className="col-md-5">
            <h6>
              <b>
                Indent Status :
                <span style={{ color: "blue" }}>
                  {/* <b> &nbsp;{tabNames[prop]} </b> */}
                  <b> &nbsp;{indentStatus} </b>
                  
                </span>
              </b>
            </h6>
          </div>
          
        </div>
      </div>
    </div>
  );
};

export default TabMenu;
