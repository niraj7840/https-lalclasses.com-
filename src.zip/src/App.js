import "./App.css";
import {Routes, Route, useLocation, useNavigate} from "react-router-dom";
import HomePage from "./pages/HomePage";
import RaiseRequest from "./pages/RaiseRequest";
import Menu from "./components/Menu/Menu";
import ApprovalScreen from "./pages/ApprovalScreen";
import MyAction from "./pages/MyAction";
import IndentStatus from "./pages/IndentStatus";
import RaiseCapitalItemRequest from "./pages/RaiseCapitalItemRequest";
import ViewCapitalRequest from "./pages/ViewCapitalRequest";
import CapApprovalScreen from "./pages/CapApprovalScreen";
import { useEffect, useState } from "react";
import IntentUmcCapStatus from "./pages/IntentUmcCapStatus";
import Login from "./pages/Login";
import IntelliBuySystemChecks from "./pages/IntelliBuySystemChecks";
import AuthWrapper from "./AuthWrapper";
import ShoppingCart from "./pages/ShoppingCart";
import axios from "axios";
import { BaseUrl } from "./constants/BaseURL";
import { Navbar } from "react-bootstrap";
import IndentMasterStatus from "./pages/IndentMasterStatus";
import SmartIndenting from "./pages/SmartIndenting";
import PendingForApproval from "./pages/PendingForApproval";



function App() {
const location =useLocation();
const navigate = useNavigate();
  const [isLoading, setIsLoading] = useState(false);
  const [plantList, setPlantList] = useState([]);
  const [deptList, setDeptList] = useState([]);
  const [UserName,setUserName]=useState("163402");
  const [DeptShow, setDeptShow] = useState(false);
  const [selDept, setSelDept] = useState( sessionStorage.getItem("Dept")?sessionStorage.getItem("Dept"):"");
  const [selPlant, setSelPlant] = useState( sessionStorage.getItem("Plant")?sessionStorage.getItem("Plant"):"");
  const showLoader = () => {
    setIsLoading(true);
  };
  useEffect(() => {
   
    fetchDepartmentList();

  }, []);
const handleClose=()=>{
  navigate("/SIS/");
}
  const fetchDepartmentList = async () => {
    try {
      
      const response = await axios.get(`${BaseUrl}api/Master/GetDepartment?adid=${UserName}`);
      const data = response.data;
     
      setDeptList(data);
      setDeptShow(true);
      setIsLoading(false);
      
    } catch (error) {
      console.log(error);
    }
  };
  const hideLoader = () => {
    setIsLoading(false);
  };
  const handleChangeDept = (val) => {
    
    //setUmcForm({
    //  ...umcForm,
    //  "destinationDepartment": val,
   // });
   setSelDept(val.dept);
    setSelPlant(val.plant);
    sessionStorage.setItem("Dept",val.dept);
    sessionStorage.setItem("DeptList",val);
    sessionStorage.setItem("DeptName",val.deptName);
    sessionStorage.setItem("Plant",val.plant);
   
   
    setDeptShow(false);
  };
  return (

    <>{isLoading ? 
      
      <div className="scene">
    <div class="wrapper">
        <div class="circle"></div>
        <div class="circle"></div>
        <div class="circle"></div>
       
        <div class="shadow"></div>
        <div class="shadow"></div>
        <div class="shadow"></div>
        <span >Loading..</span>
    </div>
</div>
:<>{sessionStorage.getItem("DeptList")==null && deptList.length>0 && location.pathname=="/SIS/RaiseIndent" ? 
      
  <DeptModal
  details={deptList}
  handleChangeDept={handleChangeDept}
  handleClose={handleClose}
  
/>
:<></>}</>}

        <Menu>
          <Routes>
          <Route path="/SIS/" element={<AuthWrapper><HomePage showLoader={showLoader} hideLoader={hideLoader}/></AuthWrapper>}/>
          <Route path="/SIS/Approval" element={<AuthWrapper><ApprovalScreen showLoader={showLoader} hideLoader={hideLoader}/></AuthWrapper>}/>
            <Route path="/SIS/MyAction" element={<AuthWrapper><MyAction showLoader={showLoader} hideLoader={hideLoader}/></AuthWrapper>}/>
            <Route path="/SIS/SearchIndent" element={<AuthWrapper><IndentMasterStatus showLoader={showLoader} hideLoader={hideLoader}/></AuthWrapper>}/>
            <Route path="/SIS/CapitalRequest" element={<AuthWrapper><RaiseCapitalItemRequest showLoader={showLoader} hideLoader={hideLoader}/></AuthWrapper>}/>
            <Route path="/SIS/ViewCapitalRequest" element={<AuthWrapper><ViewCapitalRequest showLoader={showLoader} hideLoader={hideLoader}/></AuthWrapper>}/>
            <Route path="/SIS/CapApprovalScreen" element={<AuthWrapper><CapApprovalScreen showLoader={showLoader} hideLoader={hideLoader}/></AuthWrapper>}/>
            <Route path="/SIS/IntentUmcCapStatus" element={<AuthWrapper><IntentUmcCapStatus showLoader={showLoader} hideLoader={hideLoader}/></AuthWrapper>}/>
            <Route path="/SIS/Login" element={<Login showLoader={showLoader} hideLoader={hideLoader}/>}/>
            <Route path="/SIS/IntelliBuySystemChecks" element={<AuthWrapper><IntelliBuySystemChecks showLoader={showLoader} hideLoader={hideLoader} /></AuthWrapper>} />
            <Route path="/SIS/ShoppingCart" element={<AuthWrapper><ShoppingCart showLoader={showLoader} hideLoader={hideLoader} /></AuthWrapper>} />
            <Route path="/SIS/IndentStatus" element={<AuthWrapper><IndentStatus showLoader={showLoader} hideLoader={hideLoader} /></AuthWrapper>} />
            <Route path="/SIS/SmartIndenting" element={<AuthWrapper><SmartIndenting showLoader={showLoader} hideLoader={hideLoader} /></AuthWrapper>} />
            <Route path="/SIS/PendingForApproval" element={<AuthWrapper><PendingForApproval showLoader={showLoader} hideLoader={hideLoader} /></AuthWrapper>} />
          
             {selDept.length>0 && selPlant.length>0? 
      <>
       
           <Route path="/SIS/RaiseIndent" element={<AuthWrapper><RaiseRequest showLoader={showLoader} hideLoader={hideLoader}/></AuthWrapper>}/>
           
            </> :<></>    } </Routes>
          </Menu>
    </>
  );
}
const DeptModal = ({details,handleChangeDept,handleClose }) => {
  return (
    <div className="modal modal-sm display-block" >
      <section className="modal-main text-left" style={{width:"300px",borderRadius:"8px"}}>
        <div className="App1 text-left">
       <div style={{marginLeft:"20px"}}>
        <div className="row">
          <div className="col-md-10">  <h5><span class="fas fa-building text-primary mt-2 "></span>&nbsp;&nbsp;&nbsp;Select Department</h5>
     </div>
     <div className="col-md-2"> <a className="fas fa-close mt-2" onClick={()=>{handleClose()}}></a></div>
        </div>
       
       </div><table class="table table-header">
           
            <tbody className="text-left">
              {details.map((item, index) => {
                return (
                  <tr>
                    {/* <td>{details?.destinationStorage}</td>
                <td>{details?.destinationPlant}</td>
                <td>{details?.destinationPlant}</td>
                <td>{details? .quantity}</td>
                <td>{comman.INTRA}</td> */}
                   
                    <td><label  id="destinationDepartment"
                      name="destinationDepartment"
                      className="text-primary"
                     
                      value={item.dept}
                      onClick={()=>{handleChangeDept(item)}}  style={{cursor:"pointer",color:"black"}}>{item.deptName}({item.dept})</label></td>
                   
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
       
      </section>
    </div>
  );
};

export default App;
