﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Mail;
using System.Web;
using System.Web.Http;
//using System.Web.Mvc;


using SIS_BACKEND_API.Models;

namespace SIS_BACKEND_API.Controllers
{
    [RoutePrefix("api/Email")]
    public class EmailController : ApiController
    {
        [HttpGet]
        [Route("SendOPT")]
        public IHttpActionResult SendMail(String EmailId, string OTP)
        {
            bool SuccessFlag = true;
            string ErrorMessage = "";

            try
            {
                string strSmtpServerHost = "144.0.11.253";
                SmtpClient objSmtpClient = new SmtpClient(strSmtpServerHost);
                MailMessage mail = new MailMessage();

                string MAIL_FROM = "SISAdmin@tatasteel.com";
                mail.From = new MailAddress(MAIL_FROM);
                if (EmailId != null)
                {
                    if (!string.IsNullOrEmpty(EmailId))
                        mail.To.Add(EmailId);
                }

                mail.Subject = "Your OTP";
                mail.IsBodyHtml = true;
                mail.Body = "Your OTP is " + OTP + ". Please Verify ";

                objSmtpClient.Send(mail);
                mail.Dispose();
            }
            catch (Exception ex)
            {
                SuccessFlag = false;
                ErrorMessage = "Exception during processing Send Mail with message: " + ex.Message;
            }

            if (SuccessFlag)
            {
                return Ok(new { success = true, message = "Mail sent successfully" });
            }
            else
            {
                return Ok(new { success = false, message = ErrorMessage });
            }
        }

    }
}