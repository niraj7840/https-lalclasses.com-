﻿using Newtonsoft.Json;
using SIS_BACKEND_API.App_Code.DAL;
using SIS_BACKEND_API.App_Code.Utils;
using SIS_BACKEND_API.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Security.AccessControl;
using System.Web.Http;
using System.Web.Http.Results;
using System.Web.UI.WebControls;

namespace SIS_BACKEND_API.Controllers
{
    [RoutePrefix("api/Workflow")]
    public class WorkflowController : ApiController
    {
        WorkflowDAL objCommonDAL = new WorkflowDAL();
      
        [HttpGet]
        [Route("GetWorkflow")]
        public IHttpActionResult GetWorkFlowDetails(string ADID)
        {
            List<WorkFlowModel> workFlow = new List<WorkFlowModel>();

            //string token = Request.Headers.Where(x => x.Key.ToLower() == "jwt-token").FirstOrDefault().Value.FirstOrDefault().ToString();
            //string _requester = TokenManager.VerifyToken(token);
            //if (_requester.Equals("-1"))
            //    return (Ok(new Message { Text = "Unauthorized!", Status = MessageType.error, jsonData = "Token has expired" }));

            try
            {
                DataTable dtworkFlows = objCommonDAL.GetWorkFlowDetails(ADID);
                return (Ok(new Message { Text = "success", Status = MessageType.success, jsonData = dtworkFlows }));

            }
            catch (Exception)
            {

                return null;
            }

        }
        [HttpGet]
        [Route("GetApprover")]
        public IHttpActionResult GetAppover(string DEPT,string PLANT)
        {
            HRServices.Service objHRService = new HRServices.Service();

            HRServices.EmpDetails[] objEmpDetails;

            WorkflowDAL objCommonDAL = new WorkflowDAL();
            try
            {
                DataTable dtworkFlows = objCommonDAL.GetApprover(DEPT,PLANT);
                for (int i = 0; i < dtworkFlows.Rows.Count; i++)
                {
                    objEmpDetails = objHRService.getDetails(new string[] { dtworkFlows.Rows[i]["APR_ID"].ToString() });
                    dtworkFlows.Rows[i]["USERNAME"] = dtworkFlows.Rows[i]["APR_ID"].ToString() + "-" + objEmpDetails[0].getsetFname + " " + objEmpDetails[0].getsetLname;
                }
                return (Ok(new Message { Text = "success", Status = MessageType.success, jsonData = dtworkFlows }));

            }
            catch (Exception)
            {

                return null;
            }

        }

        [HttpPost]
        [Route("UpdateWorkflowFromID")]
        public IHttpActionResult UpdateWorkFlowDetailsFromID(WorkFlowModel WorkFlowID)
        {
            List<WorkFlowModel> workFlow = new List<WorkFlowModel>();
            WorkflowDAL objCommonDAL = new WorkflowDAL();
            try
            {
               int insertCount = objCommonDAL.UpdateWorkFlowDetailsFromID(WorkFlowID);
                return (Ok(new Message { Text = "success", Status = MessageType.success, jsonData ="Updated "+ insertCount }));

            }
            catch (Exception)
            {

                return null;
            }

        }
    }
}
