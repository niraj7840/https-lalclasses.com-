﻿using Newtonsoft.Json.Linq;
using SIS_BACKEND_API.Models;
using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Http;
using System.Net.Http.Formatting;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using System.Web.Http;
[RoutePrefix("api/SAP")]
public class SAPDataController : ApiController
{
    [HttpGet]
    [Route("GetData")]
    public async Task<IHttpActionResult> GetData(string UMC,string DEPT)
    {
        string apiUrl = "http://sapfioriqa.tatasteel.co.in:8000/sap/opu/odata/sap/YMPIG_DEPT_MAT_WISE_SRV/DeptMatWisestockSet?$filter=( InputMaterial eq %27"+ UMC +"%27 and DeptCode eq %27"+DEPT+"%27 )&$format=json";

        using (HttpClient client = new HttpClient())
        {
            // Setting the username and password for basic authentication
            string username = "149713";
            string password = "Fiori@600";
            string authInfo = $"{username}:{password}";
            string base64AuthInfo = Convert.ToBase64String(Encoding.UTF8.GetBytes(authInfo));
            client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Basic", base64AuthInfo);

            try
            {
                HttpResponseMessage response = await client.GetAsync(apiUrl);

                if (response.IsSuccessStatusCode)
                {
                    string responseData = await response.Content.ReadAsStringAsync();

                    return Ok(new { StatusCode= "success", Response= responseData });
                }
                else
                {
                    return Ok(new { StatusCode = "error", Response = "" });// or BadRequest() or NotFound() based on your needs
                }
            }
            catch (HttpRequestException ex)
            {
                return Ok(new { StatusCode = "error", Response = "" }); // Return the exception details
            }
        }
    }

    public async  Task<JObject> UpdateUMCListAccordingToInventoryAsync(string umc,string dept)
    {
            string apiUrl = "http://sapfioriqa.tatasteel.co.in:8000/sap/opu/odata/sap/YMPIG_DEPT_MAT_WISE_SRV/DeptMatWisestockSet?$filter=( InputMaterial eq %27" + umc + "%27 and DeptCode eq %27" + dept + "%27 )&$format=json";
            JObject inventory = new JObject();
            using (HttpClient client = new HttpClient())
            {
                // Setting the username and password for basic authentication
                string username = "149713";
                string password = "Fiori@600";
                string authInfo = $"{username}:{password}";
                string base64AuthInfo = Convert.ToBase64String(Encoding.UTF8.GetBytes(authInfo));
                client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Basic", base64AuthInfo);

                try
                {
                    HttpResponseMessage response = await client.GetAsync(apiUrl).ConfigureAwait(false);

                    var responseContent = await response.Content.ReadAsStringAsync();
                    JObject inventoryResponse = JObject.Parse(responseContent);

                    if (inventoryResponse == null || inventoryResponse["d"] == null)
                    {
                        Console.Error.WriteLine("Invalid inventory response.");
                    }

                inventory = inventoryResponse;
                    
                }
                catch (Exception ex)
                {
                    Console.Error.WriteLine("Error while fetching inventory details", ex.Message);
                }
            }
        return inventory;
    }

   

    // Enable CORS for all origins
    private IHttpActionResult Ok(object data)
    {
        var response = Request.CreateResponse(HttpStatusCode.OK, data, new JsonMediaTypeFormatter());
        response.Headers.Add("Access-Control-Allow-Origin", "*");
        response.Headers.Add("Access-Control-Allow-Methods", "GET, POST, OPTIONS");
        response.Headers.Add("Access-Control-Allow-Headers", "Authorization, Content-Type");
        response.Headers.Add("Access-Control-Allow-Credentials", "true");
        return ResponseMessage(response);
    }
    private  static class ReturnResponse
    {
        public static string status { get; set; }
        public static  string response { get; set; }
    }
}