﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using Oracle.ManagedDataAccess.Client;
using SIS_BACKEND_API.App_Code.DAL;
using SIS_BACKEND_API.Models;


namespace SIS_BACKEND_API.Controllers
{
    [RoutePrefix("api/Indent")]
    public class IndentController : ApiController
    {
        Indent_DAL objDal = new Indent_DAL();

        [HttpPost]
        [Route("SaveIndent")]
        public IHttpActionResult PostIndentDetails([FromBody] SaveIndent SaveIndent)
        {
            var rturn = objDal.CreateIndent(SaveIndent);
            if (rturn == 0)
            {
                return Ok(new { StatusCode = "error", data = rturn });
            }
           return Ok(new { StatusCode = "OK", data = rturn });
            
        }
        //[HttpPost]
        //[Route("SaveIndentChild")]
        //public IHttpActionResult PostIndentChildDetails([FromBody] List<T_SIS_UMC_INDENT_DETAILS> T_SIS_UMC_INDENT_DETAILS)
        //{

        //    return Ok(objDal.SaveIndentChildDetails(T_SIS_UMC_INDENT_DETAILS));

        //}
        //[HttpPost]
        //[Route("SaveWorkFlow")]
        //public IHttpActionResult PostWorkFlowDetails([FromBody] List<T_SII_WORK_FLOW> T_SII_WORK_FLOW)
        //{

        //    return Ok(objDal.SaveWorkFlowDetails(T_SII_WORK_FLOW));

        //}
    }
}

