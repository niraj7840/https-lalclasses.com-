﻿using Newtonsoft.Json;
using SIS_BACKEND_API.App_Code.DAL;
using SIS_BACKEND_API.App_Code.DAL.IntelliBuyDAL;
using SIS_BACKEND_API.App_Code.Utils;
using SIS_BACKEND_API.Models;
using SIS_BACKEND_API.Models.IntelliBuyModel;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using System.Web.Http;

namespace SIS_BACKEND_API.Controllers.IntelliBuy
{
    [RoutePrefix("api/IntelliBuyChecks")]
    public class IntelliBuyChecksController : ApiController
    {
        IntelliBuyChecks_DAL objCommonDAL = new IntelliBuyChecks_DAL();

        [HttpGet]
        [Route("GetIntelliBuyChecksDetails")]
        public async Task<IHttpActionResult> GetIntelliBuyChecksDetailsFromId(string IndentId)
        {
            try
            {
                //string _requester = TokenManager.VerifyToken(Request.Headers.Authorization.Parameter);
                //if (_requester.Equals("-1"))
                //    return (Ok(new Message { Text = "Unauthorized!", Status = MessageType.error, jsonData = "Token has expired" }));
                List<IntelliBuyIndentDetails> ObjIntelliBuyIndentDetails = await objCommonDAL.GetIntelliBuyChecksDetails(IndentId).ConfigureAwait(false);
                return (Ok(new Message { Text = "success", Status = MessageType.success, jsonData = ObjIntelliBuyIndentDetails }));

            }
            catch (Exception)
            {

                return null;
            }

        }
        [HttpPost]
        [Route("InsertIntelliBuyCheckItem")]
        public IHttpActionResult InsertIntelliBuyCheckItem([FromBody] IntelliBuyChecks IntelliBuyChecks)
        {
            IntelliBuyChecksHeader header = IntelliBuyChecks.ObjIntelliBuyChecksHeader;
            List<IntelliBuyIndentDetails> items = IntelliBuyChecks.ObjIntelliBuyIndentDetails;

            try
            {
                int insertCount = 0;
                //string _requester = TokenManager.VerifyToken(Request.Headers.Authorization.Parameter);
                //if (_requester.Equals("-1"))
                //    return (Ok(new Message { Text = "Unauthorized!", Status = MessageType.error, jsonData = "Token has expired" }));

                insertCount = objCommonDAL.SaveIntelliBuyDetails(header, items);


                return (Ok(new Message { Text = "success", Status = MessageType.success, jsonData = "Updated " + insertCount }));
            }
            catch (Exception)
            {

                return null;
            }

        }


    }
}
