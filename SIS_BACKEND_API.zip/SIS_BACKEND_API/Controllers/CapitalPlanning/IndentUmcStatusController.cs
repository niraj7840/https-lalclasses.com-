﻿using SIS_BACKEND_API.App_Code.DAL.CapitalPlanningDAL;
using SIS_BACKEND_API.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace SIS_BACKEND_API.Controllers.CapitalPlanning
{
    [RoutePrefix("api/IndentUmc")]
    public class IndentUmcStatusController : ApiController
    {

        IndentUmcStatusDAL objIndentUmcDAL = new IndentUmcStatusDAL();


        //api for getting umcs under one intent and should whether the umcs is tagged as c, r or N


        [HttpGet]
        [Route("GetUmcsTaggedUnderIntent")]

        public IHttpActionResult GetUmcsTaggedUnderIntent(string intent)
        {
            try
            {
                DataTable dt = objIndentUmcDAL.GetUmcsTaggedUnderIntent(intent);
                return (Ok(new Message { Text = "success", Status = MessageType.success, jsonData = dt }));
            }
            catch (Exception ex)
            {

                return (Ok(new Message { Text = ex.ToString(), Status = MessageType.error, jsonData = null }));
            }
        }


        [HttpGet]
        [Route("GetStatusOfUMCIndent")]

        public IHttpActionResult GetStatusOfUMCIndent(string umc, int indent)
        {
            try
            {
                string status = objIndentUmcDAL.GetStatusOfUMCIndent(umc, indent);
                return (Ok(new Message { Text = "success", Status = MessageType.success, jsonData = status }));
            }
            catch (Exception ex)
            {

                return (Ok(new Message { Text = ex.ToString(), Status = MessageType.error, jsonData = null }));
            }
        }
    }
}
