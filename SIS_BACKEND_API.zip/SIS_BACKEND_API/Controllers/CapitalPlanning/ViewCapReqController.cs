﻿using SIS_BACKEND_API.App_Code.DAL.CapitalPlanningDAL;
using SIS_BACKEND_API.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace SIS_BACKEND_API.Controllers.CapitalPlanning
{
    [RoutePrefix("api/ViewCapReq")]
    public class ViewCapReqController : ApiController
    {
        ViewCapReqDAL objViewCapitalRequestDAL = new ViewCapReqDAL();


        //GET FOR VIEWREQUEST


        [HttpGet]
        [Route("GetViewPendingRequest")]

        public IHttpActionResult GetViewPendingRequest()
        {

            try
            {
                DataTable dt = objViewCapitalRequestDAL.GetViewPendingRequest();
                return (Ok(new Message { Text = "success", Status = MessageType.success, jsonData = dt }));
            }
            catch (Exception ex)
            {

                return (Ok(new Message { Text = ex.ToString(), Status = MessageType.error, jsonData = null }));
            }

        }


        // api for get umc or requestId or both

        [HttpGet]
        [Route("GetUmcOrRequestIdInfo")]

        public IHttpActionResult GetUmcOrRequestIdInfo(string umc = null, int? requestId = null)
        {
            try
            {
                DataTable dt = objViewCapitalRequestDAL.GetUmcOrRequestIdInfo(umc, requestId);
                return (Ok(new Message { Text = "success", Status = MessageType.success, jsonData = dt }));
            }
            catch (Exception ex)
            {

                return (Ok(new Message { Text = ex.ToString(), Status = MessageType.error, jsonData = null }));
            }
        }

    }
}
