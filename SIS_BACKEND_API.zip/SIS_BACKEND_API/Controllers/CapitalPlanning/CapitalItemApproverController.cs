﻿using SIS_BACKEND_API.App_Code.DAL;
using SIS_BACKEND_API.App_Code.DAL.CapitalPlanningDAL;
using SIS_BACKEND_API.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace SIS_BACKEND_API.Controllers.CapitalPlanning
{
    [RoutePrefix("api/CapitalApprover")]
    public class CapitalItemApproverController : ApiController
    {
        CapitalItemApproverDAL objCapitalRequestDAL = new CapitalItemApproverDAL();



        //CAPITAL APPROVER REQUEST PAGE

        // this is model class for getting after joining the table on approver screen

        [HttpGet]
        [Route("GetApproverScreen1/{role}")]
        public IHttpActionResult GetApproverScreen1(string role)
        {

            try
            {
                DataTable dt = objCapitalRequestDAL.GetApproverScreen1(role);
                return (Ok(new Message { Text = "success", Status = MessageType.success, jsonData = dt }));
            }
            catch (Exception ex)
            {

                return (Ok(new Message { Text = ex.ToString(), Status = MessageType.error, jsonData = null }));
            }
        }



        //api when capex/vp click approve button 

        [HttpPut]
        [Route("UpdateApproverScreenRequestID/{role}")]

        public IHttpActionResult UpdateApproverScreenRequestID(string role, UmcCapexApprovalUpdateModel model)
        {

            try
            {
                int insertCount = objCapitalRequestDAL.UpdateApproverScreenRequestID(role, model);
                return (Ok(new Message { Text = "success", Status = MessageType.success, jsonData = "Updated " + insertCount }));

            }
            catch (Exception ex)
            {

                return (Ok(new Message { Text = ex.ToString(), Status = MessageType.error, jsonData = null }));
            }

        }




        //this is the api for reject for approval screen

        [HttpPut]
        [Route("UpdateApproverScreenRejectRequestID/{role}")]

        public IHttpActionResult UpdateApproverScreenRejectRequestID(string role, UmcCapexApprovalUpdateModel model)
        {

            try
            {
                int insertCount = objCapitalRequestDAL.UpdateApproverScreenRejectRequestID(role, model);
                return (Ok(new Message { Text = "success", Status = MessageType.success, jsonData = "Updated " + insertCount }));

            }
            catch (Exception ex)
            {

                return (Ok(new Message { Text = ex.ToString(), Status = MessageType.error, jsonData = null }));
            }

        }


        // FOR INSERT INTO TAB T_CAP_REV_UMC WHEN CAPEX OR VP APPROVE

        [HttpPost]
        [Route("UPSERTAPPROVEPAGE")]

        public IHttpActionResult UPSERTAPPROVEPAGE(T_CAP_REV_UMC model)
        {
            try
            {
                int insertCount = objCapitalRequestDAL.UPSERTAPPROVEPAGE(model);
                return (Ok(new Message { Text = "success", Status = MessageType.success, jsonData = "Updated " + insertCount }));

            }
            catch (Exception ex)
            {

                return (Ok(new Message { Text = ex.ToString(), Status = MessageType.error, jsonData = null }));
            }

        }




        //reject by capex the tagged as R

        // FOR INSERT INTO TAB T_CAP_REV_UMC WHEN CAPEX OR VP reject and tagged as revenue

        [HttpPost]
        [Route("CAPEXMARKEDREVENUE/{role}")]

        public IHttpActionResult CAPEXMARKEDREVENUE(string role, T_CAP_REV_UMC model)
        {

            try
            {
                int insertCount = objCapitalRequestDAL.CAPEXMARKEDREVENUE(role, model);
                return (Ok(new Message { Text = "success", Status = MessageType.success, jsonData = "inserted " + insertCount }));

            }
            catch (Exception ex)
            {

                return (Ok(new Message { Text = ex.ToString(), Status = MessageType.error, jsonData = null }));
            }
        }

    }
}
