﻿using SIS_BACKEND_API.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using Oracle.ManagedDataAccess.Client;
using System.Configuration;
using Newtonsoft.Json;
using System.Data;
using System.Web.Http.Results;
using System.Web.DynamicData;
using System.Web.UI.WebControls;
using System.Runtime.Remoting.Contexts;
using System.Security.Policy;
using SIS_BACKEND_API.App_Code.DAL;
using System.Web.Security;
using SIS_BACKEND_API.App_Code.Utils;


namespace SIS_BACKEND_API.Controllers
{

    [RoutePrefix("api/Question")]
    public class QuestionDetailsController : ApiController
    {
        
        CapitalRequestDAL objCapitalRequestDAL = new CapitalRequestDAL();
        
        // raise capital item request page
        //This is the api when user open the raise capital item request the questions will
        //get from table.

        [HttpGet]
        [Route("GetQuestion")]
        public IHttpActionResult GetQuestion()
        {

            try
            {
                DataTable dt = objCapitalRequestDAL.GetQuestion();
                return (Ok(new Message { Text = "success", Status=MessageType.success, jsonData=dt }));
            }
            catch (Exception ex)
            {

                return (Ok(new Message { Text = ex.ToString(), Status=MessageType.error, jsonData=null }));
            }

        }




    }
}
