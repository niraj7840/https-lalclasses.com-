﻿using Oracle.ManagedDataAccess.Client;
using SIS_BACKEND_API.App_Code.DAL;
using SIS_BACKEND_API.Models;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;


namespace SIS_BACKEND_API.Controllers
{

    [RoutePrefix("api/Master")]
    public class MasterController : ApiController
    {
        MasterDAL objDal = new MasterDAL();

        private readonly string _connectionstring;

        public MasterController()
        {
            _connectionstring = ConfigurationManager.ConnectionStrings["OracleConnection"].ConnectionString;
        }

        [HttpGet]
        [Route("GetMaterial")]
        public IHttpActionResult GetMaterial(int adid)
        {
            var materialList = new List<Material>();
           

            try
            {
                materialList = objDal.GetMaterial(adid);


            }
            catch (Exception ex)
            {
                Console.WriteLine("Error : " + ex.Message);

                return InternalServerError();
            }
            return Json(materialList);

        }

       
        [HttpGet]
        [Route("GetPlantList")]
        public IHttpActionResult GetPlantList(string DEPT,string ADID)
        {
            var plantList = new List<Plant>();

            try
            {
                plantList = objDal.GetPlantList(DEPT, ADID);
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error : " + ex.Message);

                return InternalServerError();
            }
            return Json(plantList);

        }

        [HttpGet]
        [Route("GetCodeList")]
        public IHttpActionResult GetCodeValueList(string CODE)
        {
            var codeVal = new List<CODEVAL>();
          
            try
            {
                codeVal = objDal.GetCodeValueList(CODE);
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error : " + ex.Message);

                return InternalServerError();
            }
            return Json(codeVal);

        }
        [HttpGet]
        [Route("GetDepartment")]
        public IHttpActionResult GetDepartment(string adid)
        {
            var deptList = new List<Department>();
        

            try
            {
                deptList = objDal.GetDepartment(adid);
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error : " + ex.Message);

                return InternalServerError();
            }
            return Json(deptList);

        }

        [HttpGet]
        [Route("GetDraftedList")]
        public IHttpActionResult GetDraftedList(string DEPT ,string USERNAME)
        {
            var draftedList = new List<SaveDraft>();
          

            try
            {
                draftedList = objDal.GetDraftedList(DEPT, USERNAME);
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error : " + ex.Message);

                return InternalServerError();
            }
            return Json(draftedList);

        }


    }
}


