﻿
using SIS_BACKEND_API.App_Code.DAL.ShoppingCart;
using SIS_BACKEND_API.Models.ShoppingCartModel;
using System;
using System.Collections.Generic;
using System.Web.Http;
using SIS_BACKEND_API.Models;
using System.Web.Http;
using System.IO;
using System.Web;
using System.Data;
using System.Threading.Tasks;

namespace SIS_BACKEND_API.Controllers.ShoppingCart
{

    [RoutePrefix("api/ShoppingCart")]
    public class SC_ApprovalController : ApiController
    {

        SC_ApprovalDAL objCommonDAL = new SC_ApprovalDAL();

        [HttpPost]
        [Route("SCApproval")]
        public IHttpActionResult InsertApprovals([FromBody] List<ApprovalRequest> approvals)
        {
            try
            {
                objCommonDAL.InsertApprovals(approvals);
                return (Ok(new Message { Text = "success", Status = MessageType.success }));
            }
            catch (Exception ex)
            {
                return null;
            }
        }


        [HttpPost]
        [Route("SCApproverSection")]
        public IHttpActionResult InsertApprovalSecrion([FromBody] ApprovalSection approvalSection)
        {
            try
            {
                objCommonDAL.InsertApprovalSection(approvalSection);
                return (Ok(new Message { Text = "success", Status = MessageType.success }));
            }
            catch (Exception ex)
            {
                // Log the exception
                Console.WriteLine($"Error in InsertApprovalSecrion: {ex.Message}");
                // Return a meaningful error response
                return InternalServerError(ex);
            }
        }

        [HttpPost]
        [Route("SCApproverFileUpload")]
        public IHttpActionResult SCApproverFileUpload()
        {
            var httpRequest = HttpContext.Current.Request;

            if (httpRequest.Files.Count == 0)
                return BadRequest("No file uploaded");

            var postedFile = httpRequest.Files[0];
            var sno = int.Parse(httpRequest.Form["Sno"]);
            var userId = httpRequest.Form["UserId"];

            byte[] fileData;
            using (var binaryReader = new BinaryReader(postedFile.InputStream))
            {
                fileData = binaryReader.ReadBytes(postedFile.ContentLength);
            }

            var fileUploadModel = new FileUploadModel
            {
                FileName = postedFile.FileName,
                FileContent = fileData,
                Sno = sno,
                UserId = userId
            };

            objCommonDAL.UploadApprovalFile_Dal(fileUploadModel);

            //return Ok(new { fileUploadModel.FileName, fileUploadModel.Sno, fileUploadModel.UserId });

            return (Ok(new Message { Text = "success", Status = MessageType.success }));
        }



        [HttpGet]
        [Route("GetShoppingCartDetails")]
        public IHttpActionResult GetIGetShoppingCartDetails(string SCId)
        {


            try
            {
                //string _requester = TokenManager.VerifyToken(Request.Headers.Authorization.Parameter);
                //if (_requester.Equals("-1"))
                //    return (Ok(new Message { Text = "Unauthorized!", Status = MessageType.error, jsonData = "Token has expired" }));
                DataTable dt = objCommonDAL.GetShoppingCartDetails_DAL(SCId);
                return (Ok(new Message { Text = "success", Status = MessageType.success, jsonData = dt }));

            }
            catch (Exception)
            {

                return null;
            }

        }

    }
}


