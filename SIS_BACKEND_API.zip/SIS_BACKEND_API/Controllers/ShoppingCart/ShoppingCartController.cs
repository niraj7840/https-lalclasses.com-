﻿using SIS_BACKEND_API.App_Code.DAL.ShoppingCart;
using SIS_BACKEND_API.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace SIS_BACKEND_API.Controllers.ShoppingCart
{
    [RoutePrefix("api/ShoppingCart")]
    public class ShoppingCartController : ApiController
    {
        ShoppingCartDAL objCommonDAL = new ShoppingCartDAL();

        [HttpGet]
        [Route("GetCostCsrCategory")]
        public IHttpActionResult GetCostCsrCategory()
        {


            try
            {
                //string _requester = TokenManager.VerifyToken(Request.Headers.Authorization.Parameter);
                //if (_requester.Equals("-1"))
                //    return (Ok(new Message { Text = "Unauthorized!", Status = MessageType.error, jsonData = "Token has expired" }));
                DataTable dt = objCommonDAL.Get_CSR_Category();
                return (Ok(new Message { Text = "success", Status = MessageType.success, jsonData = dt }));

            }
            catch (Exception)
            {

                return null;
            }

        }
        /// <summary>
        /// csr_subsocial 
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        [Route("GetCostCsrSubCategory")]
        public IHttpActionResult GetCostCsrSubCategory()
        {


            try
            {
                //string _requester = TokenManager.VerifyToken(Request.Headers.Authorization.Parameter);
                //if (_requester.Equals("-1"))
                //    return (Ok(new Message { Text = "Unauthorized!", Status = MessageType.error, jsonData = "Token has expired" }));
                DataTable dt = objCommonDAL.Get_CSR_CODE_SUB_MASTER();
                return (Ok(new Message { Text = "success", Status = MessageType.success, jsonData = dt }));

            }
            catch (Exception)
            {

                return null;
            }

        }
        [HttpGet]
        [Route("GetCostCsrSubActivity")]
        public IHttpActionResult GetCostCsrSubActivity(string CSR_SUB_CODE)
        {


            try
            {
                //string _requester = TokenManager.VerifyToken(Request.Headers.Authorization.Parameter);
                //if (_requester.Equals("-1"))
                //    return (Ok(new Message { Text = "Unauthorized!", Status = MessageType.error, jsonData = "Token has expired" }));
                DataTable dt = objCommonDAL.Get_CSR_SUB_CODE_ACTIVITY(CSR_SUB_CODE);
                return (Ok(new Message { Text = "success", Status = MessageType.success, jsonData = dt }));

            }
            catch (Exception)
            {

                return null;
            }

        }
        [HttpGet]
        [Route("GetIntelliBuyChecksDetails")]
        public IHttpActionResult GetIntelliBuyChecksDetailsFromId(string IndentId)
        {


            try
            {
                //string _requester = TokenManager.VerifyToken(Request.Headers.Authorization.Parameter);
                //if (_requester.Equals("-1"))
                //    return (Ok(new Message { Text = "Unauthorized!", Status = MessageType.error, jsonData = "Token has expired" }));
                DataTable dt =   objCommonDAL.GetIntelliBuyChecksHeaderAndItem(IndentId);
                return (Ok(new Message { Text = "success", Status = MessageType.success, jsonData = dt }));

            }
            catch (Exception)
            {

                return null;
            }

        }

        [HttpGet]
        [Route("GetCostCategory")]
        public IHttpActionResult GetCostCategory()
        {
            try
            {
                //string _requester = TokenManager.VerifyToken(Request.Headers.Authorization.Parameter);
                //if (_requester.Equals("-1"))
                //    return (Ok(new Message { Text = "Unauthorized!", Status = MessageType.error, jsonData = "Token has expired" }));
                DataTable dt = objCommonDAL.GetCostCategory();
                return (Ok(new Message { Text = "success", Status = MessageType.success, jsonData = dt }));

            }
            catch (Exception)
            {

                return null;
            }

        }

        [HttpGet]
        [Route("GetDocumentsText")]
        public IHttpActionResult GetDocumentsText()
        {
            try
            {
                //string _requester = TokenManager.VerifyToken(Request.Headers.Authorization.Parameter);
                //if (_requester.Equals("-1"))
                //    return (Ok(new Message { Text = "Unauthorized!", Status = MessageType.error, jsonData = "Token has expired" }));
                DataTable dt = objCommonDAL.GetDocumentsText();
                return (Ok(new Message { Text = "success", Status = MessageType.success, jsonData = dt }));

            }
            catch (Exception)
            {

                return null;
            }

        } 
        [HttpGet]
        [Route("GetCurrencyCode")]
        public IHttpActionResult GetCurrencyCode()
        {
            try
            {
                //string _requester = TokenManager.VerifyToken(Request.Headers.Authorization.Parameter);
                //if (_requester.Equals("-1"))
                //    return (Ok(new Message { Text = "Unauthorized!", Status = MessageType.error, jsonData = "Token has expired" }));
                DataTable dt = objCommonDAL.GetCurrencyCode();
                return (Ok(new Message { Text = "success", Status = MessageType.success, jsonData = dt }));

            }
            catch (Exception)
            {

                return null;
            }

        }
    }
}
