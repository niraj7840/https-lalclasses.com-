﻿using Oracle.ManagedDataAccess.Client;
using SIS_BACKEND_API.Models.ShoppingCartModel;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;


namespace SIS_BACKEND_API.App_Code.DAL.ShoppingCart
{
    public class SC_ApprovalDAL
    {
       
        private string strConnSISDB = ConfigurationManager.ConnectionStrings["OracleConnection"].ConnectionString;
        private ConnectionOracleDB objConn;
        private DataTable dtResult;

        public void InsertApprovals(List<ApprovalRequest> approvals)
        {
            using (var connection = new OracleConnection(strConnSISDB))
            {
                connection.Open();

                foreach (var approval in approvals)
                {
                    using (var command = new OracleCommand("p_ins_sis_sc_approval", connection))
                    {
                        command.CommandType = CommandType.StoredProcedure;

                        command.Parameters.Add("tot_amnt", OracleDbType.Int32).Value = approval.tot_amnt;
                        command.Parameters.Add("indnt_type", OracleDbType.Varchar2).Value = approval.indnt_type;
                        command.Parameters.Add("scartno", OracleDbType.Int32).Value = approval.scartno;
                        command.Parameters.Add("dept_no", OracleDbType.Int32).Value = approval.dept_no;                     
                        command.Parameters.Add("Committed_Expenditure_Val", OracleDbType.Int32).Value = approval.Committed_Expenditure_Val;
                        command.Parameters.Add("Spare_Budget_Val", OracleDbType.Int32).Value = approval.Spare_Budget_Val;                     
                        

                        command.ExecuteNonQuery();
                    }
                }
            }
        }


        public void InsertApprovalSection(ApprovalSection approvalSec)
        {
            using (var connection = new OracleConnection(strConnSISDB))
            {
                connection.Open();
                using (var command = new OracleCommand("p_sis_appr_section", connection))
                {

                    //string _nscnum = approvalSec.nscnum.Trim();
                    //string __status = approvalSec._status.Trim();
                    //string _appr_id = approvalSec.appr_id.Trim();
                    //string _appr_rem = approvalSec.appr_rem.Trim();
                    //string _mail_to = approvalSec.mail_to.Trim();
                    //string _IMEI_no = approvalSec.IMEI_no.Trim();


                    //command.CommandType = CommandType.StoredProcedure;
                    //command.Parameters.Clear();
                    //command.Parameters.Add("nscnum", _nscnum);
                    //command.Parameters.Add("status", __status);
                    //command.Parameters.Add("appr_id", _appr_id);
                    //command.Parameters.Add("appr_rem", _appr_rem);
                    //command.Parameters.Add("mail_to", _mail_to);
                    //command.Parameters.Add("IMEI_no", _IMEI_no);


                    //command.Parameters.Add("nscnum", appSec.nscnum);
                    //command.Parameters.Add("status", appSec.status);
                    //command.Parameters.Add("appr_id", appSec.appr_id);
                    //command.Parameters.Add("appr_rem", appSec.appr_rem);
                    //command.Parameters.Add("mail_to", appSec.mail_to);
                    //command.Parameters.Add("IMEI_no", appSec.IMEI_no);

                    //command.ExecuteNonQuery();



                    command.Parameters.Clear();
                    command.CommandText = "p_sis_appr_section";
                    command.CommandType = CommandType.StoredProcedure;

                    // Input parameters
                    command.Parameters.Add("nscnum", OracleDbType.Varchar2).Value = approvalSec.nscnum;
                    command.Parameters.Add("status", OracleDbType.Varchar2).Value =approvalSec._status;   // "1";    
                    command.Parameters.Add("appr_id", OracleDbType.Varchar2).Value = approvalSec.appr_id;  // "163402";  
                    command.Parameters.Add("appr_rem", OracleDbType.Varchar2).Value = approvalSec.appr_rem; // "Approval Remarks" 
                    command.Parameters.Add("mail_to", OracleDbType.Varchar2).Value = approvalSec.mail_to;   // "ALL";  
                    command.Parameters.Add("IMEI_no", OracleDbType.Varchar2).Value = approvalSec.IMEI_no;  // "WEB";

                    // Output parameter
                    OracleParameter outputParam = new OracleParameter("err_msg", OracleDbType.Varchar2);
                    outputParam.Direction = ParameterDirection.Output;
                    outputParam.Size = 500; // Adjust size as per your requirement
                    command.Parameters.Add(outputParam);
                    int i = command.ExecuteNonQuery();

                }

            }
        }


        public void UploadApprovalFile_Dal(FileUploadModel fileUploadModel)
        {
            using (var connection = new OracleConnection(strConnSISDB))
            {
                connection.Open();

                using (var command = connection.CreateCommand())
                {
                    command.CommandText = @"
                    UPDATE t_sc_approval SET 
                        scp_filename = :FileName,
                        scp_atchmnt = :BlobParameter 
                    WHERE 
                        scp_cart_no = :Sno 
                        AND scp_apprvr = :UserId 
                        AND scp_mailsend_status = '01' 
                        AND scp_app_status = '00' 
                        AND scp_ver_no = (
                            SELECT MAX(scp_ver_no) 
                            FROM t_sc_approval 
                            WHERE scp_cart_no = :Sno
                        )";

                    command.Parameters.Add(new OracleParameter("FileName", OracleDbType.Varchar2) { Value = fileUploadModel.FileName });
                    command.Parameters.Add(new OracleParameter("BlobParameter", OracleDbType.Blob) { Value = fileUploadModel.FileContent });
                    command.Parameters.Add(new OracleParameter("Sno", OracleDbType.Varchar2) { Value = fileUploadModel.Sno });
                    command.Parameters.Add(new OracleParameter("UserId", OracleDbType.Varchar2) { Value = fileUploadModel.UserId });

                    command.ExecuteNonQuery();
                }
            }
        }


        public DataTable GetShoppingCartDetails_DAL(string SCId)
        {

            objConn = new ConnectionOracleDB(strConnSISDB, DBConst_Approval.QryShoppingCartDetails, CommandType.Text, true);

            try
            {
                //Open the connection.
                objConn.OpenConnection();

                //Bind the parameters.            
                objConn.AddParameters(":sci_cart_no", SCId);

                //Execute the query and assign the resultant table.
                objConn.FillDataTable();
                dtResult = objConn.ResultantTable;

                //Close the connection
                objConn.CloseConnection();
            }
            catch (Exception excp)
            {
                throw excp;
            }

            //return the final Data Table.
            return dtResult;
        }
    }


    public class DBConst_Approval
    {
        #region ApprovalShoppingCart
        //added by Niraj
       
        public const string QryShoppingCartDetails = @"SELECT    SCH_CART_NO, SCH_CART_NAME   FROM T_SIS_SHOPPING_CART_HDR  WHERE SCH_CART_NO = :SCH_CART_NO ORDER BY 1";

        #endregion


    }


}
