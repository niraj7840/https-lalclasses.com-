﻿using Oracle.ManagedDataAccess.Client;
using SIS_BACKEND_API.Models.IntelliBuyModel;
using SIS_BACKEND_API.Models.ShoppingCartModel;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI.WebControls;

namespace SIS_BACKEND_API.App_Code.DAL.ShoppingCart
{
    public class ShoppingCartDAL
    {
        private string strConnSISDB = ConfigurationManager.ConnectionStrings["OracleConnection"].ConnectionString;

        private ConnectionOracleDB objConn;
        private DataTable dtResult;

        public DataTable Get_CSR_Category()
        {
            objConn = new ConnectionOracleDB(strConnSISDB, DBConst.ora_Get_CSR_Category, CommandType.Text, true);

            try
            {
                objConn.OpenConnection();
                objConn.FillDataTable();
                dtResult = objConn.ResultantTable;
                objConn.CloseConnection();
            }
            catch (Exception excp)
            {
                throw excp;
            }

            return dtResult;

        }

        public DataTable Get_CSR_CODE_SUB_MASTER()
        {
            objConn = new ConnectionOracleDB(strConnSISDB, DBConst.ora_Get_CSR_CODE_SUB_MASTER, CommandType.Text, true);

            try
            {
                objConn.OpenConnection();
                objConn.FillDataTable();
                dtResult = objConn.ResultantTable;
                objConn.CloseConnection();
            }
            catch (Exception excp)
            {
                throw excp;
            }

            return dtResult;

        }
        public DataTable Get_CSR_SUB_CODE_ACTIVITY(string CSR_SUB_CODE)
        {
            objConn = new ConnectionOracleDB(strConnSISDB, DBConst.ora_Get_CSR_SUB_CODE_ACTIVITY, CommandType.Text, true);

            try
            {
                objConn.OpenConnection();
                objConn.AddParameters(":CSR_SUB_CODE", CSR_SUB_CODE);
                objConn.FillDataTable();

                dtResult = objConn.ResultantTable;
                objConn.CloseConnection();
            }
            catch (Exception excp)
            {
                throw excp;
            }

            return dtResult;

        }

        public DataTable GetIntelliBuyChecksHeaderAndItem(string IndentId)
        {

            objConn = new ConnectionOracleDB(strConnSISDB, DBConst.oraGetIntelliBuyChecksHeaderAndItem, CommandType.Text, true);

            try
            {
                //Open the connection.
                objConn.OpenConnection();

                //Bind the parameters.            
                objConn.AddParameters(":INDENT_ID", IndentId);

                //Execute the query and assign the resultant table.
                objConn.FillDataTable();
                dtResult = objConn.ResultantTable;

                //Close the connection
                objConn.CloseConnection();
            }
            catch (Exception excp)
            {
                throw excp;
            }

            //return the final Data Table.
            return dtResult;
        }

        public DataTable GetCostCategory()
        {

            objConn = new ConnectionOracleDB(strConnSISDB, DBConst.ora_Get_Cost_Category, CommandType.Text, true);

            try
            {
                //Open the connection.
                objConn.OpenConnection();
                //Execute the query and assign the resultant table.
                objConn.FillDataTable();
                dtResult = objConn.ResultantTable;

                //Close the connection
                objConn.CloseConnection();
            }
            catch (Exception excp)
            {
                throw excp;
            }

            //return the final Data Table.
            return dtResult;
        }

        public DataTable GetDocumentsText()
        {

            objConn = new ConnectionOracleDB(strConnSISDB, DBConst.ora_GetDocumentsText, CommandType.Text, true);

            try
            {
                //Open the connection.
                objConn.OpenConnection();
                //Execute the query and assign the resultant table.
                objConn.FillDataTable();
                dtResult = objConn.ResultantTable;

                //Close the connection
                objConn.CloseConnection();
            }
            catch (Exception excp)
            {
                throw excp;
            }

            //return the final Data Table.
            return dtResult;
        }
        public DataTable GetCurrencyCode()
        {

            objConn = new ConnectionOracleDB(strConnSISDB, DBConst.ora_GetCurrencyCode, CommandType.Text, true);

            try
            {
                //Open the connection.
                objConn.OpenConnection();
                //Execute the query and assign the resultant table.
                objConn.FillDataTable();
                dtResult = objConn.ResultantTable;

                //Close the connection
                objConn.CloseConnection();
            }
            catch (Exception excp)
            {
                throw excp;
            }

            //return the final Data Table.
            return dtResult;
        }
    }
    public class DBConst
    {
        #region ShoppingCart
        //added by Animesh
        public const string ora_Get_CSR_Category = @"Select CSR_CODE value ,CSR_DESC label from CSR_CODES_MASTER ORDER BY CSR_CODE";
        public const string ora_Get_Cost_Category = @"SELECT acct_asgnmt_cat,acct_asgnmt_desc FROM t_acct_asgnmt where  acct_asgnmt_cat not in ('U','Q')  and acct_applicable in ('S','B')";
        public const string ora_GetDocumentsText = @"select t.text_id,t.txt_fod_type ||' - '|| t.txt_desc txt_desc,t.txt_fod_type,t.txt_lvl  from t_text_type t where t.txt_fod_type = 'PR' and TXT_LVL <>'S'";
        public const string ora_GetCurrencyCode = @"SELECT Distinct T.FROM_CURR FCURR  FROM SAPSUR.T_S_CURR_CODES T where TO_CURR = 'INR'";



        public const string ora_Get_CSR_CODE_SUB_MASTER = @"Select CSR_SUB_CODE value,CSR_SUB_CODE_DESC label from CSR_CODE_SUB_MASTER ORDER BY CSR_SUB_CODE";
        public const string ora_Get_CSR_SUB_CODE_ACTIVITY = @"Select CSR_ACITIVITY_CODE value,CSR_ACITIVITY_DESC label from CSR_SUB_CODE_ACTIVITY where CSR_SUB_CODE =:CSR_SUB_CODE ORDER BY CSR_ACITIVITY_CODE";
        public const string oraGetIntelliBuyChecksHeaderAndItem = @"SELECT  IND.INDENT_ID,IND.INDENTOR_PLANT,UMC.REQ_UMC_NO,UMC.REQ_UMC_BGG,to_char(umc.requirement_date, 'DD-MON-YYYY') as requirement_date,UMC.PRICE_PER_ITEM,umc.document_type,
umc.fod_type,umc.req_umc_desc ,UMC.UOM,scv.code_val_desc INDENT_CURRENT_STATUS,ind.INDENT_CURRENT_STATUS INDENT_CURRENT_STATUS_CODE , umc.EXISTING_UMC || '-' || umc.EXIS_UMC_DESC as TaggedUMC,
UMC.TOTAL_SAP_DOC_QTY,(QTY-TOTAL_SAP_DOC_QTY) as AllowedQty,UMC.UMC_INDENT_ID,IND.INDENTOR_DEPT,IND.INDENT_DESC,IND.INDENT_REMARKS,UMC.ISACTIVE,UMC.IS_REFURBISHABLE
,INTBUY_I.item_id,INTBUY_I.MAX_QTY QTY,INTBUY_I.SYS_REQ_DATE,SCVCode.code_value ||' - '|| SCVCode.CODE_VAL_DESC document_type_DESC,DEPTDESC||'('||ind.indentor_dept||')' DEPT,UMC.CONSUMP_DT,UMC.DEST_SLOC,UMC.CURRENCY,UMC.PUR_GRP,UMC.PROC_TYPE,
UMC.DEST_SLOC,INTBUY_H.SCH_CART_NO,umc.PUR_GRP ||' - '|| pur.DESCRIPTION pg_desc, UMCPCODE.CODE_VAL_DESC SPARE,UMC.DEST_SLOC ||' - '|| LOC.DESCRIPTION SLOC_DESC
--,umcp.ins_spare
            FROM
T_SIS_INDENT_DETAILS IND  INNER JOIN T_SIS_UMC_INDENT_DETAILS UMC on UMC.INDENT_ID= IND.INDENT_ID           
             inner join 
            T_SIS_CODE_VALUE SCV on scv.id= ind.INDENT_CURRENT_STATUS 
left join T_SIS_CODE_VALUE SCVCode on SCVCode.CODE_VALUE= umc.DOCUMENT_TYPE 
            left join
     T_SIS_INTELLIBUY_CHECK_ITEM INTBUY_I on INTBUY_I.INDENT_ID= IND.INDENT_ID and INTBUY_I.EXISTING_UMC=umc.REQ_UMC_NO
left join
     T_SIS_INTELLIBUY_CHECK_HEADER INTBUY_H on INTBUY_H.INDENT_ID= IND.INDENT_ID
 INNER JOIN t_s_dept_mst ON DEPTNO= ind.indentor_dept
 INNER JOIN T_UMC_PROD UMCP ON UMCP.UMC_CD= UMC.REQ_UMC_NO and UMCP.PLANT_CD=IND.INDENTOR_PLANT
 Inner Join T_S_PURGRP PUR ON pur.purgrp = umc.pur_grp
 Inner Join T_SIS_CODE_VALUE UMCPCODE on UMCPCODE.CODE_VALUE=umcp.ins_spare and UMCPCODE.CODETYPE_ID=9
 left Join T_S_SLOC LOC on LOC.sloc=UMC.DEST_SLOC and loc.plant=IND.INDENTOR_PLANT
            where INTBUY_I.ISACTIVE= 'Y' and IND.INDENT_ID= :INDENT_ID  order by IND.INDENT_ID ASC";

        #endregion


    }
}