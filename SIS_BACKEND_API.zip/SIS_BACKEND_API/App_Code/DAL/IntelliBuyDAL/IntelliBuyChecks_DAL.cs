﻿using Oracle.ManagedDataAccess.Client;
using SIS_BACKEND_API.Models;
using SIS_BACKEND_API.Models.IntelliBuyModel;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Net.Http.Headers;
using System.Net.Http;
using System.Reflection;
using System.Text;
using System.Web;
using SIS_BACKEND_API.Controllers.IntelliBuy;
using System.Threading.Tasks;
using System.Runtime.CompilerServices;
using Newtonsoft.Json;
using System.Xml.Linq;
using Newtonsoft.Json.Linq;

namespace SIS_BACKEND_API.App_Code.DAL.IntelliBuyDAL
{
    public class IntelliBuyChecks_DAL
    {
        private string strConnSISDB = ConfigurationManager.ConnectionStrings["OracleConnection"].ConnectionString;

        private ConnectionOracleDB objConn;
        private DataTable dtResult;

        public async Task<List<IntelliBuyIndentDetails>> GetIntelliBuyChecksDetails(string IndentId)
        {
            var ObjIndentDetails = new List<IntelliBuyIndentDetails>();
            try
            {
                IntelliBuyChecksController controller = new IntelliBuyChecksController();
                DataTable dtTable = new DataTable();
                dtTable = GetIntelliBuyChecksDetailsFromId(IndentId);
                if (dtTable.Rows.Count == 0)
                {
                    dtTable = GetIntelliBuyChecksHeaderAndItem(IndentId);
                }
                string jsondtresult = JsonConvert.SerializeObject(dtTable);

                //List<IntelliBuyIndentDetails> ObjIntelliBuyIndentDetails = JsonConvert.DeserializeObject<List<IntelliBuyIndentDetails>>(jsondtresult);
               
                string reqDateStr = "";
                string ConsDateStr = "";
                string arc_vmiStr = "";
                foreach (DataRow item in dtTable.Rows)
                {
                    string responseContent = "";
                    //responseContent = await Get_ReqConsum_ODATA(item["REQ_UMC_NO"].ToString(), "931", item["INDENTOR_PLANT"].ToString()).ConfigureAwait(false);
                    if (!String.IsNullOrEmpty(responseContent))
                    {
                        dynamic responseObject = JsonConvert.DeserializeObject<dynamic>(responseContent);
                        reqDateStr = responseObject.d.results[0].ReqDate;
                        ConsDateStr = responseObject.d.results[0].ConsDate;
                        arc_vmiStr = responseObject.d.results[0].ARC_VMI;
                    }
                    var newItem = new IntelliBuyIndentDetails
                    {
                        SRNO= Convert.ToInt32(item["srno"].ToString()),
                        INDENT_ID = Convert.ToInt32(item["INDENT_ID"].ToString()),
                        INDENTOR_PLANT = item["INDENTOR_PLANT"].ToString(),
                        REQ_UMC_NO = item["REQ_UMC_NO"].ToString(),
                        REQ_UMC_BGG = item["REQ_UMC_BGG"].ToString(),
                        REQUIREMENT_DATE = item["REQUIREMENT_DATE"].ToString(),
                        PRICE_PER_ITEM = item["PRICE_PER_ITEM"].ToString(),
                        DOCUMENT_TYPE = item["DOCUMENT_TYPE"].ToString(),
                        FOD_TYPE = item["FOD_TYPE"].ToString(),
                        REQ_UMC_DESC = item["REQ_UMC_DESC"].ToString(),
                        UOM = item["UOM"].ToString(),
                        INDENT_CURRENT_STATUS = item["INDENT_CURRENT_STATUS"].ToString(),
                        INDENT_CURRENT_STATUS_CODE = item["INDENT_CURRENT_STATUS_CODE"].ToString(),
                        //EXISTING_UMC = item["EXISTING_UMC"].ToString(),
                        TAGGEDUMC = item["TAGGEDUMC"].ToString(),
                        TOTAL_SAP_DOC_QTY = Convert.ToInt32(item["TOTAL_SAP_DOC_QTY"].ToString()),
                        ALLOWEDQTY = Convert.ToInt32(item["ALLOWEDQTY"].ToString()),
                        UMC_INDENT_ID = Convert.ToInt32(item["UMC_INDENT_ID"].ToString()),
                        INDENTOR_DEPT = item["INDENTOR_DEPT"].ToString(),
                        INDENT_DESC = item["INDENT_DESC"].ToString(),
                        INDENT_REMARKS = item["INDENT_REMARKS"].ToString(),
                        ISACTIVE = item["ISACTIVE"].ToString(),
                        IS_REFURBISHABLE = item["IS_REFURBISHABLE"].ToString(),
                        ITEM_ID = Convert.ToInt32(item["ITEM_ID"].ToString()),
                        QTY = item["QTY"].ToString(),
                        SYS_REQ_DATE = item["SYS_REQ_DATE"].ToString(),
                        DOCUMENT_TYPE_DESC = item["DOCUMENT_TYPE_DESC"].ToString(),
                        DEPT = item["DEPT"].ToString(),
                        CONSUMP_DT = item["CONSUMP_DT"].ToString(),
                        ReqDate = reqDateStr,
                        ConsDate = ConsDateStr,
                        ARC_VMI = arc_vmiStr
                    };

                    ObjIndentDetails.Add(newItem);

                }
            }
            catch (Exception ex)
            {

               
            }

            return ObjIndentDetails;

        }

        public DataTable GetIntelliBuyChecksDetailsFromId(string IndentId)
        {

            objConn = new ConnectionOracleDB(strConnSISDB, DBConst.oraGetIntelliBuyChecksDetailsFromId, CommandType.Text, true);

            try
            {
                //Open the connection.
                objConn.OpenConnection();

                //Bind the parameters.            
                objConn.AddParameters(":INDENT_ID", IndentId);

                //Execute the query and assign the resultant table.
                objConn.FillDataTable();
                dtResult = objConn.ResultantTable;

                //Close the connection
                objConn.CloseConnection();
            }
            catch (Exception excp)
            {
                throw excp;
            }

            //return the final Data Table.
            return dtResult;
        }
        public DataTable GetIntelliBuyChecksHeaderAndItem(string IndentId)
        {

            objConn = new ConnectionOracleDB(strConnSISDB, DBConst.oraGetIntelliBuyChecksHeaderAndItem, CommandType.Text, true);

            try
            {
                //Open the connection.
                objConn.OpenConnection();

                //Bind the parameters.            
                objConn.AddParameters(":INDENT_ID", IndentId);

                //Execute the query and assign the resultant table.
                objConn.FillDataTable();
                dtResult = objConn.ResultantTable;

                //Close the connection
                objConn.CloseConnection();
            }
            catch (Exception excp)
            {
                throw excp;
            }

            //return the final Data Table.
            return dtResult;
        }
        public int GetIntelliBuyChecksDetailsFromIndentId(string IndentId)
        {

            objConn = new ConnectionOracleDB(strConnSISDB, DBConst.oraGetIntelliBuyChecksDetailsFromINDENT_ID, CommandType.Text, true);

            try
            {
                //Open the connection.
                objConn.OpenConnection();

                //Bind the parameters.            
                objConn.AddParameters(":INDENT_ID", IndentId);

                //Execute the query and assign the resultant table.
                objConn.FillDataTable();
                dtResult = objConn.ResultantTable;

                //Close the connection
                objConn.CloseConnection();
            }
            catch (Exception excp)
            {
                throw excp;
            }

            //return the final Data Table.
            if (dtResult.Rows.Count > 0) { return Convert.ToInt32(dtResult.Rows[0]["HEADER_ID"].ToString()); }
            else { return 0; }

        }

        internal int SaveIntelliBuyDetails(IntelliBuyChecksHeader header, List<IntelliBuyIndentDetails> items)
        {
            int returnresponse = 0;

            if (GetIntelliBuyChecksDetailsFromIndentId(header.INDENT_ID) > 0)
            {
                returnresponse = UpdateIntelliBuyCheckItem(header, items);
            }
            else
            {
                returnresponse = InsertIntelliBuyCheckItem(header, items);
            }
            return returnresponse;
        }

        internal int InsertIntelliBuyCheckItem(IntelliBuyChecksHeader header, List<IntelliBuyIndentDetails> items)
        {
            int attachInsertCount = 0;

            using (OracleConnection connection = new OracleConnection(strConnSISDB))
            {
                connection.Open();

                OracleCommand command = connection.CreateCommand();
                OracleTransaction transaction;

                transaction = connection.BeginTransaction();
                command.Transaction = transaction;
                string HeaderID = "0";
                try
                {
                    command.CommandText = DBConst.oraInsertIntelliBuyCheckHeader;
                    command.Parameters.Clear();

                    command.Parameters.Add(":INDENT_ID", header.INDENT_ID);
                    command.Parameters.Add(":INDENTER_LOC", String.IsNullOrEmpty(header.INDENTER_LOC) ? String.Empty : header.INDENTER_LOC);
                    command.Parameters.Add(":INDENTOR_PLANT", header.INDENTOR_PLANT);
                    command.Parameters.Add(":INDENTER_DEPT", String.IsNullOrEmpty(header.INDENTER_DEPT) ? String.Empty : header.INDENTER_DEPT);
                    command.Parameters.Add(":INDENT_DESC", header.INDENT_DESC);
                    command.Parameters.Add(":INDENT_REMARKS", header.INDENT_REMARKS);
                    command.Parameters.Add(":CRT_BY", String.IsNullOrEmpty(header.INDENT_CRT_BY) ? String.Empty : header.INDENT_CRT_BY);
                    command.Parameters.Add(":INDENT_STATUS", String.IsNullOrEmpty(header.INDENT_STATUS) ? String.Empty : header.INDENT_STATUS);
                    command.Parameters.Add(":SCH_CART_NO", header.SCH_CART_NO);
                    command.Parameters.Add(":SCH_USR_NAME", header.SCH_USR_NAME);
                    command.ExecuteNonQuery();

                    HeaderID = GetMaxHeaderId().ToString();
                    if (HeaderID.All(char.IsDigit))
                    {
                        foreach (var objintelliBuyChecksItems in items)
                        {
                            if (!String.IsNullOrEmpty(header.HEADER_ID.ToString()))
                            {
                                command.Parameters.Clear();
                                command.CommandText = DBConst.oraInsertIntelliBuyCheckItem;
                                //command.Parameters.Add(":ITEM_ID", objintelliBuyChecksItems); 27
                                command.Parameters.Add(":HEADERID", HeaderID);
                                command.Parameters.Add(":INDENT_ID", objintelliBuyChecksItems.INDENT_ID);
                                command.Parameters.Add(":SCI_MATL_DESC", objintelliBuyChecksItems.REQ_UMC_DESC);
                                command.Parameters.Add(":EXISTING_UMC", objintelliBuyChecksItems.REQ_UMC_NO);
                                command.Parameters.Add(":EXISTING_UMC_DESC", "");
                                command.Parameters.Add(":SCI_MATL_GROUP", "");
                                command.Parameters.Add(":SCI_PROD_TYPE", "");
                                command.Parameters.Add(":SCI_PLANT_CD", objintelliBuyChecksItems.INDENTOR_PLANT);
                                command.Parameters.Add(":SCI_STRG_LOC", "");
                                command.Parameters.Add(":SCI_PUR_GROUP", "");
                                command.Parameters.Add(":SCI_DOC_TYPE", "");
                                command.Parameters.Add(":SCI_QTY", objintelliBuyChecksItems.QTY);
                                command.Parameters.Add(":SCI_QTY_UNIT", objintelliBuyChecksItems.UOM);
                                command.Parameters.Add(":SCI_PRICE", "");
                                command.Parameters.Add(":SCI_FRN_CURR_CD", "");
                                //command.Parameters.Add(":SCI_REQD_ON_DT", "");
                                //command.Parameters.Add(":CONSUMP_DT", "");
                                command.Parameters.Add(":SCI_STATUS", "");
                                command.Parameters.Add(":SCI_DEL_IND", "");
                                command.Parameters.Add(":SCI_SAP_ERR_MSG", "");
                                command.Parameters.Add(":SCI_PROP_TAG", "");
                                command.Parameters.Add(":SCI_REFFB_TAG", "");
                                command.Parameters.Add(":SCI_PERISIBL_TAG", "");
                                command.Parameters.Add(":SCI_SPARE_CAT", "");
                                command.Parameters.Add(":SCI_REMARKS", "");
                                //command.Parameters.Add(":IS_ACTIVE", "Y");
                                command.Parameters.Add(":CRT_BY", "");
                                //command.Parameters.Add(":MOD_BY", "");
                                command.Parameters.Add(":MAX_QTY", objintelliBuyChecksItems.QTY);

                                attachInsertCount = command.ExecuteNonQuery();
                            }
                        }
                    }
                    command.CommandText = DBConst.UpdateStatus;
                    command.Parameters.Clear();
                    command.Parameters.Add(":INDENT_ID", header.INDENT_ID);
                    command.ExecuteNonQuery();
                    //else { attachInsertCount = BasicId; }
                    transaction.Commit();
                }
                catch (OracleException excp)
                {
                    transaction.Rollback();
                    throw excp;
                }
                catch (Exception excp)
                {
                    transaction.Rollback();
                    throw excp;
                }
            }
            return attachInsertCount;
        }

        internal int UpdateIntelliBuyCheckItem(IntelliBuyChecksHeader header, List<IntelliBuyIndentDetails> items)
        {
            int attachInsertCount = 0;

            using (OracleConnection connection = new OracleConnection(strConnSISDB))
            {
                connection.Open();

                OracleCommand command = connection.CreateCommand();
                OracleTransaction transaction;

                transaction = connection.BeginTransaction();
                command.Transaction = transaction;
                string HeaderID = "0";
                try
                {
                    command.CommandText = DBConst.oraUpdateIntelliBuyCheckHeader;
                    command.Parameters.Clear();


                    command.Parameters.Add(":INDENTER_LOC", String.IsNullOrEmpty(header.INDENTER_LOC) ? String.Empty : header.INDENTER_LOC);
                    command.Parameters.Add(":INDENTOR_PLANT", Convert.ToInt64(header.INDENTOR_PLANT));
                    command.Parameters.Add(":INDENTER_DEPT", String.IsNullOrEmpty(header.INDENTER_DEPT) ? String.Empty : header.INDENTER_DEPT);
                    command.Parameters.Add(":INDENT_DESC", header.INDENT_DESC);
                    command.Parameters.Add(":INDENT_REMARKS", header.INDENT_REMARKS);
                    command.Parameters.Add(":CRT_BY", String.IsNullOrEmpty(header.INDENT_CRT_BY) ? String.Empty : header.INDENT_CRT_BY);
                    command.Parameters.Add(":INDENT_STATUS", String.IsNullOrEmpty(header.INDENT_STATUS) ? String.Empty : header.INDENT_STATUS);
                    command.Parameters.Add(":SCH_CART_NO", header.SCH_CART_NO);
                    command.Parameters.Add(":SCH_USR_NAME", header.SCH_USR_NAME);
                    command.Parameters.Add(":ISACTIVE", header.ISACTIVE);
                    command.Parameters.Add(":INDENT_ID", header.INDENT_ID);
                    int i = command.ExecuteNonQuery();

                    HeaderID = GetIntelliBuyChecksDetailsFromIndentId(header.INDENT_ID).ToString();
                    if (HeaderID.All(char.IsDigit))
                    {
                        foreach (var objintelliBuyChecksItems in items)
                        {
                            if (!String.IsNullOrEmpty(header.HEADER_ID.ToString()))
                            {
                                command.Parameters.Clear();
                                command.CommandText = DBConst.oraUpdateIntelliBuyCheckItem;

                                //command.Parameters.Add(":HEADERID", HeaderID);                          
                                command.Parameters.Add(":SCI_MATL_DESC", objintelliBuyChecksItems.REQ_UMC_DESC);

                                command.Parameters.Add(":EXISTING_UMC_DESC", objintelliBuyChecksItems.REQ_UMC_DESC);
                                command.Parameters.Add(":SCI_MATL_GROUP", "");
                                command.Parameters.Add(":SCI_PROD_TYPE", "");
                                command.Parameters.Add(":SCI_PLANT_CD",
                                objintelliBuyChecksItems.INDENTOR_PLANT);
                                command.Parameters.Add(":SCI_STRG_LOC", "");
                                command.Parameters.Add(":SCI_PUR_GROUP", "");
                                command.Parameters.Add(":SCI_DOC_TYPE", "");
                                command.Parameters.Add(":SCI_QTY", objintelliBuyChecksItems.QTY);
                                command.Parameters.Add(":SCI_QTY_UNIT", objintelliBuyChecksItems.UOM);
                                command.Parameters.Add(":SCI_PRICE", "");
                                command.Parameters.Add(":SCI_FRN_CURR_CD", "");
                                //command.Parameters.Add(":SCI_REQD_ON_DT", "");
                                //command.Parameters.Add(":CONSUMP_DT", "");
                                command.Parameters.Add(":SCI_STATUS", "");
                                command.Parameters.Add(":SCI_DEL_IND", "");
                                command.Parameters.Add(":SCI_SAP_ERR_MSG", "");
                                command.Parameters.Add(":SCI_PROP_TAG", "");
                                command.Parameters.Add(":SCI_REFFB_TAG", "");
                                command.Parameters.Add(":SCI_PERISIBL_TAG", "");
                                command.Parameters.Add(":SCI_SPARE_CAT", "");
                                command.Parameters.Add(":SCI_REMARKS", "");
                                command.Parameters.Add(":IS_ACTIVE", objintelliBuyChecksItems.ISACTIVE);
                                command.Parameters.Add(":CRT_BY", "");
                                command.Parameters.Add(":MAX_QTY", objintelliBuyChecksItems.ALLOWEDQTY);
                                command.Parameters.Add(":INDENT_ID", header.INDENT_ID);
                                command.Parameters.Add(":EXISTING_UMC", objintelliBuyChecksItems.REQ_UMC_NO);

                                attachInsertCount = command.ExecuteNonQuery();
                            }
                        }
                    }
                    //else { attachInsertCount = BasicId; }
                    transaction.Commit();
                }
                catch (OracleException excp)
                {
                    transaction.Rollback();
                    throw excp;
                }
                catch (Exception excp)
                {
                    transaction.Rollback();
                    throw excp;
                }
            }
            return attachInsertCount;
        }


        public int GetMaxHeaderId()
        {
            using (OracleConnection connection = new OracleConnection(strConnSISDB))
            {
                connection.Open();
                int RntVal = 0;
                try
                {
                    using (OracleCommand command = new OracleCommand(DBConst.oraGetMaxHeaderID, connection))
                    {

                        int maxId = Convert.ToInt32(command.ExecuteScalar());


                        RntVal = maxId;

                    }


                    return RntVal;
                }
                catch (Exception ex)
                {
                    return RntVal;
                }
            }

            // Check the number of rows affected

        }



        public void UpdateStatusForIndId(string indId, ref OracleTransaction transaction, ref OracleConnection connection)
        {

            string query = DBConst.UpdateStatus;

            using (OracleCommand command = new OracleCommand(query, connection))
            {

                command.Parameters.Add(":INDENT_ID", indId);



                command.ExecuteNonQuery();
            }




        }

        #region ODATA 
        //public async Task<string> Get_ReqConsum_ODATA(string UMCNO, string PurGrp, string Plant)
        //{
        //    string BaseURL = ConfigurationManager.AppSettings["ODataBaseURL"];
        //    string apiUrl = BaseURL + "opu/odata/sap/YMPI_INDENT_ARC_VMI_SRV/GetReqDateSet?$filter=( Material eq '" + UMCNO + "' and PurGrp eq '" + PurGrp + "' and Plant eq '" + Plant + "' )&$format=json";
        //    string responseData = "";

        //    using (System.Net.Http.HttpClient client = new System.Net.Http.HttpClient())
        //    {
        //        // Setting the username and password for basic authentication
        //        string username = ConfigurationManager.AppSettings["ODataUserName"];
        //        string password = ConfigurationManager.AppSettings["ODataPassword"];
        //        string authInfo = username + ":" + password;
        //        string base64AuthInfo = Convert.ToBase64String(Encoding.UTF8.GetBytes(authInfo));
        //        client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Basic", base64AuthInfo);

        //        try
        //        {
        //            HttpResponseMessage response = await client.GetAsync(apiUrl).ConfigureAwait(false);

        //            if (response.IsSuccessStatusCode)
        //            {
        //                responseData = await response.Content.ReadAsStringAsync();
        //            }
        //            else
        //            {
        //                responseData = "";// or BadRequest() or NotFound() based on your needs
        //            }
        //        }
        //        catch (HttpRequestException ex)
        //        {
        //            responseData = ""; // Return the exception details
        //        }
        //    }
        //    return responseData;
        //}
        #endregion


        #region comented code
        //internal DataTable GetWorkFlowDetailsFromID(string workFlowID)
        //{
        //    //List< WorkFlowModel> workFlowModel = new List<WorkFlowModel>();
        //    //Instantiate the connection object.
        //    objConn = new ConnectionOracleDB(strConnSISDB, DBConst.oraSelectWorkFlow_WithID, CommandType.Text, true);

        //    try
        //    {
        //        //Open the connection.
        //        objConn.OpenConnection();

        //        //Bind the parameters.                
        //        objConn.AddParameters(":WF_ID", workFlowID);
        //        //Execute the query and assign the resultant table.
        //        objConn.FillDataTable();
        //        dtResult = objConn.ResultantTable;

        //        //Close the connection
        //        objConn.CloseConnection();
        //    }
        //    catch (Exception excp)
        //    {
        //        throw excp;
        //    }

        //    //return the final Data Table.
        //    return dtResult;
        //}

        //internal DataTable GetApprover(string DEPT, string PLANT)
        //{
        //    //List< WorkFlowModel> workFlowModel = new List<WorkFlowModel>();
        //    //Instantiate the connection object.
        //    objConn = new ConnectionOracleDB(strConnSISDB, DBConst.getApprover, CommandType.Text, true);

        //    try
        //    {
        //        //Open the connection.
        //        objConn.OpenConnection();
        //        objConn.AddParameters(":DEPT", DEPT);
        //        objConn.AddParameters(":PLANT", PLANT);
        //        //Bind the parameters.                

        //        //Execute the query and assign the resultant table.
        //        objConn.FillDataTable();
        //        dtResult = objConn.ResultantTable;

        //        //Close the connection
        //        objConn.CloseConnection();
        //    }
        //    catch (Exception excp)
        //    {
        //        throw excp;
        //    }

        //    //return the final Data Table.
        //    return dtResult;
        //}

        //internal int UpdateWorkFlowDetailsFromID(WorkFlowModel workflowmodel)
        //{
        //    int attachInsertCount;

        //    using (OracleConnection connection = new OracleConnection(strConnSISDB))
        //    {
        //        connection.Open();

        //        OracleCommand command = connection.CreateCommand();
        //        OracleTransaction transaction;

        //        transaction = connection.BeginTransaction();
        //        command.Transaction = transaction;

        //        try
        //        {
        //            command.CommandText = DBConst.oraUpdateWorkFlow_WithID;
        //            command.Parameters.Clear();
        //            command.Parameters.Add(":WF_STATUS", workflowmodel.WF_STATUS);
        //            command.Parameters.Add(":MOD_BY", workflowmodel.MOD_BY);
        //            command.Parameters.Add(":APPROVED_QTY", workflowmodel.APPROVED_QTY);
        //            command.Parameters.Add(":WF_REMARKS", workflowmodel.WF_REMARKS);
        //            command.Parameters.Add(":APP_BY", workflowmodel.MOD_BY);
        //            command.Parameters.Add(":WF_ID", workflowmodel.WF_ID);


        //            attachInsertCount = command.ExecuteNonQuery();

        //            if (attachInsertCount > 0)
        //            {

        //                command.Parameters.Clear();
        //                command.CommandText = DBConst.oraInsertWorkFlowAudit;
        //                command.Parameters.Clear();
        //                command.Parameters.Add(":WF_ID", workflowmodel.WF_ID);
        //                command.Parameters.Add(":WF_TYPE", workflowmodel.WF_TYPE);
        //                command.Parameters.Add(":WF_STATUS", workflowmodel.WF_STATUS);

        //                command.Parameters.Add(":WF_REMARKS", workflowmodel.WF_REMARKS);
        //                command.Parameters.Add(":CRT_BY", workflowmodel.MOD_BY);
        //                attachInsertCount = command.ExecuteNonQuery();

        //            }
        //            transaction.Commit();
        //        }
        //        catch (OracleException excp)
        //        {
        //            transaction.Rollback();
        //            throw excp;
        //        }
        //        catch (Exception excp)
        //        {
        //            transaction.Rollback();
        //            throw excp;
        //        }
        //    }
        //    return attachInsertCount;
        //}

        #endregion
        public class DBConst
        {
            #region IntelliBuyChecks
            //added by Animesh

            public const string oraGetIntelliBuyChecksDetailsFromId = @"SELECT ROW_NUMBER() OVER (ORDER BY UMC.UMC_INDENT_ID) AS srno , IND.INDENT_ID,IND.INDENTOR_PLANT,UMC.REQ_UMC_NO,UMC.REQ_UMC_BGG,to_char(umc.requirement_date, 'DD-MON-YYYY') as requirement_date,UMC.PRICE_PER_ITEM,umc.document_type,
umc.fod_type,umc.req_umc_desc,umc.qty ,UMC.UOM,INTBUY_H.INDENT_STATUS,scv.code_val_desc INDENT_CURRENT_STATUS,INDENT_CURRENT_STATUS INDENT_CURRENT_STATUS_CODE , EXISTING_UMC || '-' || EXIS_UMC_DESC as TaggedUMC,UMC.TOTAL_SAP_DOC_QTY,(QTY-TOTAL_SAP_DOC_QTY) as AllowedQty,UMC.UMC_INDENT_ID,IND.INDENTOR_DEPT,IND.INDENT_DESC,IND.INDENT_REMARKS,UMC.ISACTIVE,UMC.IS_REFURBISHABLE,SCVCode.code_value ||' - '|| SCVCode.CODE_VAL_DESC document_type_DESC,DEPTDESC||'('||ind.indentor_dept||')' DEPT,UMC.CONSUMP_DT
            FROM
T_SIS_INDENT_DETAILS IND  INNER JOIN T_SIS_UMC_INDENT_DETAILS UMC on UMC.INDENT_ID= IND.INDENT_ID
            left join T_SIS_INTELLIBUY_CHECK_HEADER INTBUY_H
            on INTBUY_H.INDENT_ID= IND.INDENT_ID inner join T_SIS_CODE_VALUE SCV on scv.id= ind.INDENT_CURRENT_STATUS 
left join T_SIS_CODE_VALUE SCVCode on SCVCode.CODE_VALUE= umc.DOCUMENT_TYPE 
 INNER JOIN t_s_dept_mst ON DEPTNO= ind.indentor_dept
where UMC.ISACTIVE= 'Y' and IND.ISACTIVE= 'Y' and IND.INDENT_ID= :INDENT_ID and IND.INDENT_CURRENT_STATUS= '15' and IND.INDENT_STATUS='CMPLT' order by IND.INDENT_ID ASC";
            public const string oraGetIntelliBuyChecksHeadersDetailsFromId = @"DECLARE
  INDENTCURSTATUS number := 0;  
BEGIN
  select INDENT_CURRENT_STATUS into INDENTCURSTATUS from T_SIS_INDENT_DETAILS where ISACTIVE='Y' and INDENT_CURRENT_STATUS= '16' and INDENT_ID=:INDENT_ID
  IF (INDENTCURSTATUS = 16) 
    THEN
     SELECT IND.INDENT_ID,IND.INDENTOR_PLANT,UMC.REQ_UMC_NO,UMC.REQ_UMC_BGG,to_char(umc.requirement_date, 'DD-MON-YYYY') as requirement_date,UMC.PRICE_PER_ITEM,umc.document_type,
umc.fod_type,umc.req_umc_desc,umc.qty ,UMC.UOM,INTBUY_H.INDENT_STATUS,scv.code_val_desc INDENT_CURRENT_STATUS, EXISTING_UMC || '-' || EXIS_UMC_DESC as TaggedUMC,UMC.TOTAL_SAP_DOC_QTY,(QTY-TOTAL_SAP_DOC_QTY) as AllowedQty,UMC.UMC_INDENT_ID,IND.INDENTOR_DEPT,IND.INDENT_DESC,IND.INDENT_REMARKS,UMC.ISACTIVE
            FROM
T_SIS_INDENT_DETAILS IND  INNER JOIN T_SIS_UMC_INDENT_DETAILS UMC on UMC.INDENT_ID= IND.INDENT_ID
            left join T_SIS_INTELLIBUY_CHECK_HEADER INTBUY_H
            on INTBUY_H.INDENT_ID= IND.INDENT_ID inner join T_SIS_CODE_VALUE SCV on scv.id= ind.INDENT_CURRENT_STATUS where UMC.ISACTIVE= 'Y' and IND.ISACTIVE= 'Y' and IND.INDENT_ID= :INDENT_ID and IND.INDENT_CURRENT_STATUS= '16' order by IND.INDENT_ID ASC
    ELSE
     select * from T_SIS_INTELLIBUY_CHECK_HEADER INTE_CH inner join T_SIS_INTELLIBUY_CHECK_ITEM INTE_CI on INTE_CI.HEADER_ID = INTE_CH.HEADER_ID and INTE_CI.INDENT_ID = INTE_CH.INDENT_ID where INTE_CH.INDENT_ID=:INDENT_ID and INTE_CI.ISACTIVE='Y' 
  END IF;
END;";

            public const string oraInsertIntelliBuyCheckHeader = @"insert into T_SIS_INTELLIBUY_CHECK_HEADER (HEADER_ID ,INDENT_ID ,INDENTER_LOC ,INDENTOR_PLANT ,INDENTER_DEPT ,INDENT_DESC ,INDENT_REMARKS ,CRT_BY ,
CRT_DT ,INDENT_STATUS ,SCH_CART_NO ,SCH_CRT_DT ,SCH_USR_NAME ,ISACTIVE) values ((SELECT coalesce(MAX(HEADER_ID),0) + 1 FROM T_SIS_INTELLIBUY_CHECK_HEADER) ,
:INDENT_ID ,:INDENTER_LOC ,:INDENTOR_PLANT ,:INDENTER_DEPT ,:INDENT_DESC ,:INDENT_REMARKS ,:CRT_BY ,
sysdate  ,:INDENT_STATUS ,:SCH_CART_NO ,sysdate ,:SCH_USR_NAME ,'Y')";
            public const string oraInsertIntelliBuyCheckItem = @"insert into T_SIS_INTELLIBUY_CHECK_ITEM (ITEM_ID,HEADER_ID,INDENT_ID,SCI_MATL_DESC,EXISTING_UMC,EXISTING_UMC_DESC,SCI_MATL_GROUP,SCI_PROD_TYPE,SCI_PLANT_CD,SCI_STRG_LOC ,SCI_PUR_GROUP ,SCI_DOC_TYPE ,SCI_QTY ,SCI_QTY_UNIT ,SCI_PRICE ,SCI_FRN_CURR_CD ,SCI_REQD_ON_DT ,CONSUMP_DT ,SCI_STATUS ,SCI_DEL_IND ,SCI_SAP_ERR_MSG ,SCI_PROP_TAG ,SCI_REFFB_TAG ,SCI_PERISIBL_TAG ,SCI_SPARE_CAT ,SCI_REMARKS ,ISACTIVE ,CRT_BY,MAX_QTY ,CRT_DT ) values 
((SELECT coalesce(MAX(ITEM_ID),0) + 1 FROM T_SIS_INTELLIBUY_CHECK_ITEM) ,:HEADER_ID ,:INDENT_ID,:SCI_MATL_DESC ,:EXISTING_UMC ,:EXISTING_UMC_DESC ,:SCI_MATL_GROUP ,:SCI_PROD_TYPE ,:SCI_PLANT_CD ,:SCI_STRG_LOC ,:SCI_PUR_GROUP ,:SCI_DOC_TYPE ,:SCI_QTY ,:SCI_QTY_UNIT ,:SCI_PRICE ,:SCI_FRN_CURR_CD ,sysdate ,sysdate ,:SCI_STATUS ,:SCI_DEL_IND ,:SCI_SAP_ERR_MSG ,:SCI_PROP_TAG ,:SCI_REFFB_TAG ,:SCI_PERISIBL_TAG ,:SCI_SPARE_CAT ,:SCI_REMARKS ,'Y' ,:CRT_BY ,:MAX_QTY,sysdate )";

            public const string oraGetMaxHeaderID = @"(SELECT coalesce(MAX(HEADER_ID),0) + 1 as HEADER_ID FROM T_SIS_INTELLIBUY_CHECK_HEADER)";

            public const string oraUpdateIntelliBuyCheckHeader = @"  UPDATE T_SIS_INTELLIBUY_CHECK_HEADER SET  INDENTER_LOC=:INDENTER_LOC ,INDENTOR_PLANT=:INDENTOR_PLANT ,INDENTER_DEPT=:INDENTER_DEPT ,INDENT_DESC=:INDENT_DESC ,INDENT_REMARKS=:INDENT_REMARKS ,MOD_BY=:CRT_BY ,INDENT_STATUS=:INDENT_STATUS ,SCH_CART_NO=:SCH_CART_NO  ,SCH_USR_NAME=:SCH_USR_NAME ,ISACTIVE=:ISACTIVE,MOD_DT=sysdate where INDENT_ID=:INDENT_ID ";

            public const string oraUpdateIntelliBuyCheckItem = @"update T_SIS_INTELLIBUY_CHECK_ITEM set SCI_MATL_DESC=:SCI_MATL_DESC  ,EXISTING_UMC_DESC=:EXISTING_UMC_DESC 
            ,SCI_MATL_GROUP=:SCI_MATL_GROUP ,SCI_PROD_TYPE=:SCI_PROD_TYPE ,SCI_PLANT_CD=:SCI_PLANT_CD ,SCI_STRG_LOC=:SCI_STRG_LOC ,SCI_PUR_GROUP=:SCI_PUR_GROUP ,SCI_DOC_TYPE=:SCI_DOC_TYPE ,SCI_QTY=:SCI_QTY ,SCI_QTY_UNIT=:SCI_QTY_UNIT ,SCI_PRICE=:SCI_PRICE ,
            SCI_FRN_CURR_CD=:SCI_FRN_CURR_CD ,SCI_REQD_ON_DT=sysdate ,CONSUMP_DT=sysdate ,SCI_STATUS=:SCI_STATUS ,SCI_DEL_IND=:SCI_DEL_IND ,           SCI_SAP_ERR_MSG=:SCI_SAP_ERR_MSG ,SCI_PROP_TAG=:SCI_PROP_TAG ,SCI_REFFB_TAG=:SCI_REFFB_TAG ,SCI_PERISIBL_TAG=:SCI_PERISIBL_TAG ,SCI_SPARE_CAT=:SCI_SPARE_CAT ,SCI_REMARKS=:SCI_REMARKS ,ISACTIVE=:IS_ACTIVE ,MOD_BY=:CRT_BY ,MAX_QTY=:MAX_QTY,MOD_DT=SYSDATE
            where  INDENT_ID=:INDENT_ID and EXISTING_UMC=:EXISTING_UMC";
            //to_char(HEADER_ID)=:HEADER_ID and
            public const string oraGetIntelliBuyChecksDetailsFromINDENT_ID = @"Select * from T_SIS_INTELLIBUY_CHECK_HEADER where INDENT_ID=:INDENT_ID";
            public const string oraGetIntelliBuyChecksHeaderAndItem = @"SELECT  ROW_NUMBER() OVER (ORDER BY INTBUY_I.ITEM_ID) AS srno ,IND.INDENT_ID,IND.INDENTOR_PLANT,UMC.REQ_UMC_NO,UMC.REQ_UMC_BGG,to_char(umc.requirement_date, 'DD-MON-YYYY') as requirement_date,UMC.PRICE_PER_ITEM,umc.document_type,
umc.fod_type,umc.req_umc_desc ,UMC.UOM,scv.code_val_desc INDENT_CURRENT_STATUS,ind.INDENT_CURRENT_STATUS INDENT_CURRENT_STATUS_CODE , umc.EXISTING_UMC || '-' || umc.EXIS_UMC_DESC as TaggedUMC,
UMC.TOTAL_SAP_DOC_QTY,(QTY-TOTAL_SAP_DOC_QTY) as AllowedQty,UMC.UMC_INDENT_ID,IND.INDENTOR_DEPT,IND.INDENT_DESC,IND.INDENT_REMARKS,UMC.ISACTIVE,UMC.IS_REFURBISHABLE
,INTBUY_I.item_id,INTBUY_I.MAX_QTY QTY,INTBUY_I.SYS_REQ_DATE,SCVCode.code_value ||' - '|| SCVCode.CODE_VAL_DESC document_type_DESC,DEPTDESC||'('||ind.indentor_dept||')' DEPT,UMC.CONSUMP_DT
            FROM
T_SIS_INDENT_DETAILS IND  INNER JOIN T_SIS_UMC_INDENT_DETAILS UMC on UMC.INDENT_ID= IND.INDENT_ID           
             inner join 
            T_SIS_CODE_VALUE SCV on scv.id= ind.INDENT_CURRENT_STATUS 
left join T_SIS_CODE_VALUE SCVCode on SCVCode.CODE_VALUE= umc.DOCUMENT_TYPE 
            left join
     T_SIS_INTELLIBUY_CHECK_ITEM INTBUY_I on INTBUY_I.INDENT_ID= IND.INDENT_ID and INTBUY_I.EXISTING_UMC=umc.REQ_UMC_NO
 INNER JOIN t_s_dept_mst ON DEPTNO= ind.indentor_dept
            where INTBUY_I.ISACTIVE= 'Y' and IND.INDENT_ID= :INDENT_ID  order by IND.INDENT_ID ASC";
            public const string UpdateStatus = @"update T_SIS_INDENT_DETAILS set INDENT_CURRENT_STATUS='25'  where INDENT_ID=:INDENT_ID";
            #endregion


        }
    }
}