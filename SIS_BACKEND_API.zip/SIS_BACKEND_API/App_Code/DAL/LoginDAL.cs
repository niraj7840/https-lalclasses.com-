﻿
using SIS_BACKEND_API.Models;
using System;
using System.Configuration;
using Oracle.ManagedDataAccess.Client;



namespace SIS_BACKEND_API.App_Code.DAL
{
    public class LoginDAL
    {
        Otp_qry qry = new Otp_qry();
        string connectionString = ConfigurationManager.ConnectionStrings["OracleConnection"].ConnectionString;




        public object SaveUserDetails(LoginDetails obj)
        {
            OracleConnection connection = new OracleConnection(connectionString);

            connection.Open();
            OracleTransaction transaction = connection.BeginTransaction();
            int RntVal = 0;
            try
            {

                
                try
                {
                  //  if (!string.IsNullOrEmpty(obj.T_SII_USER_DETAILS.Otp))
                   // {
                      

                        if (obj.T_SII_USER_DETAILS.OTPType=="NEW")
                        {
                            SaveUserDetails(obj.T_SII_USER_DETAILS, ref transaction, ref connection);                           
                        }
                        else if(obj.T_SII_USER_DETAILS.OTPType == "RE_NEW")
                        {

                            string Old_OtpExists = GetLatestOTP(obj.T_SII_USER_DETAILS.adid, connection);
                            if(Old_OtpExists!="")
                            {
                                UpdateUserDetails(obj.T_SII_USER_DETAILS, ref transaction, ref connection, Old_OtpExists);
                            }                            
                        }

                        transaction.Commit();
                 //   }
                }
                catch (Exception ex)
                {
                    // Log exception here
                    transaction.Rollback();
                    throw;
                }


                return RntVal;
            }
            catch (Exception ex)
            {
                transaction.Rollback();
                return RntVal;
            }
            finally { connection.Close(); }


            // Check the number of rows affected

        }

        private string GetLatestOTP(string adid, OracleConnection connection)
        {
            string query = @"
    SELECT Otp 
    FROM (
      SELECT Otp, ROW_NUMBER() OVER(ORDER BY CREATEDDATE DESC) AS rn
      FROM T_SIS_USER_DETAILS
      WHERE adid = :adid
    )
    WHERE rn = 1";

            using (OracleCommand command = new OracleCommand(query, connection))
            {
                command.Parameters.Add(":adid", OracleDbType.Varchar2).Value = adid;

                // ExecuteScalar returns the first column of the first row in the result set
                object result = command.ExecuteScalar();

                // Check if the result is null
                if (result != null)
                {
                    return result.ToString();
                }
                else
                {
                    return null; // or you can return an empty string or throw an exception based on your requirement
                }
            }
        }



        public void SaveUserDetails(T_SII_USER_DETAILS obj, ref OracleTransaction transaction, ref OracleConnection connection)        {


            string query = qry.InsertOTPDetails;

            using (OracleCommand command = new OracleCommand(query, connection))
            {
                command.Parameters.Add(":adid", obj.adid);
                command.Parameters.Add(":email", obj.email);              
                command.Parameters.Add(":Otp", obj.Otp);
                command.Parameters.Add(":contactNumber", obj.contactNumber);
                command.Parameters.Add(":createdBy", obj.createdBy);
                command.Parameters.Add(":modifiedBy", obj.modifiedBy);             

                command.ExecuteNonQuery();
            }

        }


        public void UpdateUserDetails(T_SII_USER_DETAILS obj, ref OracleTransaction transaction, ref OracleConnection connection, string Old_OtpExists)
        {
            string query = qry.UpdateOTPDetails;
            using (OracleCommand command = new OracleCommand(query, connection))
            {
                command.Parameters.Add(":Otp", obj.Otp);
                command.Parameters.Add(":adid", obj.adid);
                command.Parameters.Add(":Odl_OTP", Old_OtpExists);

                command.ExecuteNonQuery();
            }
        }

        
     
      
    }

    public class Otp_qry
    {
        
        public string InsertOTPDetails = @"Insert into T_SIS_USER_DETAILS(adid,email,Otp,contactNumber,createdDate,createdBy,modificationDate,modifiedBy,OTPEXPIRYDATE)
values(:adid,:email,:Otp,:contactNumber,sysdate,:createdBy,sysdate,:modifiedBy, sysdate)";

        public string UpdateOTPDetails = @"update T_SIS_USER_DETAILS set Otp=:Otp, modificationDate=sysdate, OTPEXPIRYDATE=sysdate where adid=:adid and Otp=:Odl_OTP";

        public string OTPVerify = @"SELECT ADID, OTP, ((SYSDATE - OTPEXPIRYDATE) * 24 * 60) AS MinutesDifference
FROM (
  SELECT ADID, OTP, OTPEXPIRYDATE, ROW_NUMBER() OVER (ORDER BY CREATEDDATE DESC) AS rn
  FROM T_SIS_USER_DETAILS
  WHERE adid = 808516 and ((SYSDATE - OTPEXPIRYDATE) * 24 * 60) > = 5
)
WHERE rn = 1; ";
    }
}