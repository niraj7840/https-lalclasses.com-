﻿using Oracle.ManagedDataAccess.Client;
using Oracle.ManagedDataAccess.Types;
using SIS_BACKEND_API.Models;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Reflection;
using System.Runtime.Remoting.Messaging;
using System.Web;
using System.Web.Security;


namespace SIS_BACKEND_API.App_Code.DAL
{
    public class CapitalRequestDAL
    {

        //DataTable dtRet = null;
        private string strConnSISDB = ConfigurationManager.ConnectionStrings["OracleConnection"].ConnectionString;

        private ConnectionOracleDB objConn;
        private DataTable dtResult;

        //start of funtion
        public DataTable GetQuestion()
        {
            var data = new List<QuestionDetails>();
            DataTable dt = new DataTable();
            try
            {
                using (var connection = new OracleConnection(strConnSISDB))
                {
                    using (var command = new OracleCommand(DalQuery.queryGetQuestion, connection))
                    {
                        connection.Open();
                        using (var reader = command.ExecuteReader())
                        {
                            dt.Load(reader);
                            reader.Close();
                            connection.Close();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                return dt;
            }

            return dt;
        }

        //end of funtion

    }

    public class DalQuery
    {
        public const string queryGetQuestion = "select * from SAPSUR.T_SIS_CAP_QUES_MASTER";

 

           }


}