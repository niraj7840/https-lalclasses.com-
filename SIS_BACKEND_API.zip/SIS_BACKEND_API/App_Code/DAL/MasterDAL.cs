﻿using Oracle.ManagedDataAccess.Client;
using SIS_BACKEND_API.Models;

using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Reflection;
using System.Web;

namespace SIS_BACKEND_API.App_Code.DAL
{
    public class MasterDAL
    {
        string connectionString = ConfigurationManager.ConnectionStrings["OracleConnection"].ConnectionString;
        MASTER_QRY qry = new MASTER_QRY();
        public List<SaveDraft> GetDraftedList(string DEPT, string USERNAME)
        {
            var draftedList = new List<SaveDraft>();
            DataTable draftedTable = new DataTable();

            try
            {
                using (var connection = new OracleConnection(connectionString))
                {
                    string query = qry.getIndentDraftList;
                        using (var command = new OracleCommand(query, connection))
                    {
                        command.Parameters.Add(new OracleParameter("DEPT", DEPT));
                        command.Parameters.Add(new OracleParameter("USERNAME", USERNAME));
                        connection.Open();
                        using (var reader = command.ExecuteReader())
                        {
                            draftedTable.Load(reader);
                            reader.Close();
                            connection.Close();
                        }
                    }
                }

                foreach (DataRow row in draftedTable.Rows)
                {
                    var drafted = new SaveDraft
                    {
                        umcNo = row["REQ_UMC_NO"].ToString(),
                        materialDescription = row["REQ_UMC_DESC"].ToString(),
                        procurementType = row["PROC_TYPE"].ToString(),
                        intraInventory = "0",
                        interInventory = "0",
                        aiulpInventory = "0",
                        quantity = row["QTY"].ToString(),
                        unitOfMeasurement = row["UOM"].ToString(),
                        destinationStorage = row["DEST_SLOC"].ToString(),
                        existingUmcNo = row["EXISTING_UMC"].ToString(),
                        existingMaterialDescription = row["EXIS_UMC_DESC"].ToString(),
                        UMC_INDENT_ID = row["UMC_INDENT_ID"].ToString(),
                        REQ_UMC_NO = row["REQ_UMC_NO"].ToString(),
                        INDENT_ID = row["INDENT_ID"].ToString(),
                        REQ_UMC_DESC = row["REQ_UMC_DESC"].ToString(),
                        EXISTING_UMC = row["EXISTING_UMC"].ToString(),
                        EXIS_UMC_DESC = row["EXIS_UMC_DESC"].ToString(),
                        DEST_SLOC = row["DEST_SLOC"].ToString(),
                        UOM = row["UOM"].ToString(),
                        QTY = row["QTY"].ToString(),
                        IS_REFURBISHABLE = row["IS_REFURBISHABLE"].ToString(),
                        IS_CRITICAL = row["IS_CRITICAL"].ToString(),
                        IS_PERISHABLE = row["IS_PERISHABLE"].ToString(),
                        REQ_DT = row["REQ_DT"].ToString(),
                        CONSUMP_DT = row["CONSUMP_DT"].ToString(),
                        PROC_TYPE = row["PROC_TYPE"].ToString(),
                        SRC_DEPT_ID = row["INDENTOR_DEPT"].ToString(),
                        SRC_DEPT_DESC = row["DEST_SLOC"].ToString(),
                        SRC_LOC_DESC = row["INDENTOR_LOC"].ToString(),
                        SRC_PLANT_ID = row["INDENTOR_PLANT"].ToString(),
                        INDENT_DESC = row["INDENT_DESC"].ToString(),
                        INDENT_REMARKS = row["INDENT_REMARKS"].ToString(),
                        REQ_QUANTITY = row["QTY"].ToString(),

                        docType = row["DOCUMENT_TYPE"].ToString(),
                        fodType = row["FOD_TYPE"].ToString(),
                        currency = row["CURRENCY"].ToString(),
                        materialBGG = row["REQ_UMC_BGG"].ToString(),
                        rate = row["PRICE_PER_ITEM"].ToString(),
                        requestedOn = row["REQUIREMENT_DATE"].ToString(),

                        WF_STATUS = "2",
                        WF_TYPE = "INTRA",


                    };
                    draftedList.Add(drafted);
                }
            }
            catch (Exception ex)
            {
               
            }

            return draftedList;
        }

        public List<Department> GetDepartment(string adid)
        {
            var deptList = new List<Department>();
            DataTable deptTable = new DataTable();

            try
            {
                using (var connection = new OracleConnection(connectionString))
                {
                    string query = qry.GetDepartment;
                        using (var command = new OracleCommand(query, connection))
                    {
                        command.Parameters.Add(new OracleParameter("adid", adid));
                        connection.Open();
                        using (var reader = command.ExecuteReader())
                        {
                            deptTable.Load(reader);
                            reader.Close();
                            connection.Close();
                        }
                    }
                }

                foreach (DataRow row in deptTable.Rows)
                {
                    var department = new Department
                    {
                        dept = row["ROV_FOR_DEPT_CD"].ToString(),
                        deptName = row["DEPTDESC"].ToString(),
                        plant = row["PLANT"].ToString(),
                    };
                    deptList.Add(department);
                }
            }
            catch (Exception ex)
            {
                
            }
            return deptList;

        }

        public List<Material> GetMaterial(int adid)
        {
            var materialList = new List<Material>();
            DataTable matrialTable = new DataTable();

            try
            {
                using (var connection = new OracleConnection(connectionString))
                {
                    string query = qry.GetUmc;
                    using (var command = new OracleCommand(query, connection))
                    {
                        //command.Parameters.Add(new OracleParameter("adid", adid));
                        connection.Open();
                        using (var reader = command.ExecuteReader())
                        {
                            matrialTable.Load(reader);
                            reader.Close();
                            connection.Close();
                        }
                    }
                }

                foreach (DataRow row in matrialTable.Rows)
                {
                    var material = new Material
                    {
                        umcno = row["UMC_CD"].ToString(),
                        materialDescription = row["SHT_DESC"].ToString(),
                        unitOfMeasure = row["BUOM"].ToString(),
                        currency = row["CURR"].ToString(),
                        materialBGG = row["BGG_CD"].ToString()
                    };
                    materialList.Add(material);
                }
            }
            catch (Exception ex)
            {
                
            }
            return materialList;

        }

        public List<CODEVAL> GetCodeValueList(string CODE)
        {
            var codeVal = new List<CODEVAL>();
            DataTable plantTable = new DataTable();
            try
            {
                using (var connection = new OracleConnection(connectionString))
                {
                    string query = qry.getCodeValue;
                        using (var command = new OracleCommand(query, connection))
                    {
                        command.Parameters.Add("CODE", CODE);

                        connection.Open();
                        using (var reader = command.ExecuteReader())
                        {
                            plantTable.Load(reader);
                            reader.Close();
                            connection.Close();
                        }
                    }
                }

                foreach (DataRow row in plantTable.Rows)
                {
                    var plantDetails = new CODEVAL
                    {
                        ID = row["ID"].ToString(),
                        VAL = row["VAL"].ToString(),

                    };
                    codeVal.Add(plantDetails);
                }
            }
            catch (Exception ex)
            {
            }
            return codeVal;

        }
        public List<Plant> GetPlantList(string DEPT, string ADID)
        {
            var plantList = new List<Plant>();
            DataTable plantTable = new DataTable();
            try
            {
                using (var connection = new OracleConnection(connectionString))
                {
                    string query = qry.GetPlant;
                    using (var command = new OracleCommand(query, connection))
                    {
                        command.Parameters.Add("DEPT", DEPT);
                        command.Parameters.Add("ADID", ADID);
                        connection.Open();
                        using (var reader = command.ExecuteReader())
                        {
                            plantTable.Load(reader);
                            reader.Close();
                            connection.Close();
                        }
                    }
                }

                foreach (DataRow row in plantTable.Rows)
                {
                    var plantDetails = new Plant
                    {
                        plant = row["LOC"].ToString(),

                    };
                    plantList.Add(plantDetails);
                }
            }
            catch (Exception ex)
            {
                
            }
            return plantList;

        }
    }
    public class MASTER_QRY
    {
        public string getIndentDraftList = @"select 
t1.INDENT_ID INDENT_ID,
INDENTOR_LOC,
INDENTOR_PLANT,
INDENTOR_DEPT,
INDENT_DESC,
INDENT_REMARKS,

INDENT_STATUS,

INDENT_CURRENT_STATUS,
INDENT_WF_STATUS,
REQ_UMC_NO,
UMC_INDENT_ID,
REQ_UMC_DESC,
EXISTING_UMC,
EXIS_UMC_DESC,
DEST_SLOC,
UOM,
QTY,
IS_REFURBISHABLE,
IS_CRITICAL,
IS_PERISHABLE,
REQ_DT,
CONSUMP_DT,
PROC_TYPE,
AIULP_INVENTORY,
INTRA_INVENTORY,
INTER_INVENTORY,
UMC_STATUS,
TOTAL_SAP_DOC_QTY,
PRICE_PER_ITEM,
to_char(REQUIREMENT_DATE,'YYYY-MM-DD')REQUIREMENT_DATE,
REQ_UMC_BGG,
FOD_TYPE,
DOCUMENT_TYPE,
CURRENCY
from T_sis_Indent_details t1 JOIN t_sis_umc_indent_details t2 ON t1.indent_id = t2.indent_id WHERE t1.indent_status = 'DRAFT' AND t2.isactive = 'Y' AND t1.INDENT_ID = (select max(INDENT_ID) from T_sis_Indent_details where INDENTOR_DEPT=:DEPT and INDENT_CRT_BY=:USERNAME AND  indent_status = 'DRAFT')";

        public string GetDepartment= @"select T1.rov_for_dept_cd, T2.PLANT, t2.deptdesc from (
 select distinct rov_for_dept_cd from t_role_obj_val where rov_role_id
 in (select tru_role_id from t_role_user where tru_udr_id =:adid AND   rov_object = 'OBJ_DEPT' AND rov_create = 'Y'))T1,t_s_dept_mst T2 where T1.rov_for_dept_cd = T2.DEPTNO";
       public string GetUmc= @"select distinct UMC_CD,SHT_DESC,BUOM,BGG_CD,CURR from T_UMC_PROD where Plant_cd in ('062')";
public string getCodeValue= @"SELECT CODE_VALUE ID,CODE_VAL_DESC VAL FROM T_SIS_CODE_VALUE WHERE CODETYPE_ID =:CODE AND ACTIVE_FLG='Y' ORDER BY ID";
                public string GetPlant= @"select UM_PLANT_CD LOC from t_user_master where um_dept_cd=:DEPT and um_usr_id=:ADID";
                  
    }
}