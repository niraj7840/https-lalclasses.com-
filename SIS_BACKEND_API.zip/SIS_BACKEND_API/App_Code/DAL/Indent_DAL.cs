﻿using Oracle.ManagedDataAccess.Client;
using SIS_BACKEND_API.Models;

using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Reflection;
using System.Web;

namespace SIS_BACKEND_API.App_Code.DAL
{
    public class Indent_DAL
    {

        Indent_qry qry = new Indent_qry();
        string connectionString = ConfigurationManager.ConnectionStrings["OracleConnection"].ConnectionString;

        public int GetMaxIndentId()
        {
            using (OracleConnection connection = new OracleConnection(connectionString))
            {
                connection.Open();
                int RntVal = 0;
                try
                {


                    string query = qry.GetMaxId;

                    using (OracleCommand command = new OracleCommand(query, connection))
                    {

                        int maxId = Convert.ToInt32(command.ExecuteScalar());


                        RntVal = maxId;

                    }


                    return RntVal;
                }
                catch (Exception ex)
                {
                    return RntVal;
                }
            }

            // Check the number of rows affected

        }

        public int CreateIndent(SaveIndent obj)
        {
            OracleConnection connection = new OracleConnection(connectionString);

            connection.Open();
            OracleTransaction transaction = connection.BeginTransaction();
            int RntVal = 0;
            try
            {
                if (obj.T_SII_INDENT_DETAILS.IndentId.Length > 0)
                {
                    if (obj.IsDraft == "N")
                    {
                        UpdateIndent(obj.T_SII_INDENT_DETAILS, ref transaction, ref connection);
                    }
                    UpdateUMC_ChildDetails(obj.T_SII_INDENT_DETAILS, ref transaction, ref connection);
                }
                else
                {
                    SaveIndent(obj.T_SII_INDENT_DETAILS, ref transaction, ref connection, obj.IsDraft);

                }

                foreach (var model in obj.T_SIS_UMC_INDENT_DETAILS)
                {
                    if (model.UMC_INDENT_ID.Length > 0)
                    {
                        List<T_SII_WORK_FLOW> lst = obj.T_SII_WORK_FLOW.Where(x => x.UMC_INDENT_ID == model.UMC_INDENT_ID && x.INDENT_ID == model.INDENT_ID && x.DEST_SLOC == model.DEST_SLOC).ToList<T_SII_WORK_FLOW>();

                        UpdateIndentChildDetails(model, ref transaction, ref connection);
                        if (obj.IsDraft == "N")
                        {
                            foreach (var wfmodel in lst)
                            {
                                wfmodel.UMC_INDENT_ID = model.UMC_INDENT_ID;
                                wfmodel.INDENT_ID = model.INDENT_ID;
                                SaveWorkFlowDetails(wfmodel, ref transaction, ref connection);
                                insertWorlflowAudit(wfmodel, ref transaction, ref connection);

                            }
                        }

                    }
                    else
                    {
                        SaveIndentChildDetails(model, ref transaction, ref connection);
                        if (obj.IsDraft == "N" && obj.T_SII_INDENT_DETAILS.IndentId.Length > 0)
                        {
                            List<T_SII_WORK_FLOW> lst = obj.T_SII_WORK_FLOW.Where(x => x.INDENT_ID == model.INDENT_ID && x.REQ_UMC_NO == model.REQ_UMC_NO).ToList<T_SII_WORK_FLOW>();
                            foreach (var wfmodel in lst)
                            {
                                wfmodel.INDENT_ID = model.INDENT_ID;
                                SaveWorkFlowDetails(wfmodel, ref transaction, ref connection);

                                insertWorlflowAudit(wfmodel, ref transaction, ref connection);
                            }
                        }
                        else if (obj.IsDraft == "N" && obj.T_SII_INDENT_DETAILS.IndentId.Length == 0)
                        {
                            List<T_SII_WORK_FLOW> lst = obj.T_SII_WORK_FLOW.Where(x => x.REQ_UMC_NO == model.REQ_UMC_NO).ToList<T_SII_WORK_FLOW>();
                            foreach (var wfmodel in lst)
                            {
                                wfmodel.INDENT_ID = model.INDENT_ID;
                                SaveWorkFlowDetailsDirect(wfmodel, ref transaction, ref connection);

                                insertWorlflowAudit(wfmodel, ref transaction, ref connection);
                            }
                        }

                    }

                }

                transaction.Commit();
                RntVal = GetMaxIndentId();
                return RntVal;
            }
            catch (Exception ex)
            {
                transaction.Rollback();
                return 0;
            }
            finally { connection.Close(); }


            // Check the number of rows affected

        }

        public int SaveBatchWorkflow(T_SII_WORK_FLOW wfmodel)
        {
            OracleConnection connection = new OracleConnection(connectionString);

            connection.Open();
            OracleTransaction transaction = connection.BeginTransaction();

            try
            {

                SaveWorkFlowDetails(wfmodel, ref transaction, ref connection);
                insertWorlflowAudit(wfmodel, ref transaction, ref connection);



                transaction.Commit();

                return 1;
            }
            catch (Exception ex)
            {
                transaction.Rollback();
                return 0;
            }
            finally { connection.Close(); }


            // Check the number of rows affected

        }
        public void SaveIndent(T_SII_INDENT_DETAILS obj, ref OracleTransaction transaction, ref OracleConnection connection, string typ)
        {


            string query = qry.InsertIndent;

            using (OracleCommand command = new OracleCommand(query, connection))
            {
                command.Parameters.Add(":IndentorLoc", obj.IndentorLoc);
                command.Parameters.Add(":IndentorPlant", obj.IndentorPlant);
                command.Parameters.Add(":IndentorDept", obj.IndentorDept);
                command.Parameters.Add(":IndentDesc", obj.IndentDesc);

                command.Parameters.Add(":IndentRemarks", obj.IndentRemarks);
                command.Parameters.Add(":IndentStatus", typ == "Y" ? "DRAFT" : "CMPLT");
                command.Parameters.Add(":UserName", obj.UserName);
                command.Parameters.Add(":STATUS", obj.STATUS);



                command.ExecuteNonQuery();
            }





            // Check the number of rows affected

        }
        public void UpdateIndent(T_SII_INDENT_DETAILS obj, ref OracleTransaction transaction, ref OracleConnection connection)
        {


            string query = qry.updateIndent;

            using (OracleCommand command = new OracleCommand(query, connection))
            {
                command.Parameters.Add(":IndentDesc", obj.IndentDesc);
                command.Parameters.Add(":IndentRemarks", obj.IndentRemarks);

                command.Parameters.Add(":UserName", obj.UserName);
                command.Parameters.Add(":STATUS", obj.STATUS);
                command.Parameters.Add(":IndentId", obj.IndentId);



                command.ExecuteNonQuery();
            }




            // Check the number of rows affected

        }
        public void SaveIndentChildDetails(T_SIS_UMC_INDENT_DETAILS model, ref OracleTransaction transaction, ref OracleConnection connection)
        {



            string query = qry.InsertIndentChild;

            using (OracleCommand command = new OracleCommand(query, connection))
            {
                command.Parameters.Add(":REQ_UMC_NO", OracleDbType.Varchar2).Value = model.REQ_UMC_NO;
                command.Parameters.Add(":INDENT_ID", OracleDbType.Varchar2).Value = model.INDENT_ID;
                command.Parameters.Add(":REQ_UMC_DESC", OracleDbType.Varchar2).Value = model.REQ_UMC_DESC;
                command.Parameters.Add(":EXISTING_UMC", OracleDbType.Varchar2).Value = model.EXISTING_UMC;
                command.Parameters.Add(":EXIS_UMC_DESC", OracleDbType.Varchar2).Value = model.EXIS_UMC_DESC;
                command.Parameters.Add(":DEST_SLOC", OracleDbType.Varchar2).Value = model.DEST_SLOC;
                command.Parameters.Add(":UOM", OracleDbType.Varchar2).Value = model.UOM;
                command.Parameters.Add(":QTY", OracleDbType.Varchar2).Value = model.QTY;
                command.Parameters.Add(":IS_REFURBISHABLE", OracleDbType.Varchar2).Value = model.IS_REFURBISHABLE;
                command.Parameters.Add(":IS_CRITICAL", OracleDbType.Varchar2).Value = model.IS_CRITICAL;
                command.Parameters.Add(":IS_PERISHABLE", OracleDbType.Varchar2).Value = model.IS_PERISHABLE;
                command.Parameters.Add(":REQ_DT", OracleDbType.Varchar2).Value = model.REQ_DT;
                command.Parameters.Add(":CONSUMP_DT", OracleDbType.Varchar2).Value = model.CONSUMP_DT;
                command.Parameters.Add(":PROC_TYPE", OracleDbType.Varchar2).Value = model.PROC_TYPE;
                command.Parameters.Add(":USERNAME", OracleDbType.Varchar2).Value = model.USERNAME;
                command.Parameters.Add(":AIULP_INVENTORY", OracleDbType.Varchar2).Value = model.aiulpInventory;
                command.Parameters.Add(":INTRA_INVENTORY", OracleDbType.Varchar2).Value = model.intraInventory;
                command.Parameters.Add(":INTER_INVENTORY", OracleDbType.Varchar2).Value = model.interInventory;
                command.Parameters.Add(":UMC_STATUS", OracleDbType.Varchar2).Value = model.UMC_STATUS;
                command.Parameters.Add(":PRICE_PER_ITEM", OracleDbType.Varchar2).Value = model.rate;
                command.Parameters.Add(":REQUIREMENT_DATE", OracleDbType.Varchar2).Value = model.requestedOn;
                command.Parameters.Add(":REQ_UMC_BGG", OracleDbType.Varchar2).Value = model.materialBGG;
                command.Parameters.Add(":FOD_TYPE", OracleDbType.Varchar2).Value = model.fodType;
                command.Parameters.Add(":DOCUMENT_TYP", OracleDbType.Varchar2).Value = model.docType;
                command.Parameters.Add(":CURRENCY", OracleDbType.Varchar2).Value = model.currency;


                command.ExecuteNonQuery();


            }


        }

        public void UpdateIndentChildDetails(T_SIS_UMC_INDENT_DETAILS model, ref OracleTransaction transaction, ref OracleConnection connection)
        {



            string query = qry.updateIndentChild;

            using (OracleCommand command = new OracleCommand(query, connection))
            {
                command.Parameters.Add(":REQ_UMC_NO", OracleDbType.Varchar2).Value = model.REQ_UMC_NO;

                command.Parameters.Add(":REQ_UMC_DESC", OracleDbType.Varchar2).Value = model.REQ_UMC_DESC;
                command.Parameters.Add(":EXISTING_UMC", OracleDbType.Varchar2).Value = model.EXISTING_UMC;
                command.Parameters.Add(":EXIS_UMC_DESC", OracleDbType.Varchar2).Value = model.EXIS_UMC_DESC;
                command.Parameters.Add(":DEST_SLOC", OracleDbType.Varchar2).Value = model.DEST_SLOC;
                command.Parameters.Add(":UOM", OracleDbType.Varchar2).Value = model.UOM;
                command.Parameters.Add(":QTY", OracleDbType.Varchar2).Value = model.QTY;
                command.Parameters.Add(":IS_REFURBISHABLE", OracleDbType.Varchar2).Value = model.IS_REFURBISHABLE;
                command.Parameters.Add(":IS_CRITICAL", OracleDbType.Varchar2).Value = model.IS_CRITICAL;
                command.Parameters.Add(":IS_PERISHABLE", OracleDbType.Varchar2).Value = model.IS_PERISHABLE;
                command.Parameters.Add(":REQ_DT", OracleDbType.Varchar2).Value = model.REQ_DT;
                command.Parameters.Add(":CONSUMP_DT", OracleDbType.Varchar2).Value = model.CONSUMP_DT;
                command.Parameters.Add(":PROC_TYPE", OracleDbType.Varchar2).Value = model.PROC_TYPE;
                command.Parameters.Add(":USERNAME", OracleDbType.Varchar2).Value = model.USERNAME;
                command.Parameters.Add(":AIULP_INVENTORY", OracleDbType.Varchar2).Value = model.aiulpInventory;
                command.Parameters.Add(":INTRA_INVENTORY", OracleDbType.Varchar2).Value = model.intraInventory;
                command.Parameters.Add(":INTER_INVENTORY", OracleDbType.Varchar2).Value = model.interInventory;
                command.Parameters.Add(":UMC_STATUS", OracleDbType.Varchar2).Value = model.UMC_STATUS;
                command.Parameters.Add(":PRICE_PER_ITEM", OracleDbType.Varchar2).Value = model.rate;
                command.Parameters.Add(":REQUIREMENT_DATE", OracleDbType.Varchar2).Value = model.requestedOn;
                command.Parameters.Add(":REQ_UMC_BGG", OracleDbType.Varchar2).Value = model.materialBGG;
                command.Parameters.Add(":FOD_TYPE", OracleDbType.Varchar2).Value = model.fodType;
                command.Parameters.Add(":DOCUMENT_TYP", OracleDbType.Varchar2).Value = model.docType;
                command.Parameters.Add(":CURRENCY", OracleDbType.Varchar2).Value = model.currency;
                command.Parameters.Add(":UMC_INDENT_ID", OracleDbType.Varchar2).Value = model.UMC_INDENT_ID;
                command.Parameters.Add(":INDENT_ID", OracleDbType.Varchar2).Value = model.INDENT_ID;

                command.ExecuteNonQuery();


            }


        }

        public void SaveWorkFlowDetails(T_SII_WORK_FLOW model, ref OracleTransaction transaction, ref OracleConnection connection)
        {

            if (model.WF_TYPE == "AIULP")
            {
                model.WF_EXPIRY_DT = "0";

            }
            else
            {
                model.WF_EXPIRY_DT = GetExpiryDays().ToString();

            }
            string query = qry.InsertWorkFlow.Replace("@DYS", model.WF_EXPIRY_DT);

            using (OracleCommand command = new OracleCommand(query, connection))
            {

                command.Parameters.Add(":UMC_INDENT_ID", model.UMC_INDENT_ID);

                //command.Parameters.Add(":INDENT_ID", model.INDENT_ID);
                command.Parameters.Add(":REQ_UMC_NO", model.REQ_UMC_NO);
                // command.Parameters.Add(":DEST_SLOC", model.SRC_LOC_DESC==""?model.DEST_SLOC: model.SRC_LOC_DESC);

                command.Parameters.Add(":SRC_LOC_ID", model.SRC_LOC_DESC);
                command.Parameters.Add(":SRC_LOC_DESC", model.SRC_LOC_ID);
                command.Parameters.Add(":SRC_PLANT_ID", model.SRC_PLANT_ID);
                command.Parameters.Add(":SRC_PLANT_DESC", model.SRC_PLANT_DESC);
                command.Parameters.Add(":SRC_DEPT_ID", model.SRC_DEPT_ID);
                command.Parameters.Add(":SRC_DEPT_DESC", "");
                command.Parameters.Add(":REQ_QUANTITY", model.REQ_QUANTITY);

                command.Parameters.Add(":WF_TYPE", model.WF_TYPE == "" ? "INTRA" : model.WF_TYPE);
                command.Parameters.Add(":WF_STATUS", model.WF_STATUS);
                // command.Parameters.Add(":WF_EXPIRY_DT", model.WF_EXPIRY_DT);
                command.Parameters.Add(":WF_REMARKS", model.WF_REMARKS);
                command.Parameters.Add(":USERNAME", model.USERNAME);


                command.ExecuteNonQuery();
            }



        }
        public void SaveWorkFlowDetailsDirect(T_SII_WORK_FLOW model, ref OracleTransaction transaction, ref OracleConnection connection)
        {
            if (model.WF_TYPE == "AIULP")
            {
                model.WF_EXPIRY_DT = "0";

            }
            else
            {

                model.WF_EXPIRY_DT = GetExpiryDays().ToString();

            }

            string query = qry.InsertWorkFlowDirect.Replace("@DYS", model.WF_EXPIRY_DT);

            using (OracleCommand command = new OracleCommand(query, connection))
            {

                command.Parameters.Add(":UMC_INDENT_ID", model.UMC_INDENT_ID);

                //command.Parameters.Add(":INDENT_ID", model.INDENT_ID);
                command.Parameters.Add(":REQ_UMC_DESC", model.REQ_UMC_NO);
                //  command.Parameters.Add(":DEST_SLOC", model.SRC_LOC_DESC);

                command.Parameters.Add(":SRC_LOC_ID", model.SRC_LOC_DESC);
                command.Parameters.Add(":SRC_LOC_DESC", "");
                command.Parameters.Add(":SRC_PLANT_ID", model.SRC_PLANT_ID);
                command.Parameters.Add(":SRC_PLANT_DESC", model.SRC_PLANT_DESC);
                command.Parameters.Add(":SRC_DEPT_ID", model.SRC_DEPT_ID);
                command.Parameters.Add(":SRC_DEPT_DESC", "");
                command.Parameters.Add(":REQ_QUANTITY", model.REQ_QUANTITY);

                command.Parameters.Add(":WF_TYPE", model.WF_TYPE == "" ? "INTRA" : model.WF_TYPE);
                command.Parameters.Add(":WF_STATUS", model.WF_STATUS);
                // command.Parameters.Add(":WF_EXPIRY_DT", model.WF_EXPIRY_DT);
                command.Parameters.Add(":WF_REMARKS", model.WF_REMARKS);
                command.Parameters.Add(":USERNAME", model.USERNAME);


                command.ExecuteNonQuery();
            }



        }

        public void UpdateUMC_ChildDetails(T_SII_INDENT_DETAILS model, ref OracleTransaction transaction, ref OracleConnection connection)
        {


            string query = qry.UpdateIndentChild;

            using (OracleCommand command = new OracleCommand(query, connection))
            {
                command.Parameters.Add(":UserName", model.UserName);
                command.Parameters.Add(":INDENT_ID", model.IndentId);




                command.ExecuteNonQuery();
            }



        }

        public void insertWorlflowAudit(T_SII_WORK_FLOW model, ref OracleTransaction transaction, ref OracleConnection connection)
        {


            string query = qry.oraInsertWorkFlowAudit;

            using (OracleCommand command = new OracleCommand(query, connection))
            {



                command.Parameters.Add(":WF_TYPE", model.WF_TYPE);

                command.Parameters.Add(":CRT_BY", model.USERNAME);



                command.ExecuteNonQuery();
            }



        }

        public void UpdateStatusForIndId(string indId, ref OracleTransaction transaction, ref OracleConnection connection)
        {

            string query = qry.UpdateStatus;

            using (OracleCommand command = new OracleCommand(query, connection))
            {

                command.Parameters.Add(":INDENT_ID", indId);



                command.ExecuteNonQuery();
            }




        }
        int GetExpiryDays()
        {
            DateTime currentDate = DateTime.Today;

            // Add 5 days to the current date
            int dys = 0;
            for (int i = 1; i <= 5; i++)
            {


                DateTime futureDate = currentDate.AddDays(dys);

                // Check if the future date falls on Saturday or Sunday
                if (futureDate.DayOfWeek == DayOfWeek.Saturday || futureDate.DayOfWeek == DayOfWeek.Sunday)

                {
                   
                    i = i - 1;
                    
                }
                dys = dys + 1;
            }
            return dys;
        }

    }




    public class Indent_qry
    {
        public string GetMaxId = @"select nvl(max(INDENT_ID),0) as IndentId from T_SIS_INDENT_DETAILS";
        public string InsertIndent = @"INSERT INTO T_SIS_INDENT_DETAILS 
                    (INDENT_ID,INDENTOR_LOC, INDENTOR_PLANT, INDENTOR_DEPT, INDENT_DESC, 
                    INDENT_REMARKS,INDENT_STATUS, INDENT_CRT_BY, INDENT_CRT_DT,INDENT_CURRENT_STATUS) 
                    VALUES 
                    (
(select nvl(max(INDENT_ID),0)+1 from T_SIS_INDENT_DETAILS), :IndentorLoc, :IndentorPlant, :IndentorDept, :IndentDesc, 
                    :IndentRemarks, :IndentStatus, :UserName, sysdate,:STATUS)";
        public string updateIndent = @"UPDATE T_SIS_INDENT_DETAILS 
                    SET INDENT_DESC =:IndentDesc,
INDENT_REMARKS=:IndentRemarks ,INDENT_STATUS='CMPLT', INDENT_MOD_BY=:UserName, INDENT_MOD_DT=SYSDATE,INDENT_CURRENT_STATUS=:STATUS
where INDENT_ID=:IndentId";

        public string UpdateIndentChild = @"UPDATE T_SIS_UMC_INDENT_DETAILS SET ISACTIVE='N',MOD_BY=:UserName,MOD_DT=SYSDATE WHERE to_char(INDENT_ID)=:IndentId";
        public string InsertIndentChild = @"INSERT INTO T_SIS_UMC_INDENT_DETAILS
(UMC_INDENT_ID, REQ_UMC_NO, INDENT_ID, REQ_UMC_DESC,
EXISTING_UMC, EXIS_UMC_DESC, DEST_SLOC, UOM, QTY,
IS_REFURBISHABLE, IS_CRITICAL, IS_PERISHABLE, REQ_DT,
CONSUMP_DT, PROC_TYPE, CRT_BY, CRT_DT,ISACTIVE,AIULP_INVENTORY,INTRA_INVENTORY,INTER_INVENTORY,UMC_STATUS,PRICE_PER_ITEM,
REQUIREMENT_DATE,
REQ_UMC_BGG,
FOD_TYPE,
DOCUMENT_TYPE,
CURRENCY,TOTAL_SAP_DOC_QTY)
VALUES
((select nvl(max(UMC_INDENT_ID),0)+1 from T_SIS_UMC_INDENT_DETAILS), :REQ_UMC_NO, nvl(:INDENT_ID,(select nvl(max(INDENT_ID),0) from T_SIS_INDENT_DETAILS)), :REQ_UMC_DESC,
:EXISTING_UMC, :EXIS_UMC_DESC, :DEST_SLOC, :UOM, :QTY,
:IS_REFURBISHABLE, :IS_CRITICAL, :IS_PERISHABLE, :REQ_DT,
:CONSUMP_DT, :PROC_TYPE, :USERNAME, SYSDATE,'Y',:AIULP_INVENTORY,:INTRA_INVENTORY,:INTER_INVENTORY,:UMC_STATUS,
:PRICE_PER_ITEM,
to_date(:REQUIREMENT_DATE,'YYYY-MM-DD'),
:REQ_UMC_BGG,
:FOD_TYPE,
:DOCUMENT_TYPE,
:CURRENCY,'0')";

        public string updateIndentChild = @"UPDATE T_SIS_UMC_INDENT_DETAILS
SET REQ_UMC_NO=:REQ_UMC_NO, REQ_UMC_DESC=:REQ_UMC_DESC,
EXISTING_UMC=:EXISTING_UMC, EXIS_UMC_DESC=:EXIS_UMC_DESC, DEST_SLOC=:DEST_SLOC, UOM=:UOM, QTY=:QTY,
IS_REFURBISHABLE=:IS_REFURBISHABLE, IS_CRITICAL=:IS_CRITICAL, IS_PERISHABLE=:IS_PERISHABLE, REQ_DT=:REQ_DT,
CONSUMP_DT=:CONSUMP_DT, PROC_TYPE=:PROC_TYPE, MOD_BY=:USERNAME, MOD_DT=SYSDATE,ISACTIVE='Y',AIULP_INVENTORY=:AIULP_INVENTORY,
INTRA_INVENTORY=:INTRA_INVENTORY,INTER_INVENTORY=:INTER_INVENTORY,UMC_STATUS=:UMC_STATUS,

PRICE_PER_ITEM=:PRICE_PER_ITEM,
REQUIREMENT_DATE=to_date(:REQUIREMENT_DATE,'YYYY-MM-DD'),
REQ_UMC_BGG=:REQ_UMC_BGG,
FOD_TYPE=:FOD_TYPE,
DOCUMENT_TYPE=:DOCUMENT_TYPE,
CURRENCY=:CURRENCY,
TOTAL_SAP_DOC_QTY='0'
where UMC_INDENT_ID=:UMC_INDENT_ID AND INDENT_ID=:INDENT_ID";



        public string InsertWorkFlow = @"INSERT INTO T_SIS_WORK_FLOW
(WF_ID, UMC_INDENT_ID, SRC_LOC_ID, SRC_LOC_DESC,
SRC_PLANT_ID, SRC_PLANT_DESC, SRC_DEPT_ID, SRC_DEPT_DESC,
REQ_QUANTITY, APPROVED_QTY, WF_TYPE, WF_STATUS, WF_EXPIRY_DT,
WF_REMARKS, CRT_BY, CRT_ON)
VALUES 
((select nvl(max(WF_ID),0)+1 from T_SIS_WORK_FLOW), nvl(:UMC_INDENT_ID,(select nvl(max(UMC_INDENT_ID),0) from T_SIS_UMC_INDENT_DETAILS WHERE REQ_UMC_NO=:REQ_UMC_NO AND ISACTIVE='Y' )), :SRC_LOC_ID, :SRC_LOC_DESC,
:SRC_PLANT_ID, :SRC_PLANT_DESC, :SRC_DEPT_ID, :SRC_DEPT_DESC,
:REQ_QUANTITY, '0', :WF_TYPE, :WF_STATUS, SYSDATE+@DYS,
:WF_REMARKS, :USERNAME, SYSDATE)";
        public string InsertWorkFlowDirect = @"INSERT INTO T_SIS_WORK_FLOW
(WF_ID, UMC_INDENT_ID, SRC_LOC_ID, SRC_LOC_DESC,
SRC_PLANT_ID, SRC_PLANT_DESC, SRC_DEPT_ID, SRC_DEPT_DESC,
REQ_QUANTITY, APPROVED_QTY, WF_TYPE, WF_STATUS, WF_EXPIRY_DT,
WF_REMARKS, CRT_BY, CRT_ON)
VALUES 
((select nvl(max(WF_ID),0)+1 from T_SIS_WORK_FLOW), nvl(:UMC_INDENT_ID,(select nvl(max(UMC_INDENT_ID),0) from T_SIS_UMC_INDENT_DETAILS WHERE REQ_UMC_NO=:REQ_UMC_NO AND ISACTIVE='Y' )), :SRC_LOC_ID, :SRC_LOC_DESC,
:SRC_PLANT_ID, :SRC_PLANT_DESC, :SRC_DEPT_ID, :SRC_DEPT_DESC,
:REQ_QUANTITY, '0', :WF_TYPE, :WF_STATUS, SYSDATE+@DYS,
:WF_REMARKS, :USERNAME, SYSDATE)";
        public string UpdateStatus = @"update T_SIS_INDENT_DETAILS set INDENT_STATUS='CMPLT'  where INDENT_ID=:INDENT_ID";
        public string oraInsertWorkFlowAudit = @"insert into T_SIS_WORKFLOW_AUDIT (ID,WF_ID,WF_TYPE,WF_STATUS,WF_REMARKS,CRT_BY,CRT_DT) values ((SELECT coalesce(MAX(ID),0) + 1 FROM T_SIS_WORKFLOW_AUDIT),(select nvl(max(WF_ID),0) from T_SIS_WORK_FLOW),:WF_TYPE,'2','',:CRT_BY,SYSDATE)";


    }

}