﻿using SIS_BACKEND_API.Models;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using Oracle.ManagedDataAccess.Client;
using SIS_BACKEND_API.Models;
using System.Data.SqlClient;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Web;
using System.Reflection;

namespace SIS_BACKEND_API.App_Code.DAL
{
    public class WorkflowDAL
    {
        private SqlCommand cmd;
        private SqlCommand cmd2;
        DataTable dtRet = null;
        private string strConnSISDB = ConfigurationManager.ConnectionStrings["OracleConnection"].ConnectionString;

        private ConnectionOracleDB objConn;
        private DataTable dtResult;

        public DataTable GetWorkFlowDetails(string ADID)
        {
            //List< WorkFlowModel> workFlowModel = new List<WorkFlowModel>();
            //Instantiate the connection object.
            objConn = new ConnectionOracleDB(strConnSISDB, DBConst.oraSelectWorkFlow, CommandType.Text, true);

            try
            {
                //Open the connection.
                objConn.OpenConnection();

                //Bind the parameters.            
                objConn.AddParameters(":APR_ID", ADID);

                //Execute the query and assign the resultant table.
                objConn.FillDataTable();
                dtResult = objConn.ResultantTable;

                //Close the connection
                objConn.CloseConnection();
            }
            catch (Exception excp)
            {
                throw excp;
            }

            //return the final Data Table.
            return dtResult;
        }

        internal DataTable GetWorkFlowDetailsFromID(string workFlowID)
        {
            //List< WorkFlowModel> workFlowModel = new List<WorkFlowModel>();
            //Instantiate the connection object.
            objConn = new ConnectionOracleDB(strConnSISDB, DBConst.oraSelectWorkFlow_WithID, CommandType.Text, true);

            try
            {
                //Open the connection.
                objConn.OpenConnection();

                //Bind the parameters.                
                objConn.AddParameters(":WF_ID", workFlowID);
                //Execute the query and assign the resultant table.
                objConn.FillDataTable();
                dtResult = objConn.ResultantTable;

                //Close the connection
                objConn.CloseConnection();
            }
            catch (Exception excp)
            {
                throw excp;
            }

            //return the final Data Table.
            return dtResult;
        }

        internal DataTable GetApprover(string DEPT,string PLANT)
        {
            //List< WorkFlowModel> workFlowModel = new List<WorkFlowModel>();
            //Instantiate the connection object.
            objConn = new ConnectionOracleDB(strConnSISDB, DBConst.getApprover, CommandType.Text, true);

            try
            {
                //Open the connection.
                objConn.OpenConnection();
                objConn.AddParameters(":DEPT", DEPT);
                objConn.AddParameters(":PLANT", PLANT);
                //Bind the parameters.                

                //Execute the query and assign the resultant table.
                objConn.FillDataTable();
                dtResult = objConn.ResultantTable;

                //Close the connection
                objConn.CloseConnection();
            }
            catch (Exception excp)
            {
                throw excp;
            }

            //return the final Data Table.
            return dtResult;
        }

        internal int UpdateWorkFlowDetailsFromID(WorkFlowModel workflowmodel)
        {
            int attachInsertCount;

            using (OracleConnection connection = new OracleConnection(strConnSISDB))
            {
                connection.Open();

                OracleCommand command = connection.CreateCommand();
                OracleTransaction transaction;

                transaction = connection.BeginTransaction();
                command.Transaction = transaction;

                try
                {
                     command.CommandText = DBConst.oraUpdateWorkFlow_WithID;
                    command.Parameters.Clear();
                    command.Parameters.Add(":WF_STATUS", workflowmodel.WF_STATUS);
                    command.Parameters.Add(":MOD_BY", workflowmodel.MOD_BY);
                    command.Parameters.Add(":APPROVED_QTY", workflowmodel.APPROVED_QTY);
                    command.Parameters.Add(":WF_REMARKS", workflowmodel.WF_REMARKS);
                    command.Parameters.Add(":APP_BY", workflowmodel.MOD_BY);
                    command.Parameters.Add(":WF_ID", workflowmodel.WF_ID);
                    
                    
                    attachInsertCount = command.ExecuteNonQuery();

                    if (attachInsertCount > 0)
                    {

                        command.Parameters.Clear();
                        command.CommandText = DBConst.oraInsertWorkFlowAudit;
                        command.Parameters.Clear();
                        command.Parameters.Add(":WF_ID", workflowmodel.WF_ID);
                        command.Parameters.Add(":WF_TYPE", workflowmodel.WF_TYPE);
                        command.Parameters.Add(":WF_STATUS", workflowmodel.WF_STATUS);
                        
                        command.Parameters.Add(":WF_REMARKS", workflowmodel.WF_REMARKS);
                        command.Parameters.Add(":CRT_BY", workflowmodel.MOD_BY);
                        attachInsertCount = command.ExecuteNonQuery();

                    }
                    transaction.Commit();
                }
                catch (OracleException excp)
                {
                    transaction.Rollback();
                    throw excp;
                }
                catch (Exception excp)
                {
                    transaction.Rollback();
                    throw excp;
                }
            }
            return attachInsertCount;
        }
      

        public class DBConst
        {
            #region WorkFlow
            //added by Animesh
            //        public const string oraSelectWorkFlow = @"select T_SIS_WORK_FLOW.* from sapsur.T_SIS_WORK_FLOW  inner join sapsur.t_approver  on SRC_DEPT_ID=apr_dept and SRC_PLANT_ID = APR_PLANT 
            //and APP_BY = APR_LEVEL Where apr_dept = '253' and APR_PLANT = '025' and APR_LEVEL IN (1,2)";
            public const string oraSelectWorkFlow = @"SELECT DISTINCT WF.WF_ID,IND.INDENT_ID,UMC.REQ_UMC_DESC,UMC.PROC_TYPE,WF.WF_TYPE,IND.INDENTOR_PLANT,UMC.REQ_UMC_NO,WF.REQ_QUANTITY,UMC.UOM,nvl(WF.SRC_PLANT_DESC,WF.SRC_PLANT_ID)SRC_PLANT_DESC,nvl(WF.SRC_LOC_DESC,WF.SRC_LOC_ID)SRC_LOC_DESC,nvl(WF.SRC_DEPT_DESC,SRC_DEPT_ID)SRC_DEPT_DESC,TO_CHAR(WF.CRT_ON,'DD-MON-YYYY') MOD_DT,IND.INDENT_DESC FROM
 T_SIS_work_flow WF INNER JOIN T_SIS_UMC_INDENT_DETAILS UMC on UMC.UMC_INDENT_ID= WF.UMC_INDENT_ID inner join T_SIS_INDENT_DETAILS IND 
on IND.INDENT_ID=UMC.INDENT_ID  inner join t_approver appr on WF.SRC_PLANT_ID= appr.apr_plant  and wf.src_dept_id= appr.apr_dept where
  appr.APR_ID=:APR_ID and appr.APR_LEVEL IN (2,3) and WF.WF_STATUS in (2,3) ORDER BY WF.WF_ID ASC"; //'500455'
            public const string oraSelectWorkFlow_WithID = @"select UMC.REQ_UMC_NO,UMC.REQ_UMC_DESC,UMC.DEST_SLOC,WF.SRC_PLANT_DESC,WF.SRC_DEPT_DESC,UMC.CONSUMP_DT,UMC.REQ_DT,UMC.PROC_TYPE,
IND.INDENT_DESC,IND.INDENT_REMARKS from
T_SIS_WORK_FLOW WF inner join t_sis_UMC_indent_details UMC on UMC.UMC_INDENT_ID=WF.UMC_INDENT_ID inner join T_SIS_INDENT_DETAILS IND on
IND.INDENT_ID = UMC.INDENT_ID where WF.WF_ID=:WF_ID";
            public const string oraUpdateWorkFlow_WithID = @"update T_SIS_work_flow set WF_STATUS=:WF_STATUS ,MOD_BY=:MOD_BY,APPROVED_QTY=:APPROVED_QTY,WF_REMARKS=:WF_REMARKS ,MOD_ON=SYSDATE,APP_BY=:APP_BY,APP_ON=SYSDATE where WF_ID=:WF_ID";
            public const string oraInsertWorkFlowAudit = @"insert into T_SIS_WORKFLOW_AUDIT (ID,WF_ID,WF_TYPE,WF_STATUS,WF_REMARKS,CRT_BY,CRT_DT) values ((SELECT coalesce(MAX(ID),0) + 1 FROM T_SIS_WORKFLOW_AUDIT),:WF_ID,:WF_TYPE,:WF_STATUS,:WF_REMARKS,:CRT_BY,SYSDATE)";
            public const string getApprover = @"SELECT APR_ID,APR_LEVEL,'' USERNAME FROM SAPSUR.T_APPROVER WHERE APR_DEPT=:DEPT AND APR_PLANT=:PLANT AND APR_LEVEL IN (2,3)";
            #endregion


        }

    }
}