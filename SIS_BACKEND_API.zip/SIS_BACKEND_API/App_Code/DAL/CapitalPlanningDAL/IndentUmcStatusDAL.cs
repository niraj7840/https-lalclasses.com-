﻿using Oracle.ManagedDataAccess.Client;
using SIS_BACKEND_API.Models;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Http;

namespace SIS_BACKEND_API.App_Code.DAL.CapitalPlanningDAL
{
    public class IndentUmcStatusDAL
    {
        private string strConnSISDB = ConfigurationManager.ConnectionStrings["OracleConnection"].ConnectionString;

        //start of function

        public DataTable GetUmcsTaggedUnderIntent(string intent)
        {
            var approvalDataList = new List<CapexApprovalRequestData>();
            DataTable dt = new DataTable();
            try
            {

                using (var connection = new OracleConnection(strConnSISDB))
                {
                    connection.Open();


                    using (var command = new OracleCommand(DalQueryindentUmc.queryGetUmcsUnderIntent, connection))
                    {

                        command.Parameters.Add(new OracleParameter(":intent", intent));

                        using (var reader = command.ExecuteReader())
                        {

                            dt.Load(reader);
                        }
                    }
                    connection.Close();


                }

            }
            catch (Exception ex)
            {
                return dt;
            }

            return dt;
        }


        //end of function


        //start of function
        public string GetStatusOfUMCIndent(string umc, int indent)
        {
            using (OracleConnection connection = new OracleConnection(strConnSISDB))
            {

                using (OracleCommand command = new OracleCommand(DalQueryindentUmc.queryGetStatusOfUmc, connection))
                {
                    // Set parameter values
                    command.Parameters.Add(":umc", OracleDbType.Varchar2).Value = umc;
                    command.Parameters.Add(":indent", OracleDbType.Varchar2).Value = indent;

                    try
                    {
                        connection.Open();
                        var status = command.ExecuteScalar(); // Assuming status is a single value

                        // Check if status is null
                        if (status != null)
                        {
                            return status.ToString();
                        }
                        else
                        {
                            // UMC with the given intent not found
                            return "NotFound";
                        }
                    }
                    catch (Exception ex)
                    {
                        // Handle exception
                        Console.WriteLine("Error fetching status: " + ex.Message);
                        return null;
                    }
                }
            }
        }

        //end od function



    }

    public class DalQueryindentUmc
    {

        public const string queryGetUmcsUnderIntent = @"select a.req_umc_no,  nvl(b.cru_tag,'N') tag, a.REQ_UMC_DESC description
                                                        from sapsur.t_sis_umc_indent_details a, sapsur.T_SIS_CAP_REV_UMC b 
                                                        where indent_id=:intent
                                                        and req_umc_no = cru_umc(+)
                                                        and REQ_UMC_NO is not null AND REQ_UMC_NO <> ' '";

        public const string queryGetStatusOfUmc = @"select cua_status from sapsur.t_sis_cap_umc_aprvl where cua_umc=:umc and cua_indent_no=:indent and rownum<2";



    }
}