﻿using Oracle.ManagedDataAccess.Client;
using SIS_BACKEND_API.Models;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Http;

namespace SIS_BACKEND_API.App_Code.DAL.CapitalPlanningDAL
{
   
    public class ViewCapReqDAL
    {

        private string strConnSISDB = ConfigurationManager.ConnectionStrings["OracleConnection"].ConnectionString;


        //start of funtion

        public DataTable GetViewPendingRequest()
        {

            var approvalDataList = new List<CapexApprovalRequestData>();
            DataTable dt = new DataTable();
            try
            {

                using (var connection = new OracleConnection(strConnSISDB))
                {
                    connection.Open();


                    using (var command = new OracleCommand(DalQueryView.queryViewPendingRequest, connection))
                    {
                        using (var reader = command.ExecuteReader())
                        {

                            dt.Load(reader);
                        }
                    }
                    connection.Close();


                }

            }
            catch (Exception ex)
            {
                return dt;
            }



            return dt;
        }

        //end of function 


        //start of funtion
        public DataTable GetUmcOrRequestIdInfo(string umc = null, int? requestId = null)
        {
            var approvalDataList = new List<CapexApprovalRequestData>();
            DataTable dt = new DataTable();
            try
            {

                using (var connection = new OracleConnection(strConnSISDB))
                {
                    connection.Open();


                    string strQuery = "";
                    if (umc != null && requestId != null)
                    {
                        strQuery = DalQueryView.queryGetUmcAndRequestId;
                    }
                    else
                    {
                        strQuery = DalQueryView.queryGetUmcOrRequestId;
                    }

                    using (var command = new OracleCommand(strQuery, connection))
                    {

                        command.Parameters.Add(new OracleParameter(":umc", umc));

                        command.Parameters.Add(new OracleParameter(":requestId", requestId));

                        using (var reader = command.ExecuteReader())
                        {

                            dt.Load(reader);
                        }
                    }
                    connection.Close();


                }

            }
            catch (Exception ex)
            {
                return dt;
            }

            return dt;
        }
        //end of funtion


    }

    public class DalQueryView
    {
        public const string queryViewPendingRequest = @"SELECT a.CUA_REQUEST_ID,
                                        a.CUA_UMC,
                                        a.CUA_USER_REMARKS,
                                        r.CUR_QUESTION_ID,
                                        r.CUR_RESPONSE,
                                        r.CUR_CREATED_ON,
                                        q.CQM_QUES_DESC,
                                        a.CUA_STATUS
                                        FROM SAPSUR.T_SIS_CAP_UMC_APRVL a
                                        JOIN
                                        T_SIS_CAP_UMC_REQ r ON a.CUA_REQUEST_ID = r.CUR_REQUEST_ID
                                        JOIN
                                        SAPSUR.T_SIS_CAP_QUES_MASTER q ON r.CUR_QUESTION_ID = q.CQM_QUES_ID
                                        WHERE
                                        a.CUA_STATUS IN ('1', '2')
                                        ORDER BY
                                        a.CUA_REQUEST_ID";



        public const string queryGetUmcOrRequestId = @"SELECT a.CUA_REQUEST_ID,
                                    a.CUA_UMC,
                                    a.CUA_USER_REMARKS,
                                    r.CUR_QUESTION_ID,
                                    r.CUR_RESPONSE,
                                    r.CUR_CREATED_ON,
                                    q.CQM_QUES_DESC,
                                    a.CUA_STATUS
                                    FROM SAPSUR.T_SIS_CAP_UMC_APRVL a
                                    JOIN
                                    T_SIS_CAP_UMC_REQ r ON a.CUA_REQUEST_ID = r.CUR_REQUEST_ID
                                    JOIN
                                    SAPSUR.T_SIS_CAP_QUES_MASTER q ON r.CUR_QUESTION_ID = q.CQM_QUES_ID
                                    
                                    WHERE (a.CUA_UMC = :umc)
                                    OR (a.CUA_REQUEST_ID = :requestId)";


        public const string queryGetUmcAndRequestId = @"SELECT a.CUA_REQUEST_ID,
                                    a.CUA_UMC,
                                    a.CUA_USER_REMARKS,
                                    r.CUR_QUESTION_ID,
                                    r.CUR_RESPONSE,
                                    r.CUR_CREATED_ON,
                                    q.CQM_QUES_DESC,
                                    a.CUA_STATUS
                                    FROM SAPSUR.T_SIS_CAP_UMC_APRVL a
                                    JOIN
                                    T_SIS_CAP_UMC_REQ r ON a.CUA_REQUEST_ID = r.CUR_REQUEST_ID
                                    JOIN
                                    SAPSUR.T_SIS_CAP_QUES_MASTER q ON r.CUR_QUESTION_ID = q.CQM_QUES_ID
                                    WHERE (a.CUA_UMC = :umc)
                                    AND (a.CUA_REQUEST_ID = :requestId)";

    }
}