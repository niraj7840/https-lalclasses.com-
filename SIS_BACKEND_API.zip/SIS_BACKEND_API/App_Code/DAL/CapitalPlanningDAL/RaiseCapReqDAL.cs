﻿using Oracle.ManagedDataAccess.Client;
using SIS_BACKEND_API.Models;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Web;

namespace SIS_BACKEND_API.App_Code.DAL.CapitalPlanningDAL
{
    public class RaiseCapReqDAL
    {
        private string strConnSISDB = ConfigurationManager.ConnectionStrings["OracleConnection"].ConnectionString;


        //start of funtion

        public int AddRequestFinal(CapexApprovalRequest newApprovals, List<string> existingUmcList)
        {
            int result = 0;
            try
            {

                using (var connection = new OracleConnection(strConnSISDB))
                {
                    connection.Open();

                    // Check if any UMC exists in another table and is marked as 'R' or 'C'
                    foreach (FormModel newApproval in newApprovals.Forms)
                    {
                        string checkUmcQuery = "select CRU_UMC from T_SIS_CAP_REV_UMC where CRU_UMC=:CRU_UMC AND (CRU_TAG='R' OR CRU_TAG='C')";
                        using (var checkUmcCommand = new OracleCommand(checkUmcQuery, connection))
                        {
                            checkUmcCommand.Parameters.Add(new OracleParameter(":CRU_UMC", newApproval.UmcNumber));

                            var umc = checkUmcCommand.ExecuteScalar();
                            if (umc != null)
                            {
                                existingUmcList.Add(newApproval.UmcNumber);
                            }
                        }
                    }

                    // If any UMC is found, return those UMCs without performing the insert operation
                    if (existingUmcList.Any())
                    {
                        return -1; // Returning -1 to indicate that the operation was not performed
                    }


                    foreach (FormModel newApproval in newApprovals.Forms)
                    {

                        int newId;
                        using (var getLastIdCommand = new OracleCommand(DalQuery.getLastIdQuery, connection))
                        {
                            var lastId = getLastIdCommand.ExecuteScalar().ToString();

                            if (string.IsNullOrEmpty(lastId))
                            {
                                // If lastId is null or empty, start with 1
                                newId = 1;
                            }
                            else
                            {
                                // Convert lastId to integer and increment by 1
                                newId = Convert.ToInt32(lastId) + 1;
                            }

                        }


                        // Insert the new record


                        using (var insertCommand = new OracleCommand(DalQuery.insertCapRequestQuery1, connection))
                        {
                            OracleParameter paramRequestID = new OracleParameter("CUA_REQUEST_ID", OracleDbType.Varchar2);
                            paramRequestID.Value = newId;
                            insertCommand.Parameters.Add(paramRequestID);

                            OracleParameter paramUmc = new OracleParameter("CUA_UMC", OracleDbType.Varchar2);
                            paramUmc.Value = newApproval.UmcNumber;
                            insertCommand.Parameters.Add(paramUmc);

                            OracleParameter paramUserRemarks = new OracleParameter("CUA_USER_REMARKS", OracleDbType.Varchar2);
                            paramUserRemarks.Value = newApproval.Remarks;
                            insertCommand.Parameters.Add(paramUserRemarks);

                            OracleParameter paramStatus = new OracleParameter("CUA_STATUS", OracleDbType.Varchar2);
                            paramStatus.Value = "1";
                            insertCommand.Parameters.Add(paramStatus);

                            OracleParameter paramCapexApprovedBy = new OracleParameter("CUA_CAPEX_APPROVED_BY", OracleDbType.Varchar2);
                            paramCapexApprovedBy.Value = DBNull.Value;
                            insertCommand.Parameters.Add(paramCapexApprovedBy);

                            OracleParameter paramCapexApprovedOn = new OracleParameter("CUA_CAPEX_APPROVED_ON", OracleDbType.Date);
                            paramCapexApprovedOn.Value = DBNull.Value;
                            insertCommand.Parameters.Add(paramCapexApprovedOn);

                            OracleParameter paramCapexRemarks = new OracleParameter("CUA_CAPEX_REMARKS", OracleDbType.Varchar2);
                            paramCapexRemarks.Value = DBNull.Value;
                            insertCommand.Parameters.Add(paramCapexRemarks);

                            OracleParameter paramVpApprovedBy = new OracleParameter("CUA_VP_APPROVED_BY", OracleDbType.Varchar2);
                            paramVpApprovedBy.Value = DBNull.Value;
                            insertCommand.Parameters.Add(paramVpApprovedBy);

                            OracleParameter paramVpApprovedOn = new OracleParameter("CUA_VP_APPROVED_ON", OracleDbType.Date);
                            paramVpApprovedOn.Value = DBNull.Value;
                            insertCommand.Parameters.Add(paramVpApprovedOn);

                            OracleParameter paramVpRemarks = new OracleParameter("CUA_VP_REMARKS", OracleDbType.Varchar2);
                            paramVpRemarks.Value = DBNull.Value;
                            insertCommand.Parameters.Add(paramVpRemarks);

                            if (newApprovals.CUA_INTENT_NO.HasValue)
                            {
                                insertCommand.Parameters.Add(new OracleParameter("CUA_INTENT_NO", OracleDbType.Int32) { Value = newApprovals.CUA_INTENT_NO.Value });
                            }
                            else
                            {
                                insertCommand.Parameters.Add(new OracleParameter("CUA_INTENT_NO", OracleDbType.Int32) { Value = DBNull.Value });
                            }

                            result = insertCommand.ExecuteNonQuery();
                        }



                        // Get the IDs from the T_SIS_CAP_QUES_MASTER table
                        var questionIds = new List<int>();
                        string questionIdQuery = "SELECT CQM_QUES_ID FROM SAPSUR.T_SIS_CAP_QUES_MASTER";
                        using (var questionIdCommand = new OracleCommand(questionIdQuery, connection))
                        {
                            using (var reader = questionIdCommand.ExecuteReader())
                            {
                                while (reader.Read())
                                {
                                    questionIds.Add(reader.GetInt32(0));
                                    // reader.Close();
                                }
                            }
                        }


                        // Insert the question IDs into the CAP_UMC_REQ table

                        int i = 0;
                        foreach (var response in newApproval.QuestionResponses)
                        {
                            using (var insertCommand = new OracleCommand(DalQuery.insertCapRequestQuery2, connection))
                            {

                                OracleParameter paramCurRequest = new OracleParameter("CUR_REQUEST_ID", OracleDbType.Varchar2);
                                paramCurRequest.Value = newId;
                                insertCommand.Parameters.Add(paramCurRequest);

                                OracleParameter paramQuestionId = new OracleParameter("CUR_QUESTION_ID", OracleDbType.Int32);
                                paramQuestionId.Value = questionIds[i];
                                insertCommand.Parameters.Add(paramQuestionId);

                                OracleParameter paramCurResponse = new OracleParameter("CUR_RESPONSE", OracleDbType.Varchar2);
                                paramCurResponse.Value = response;
                                insertCommand.Parameters.Add(paramCurResponse);

                                OracleParameter paramCurCreatedBy = new OracleParameter("CUR_CREATED_BY", OracleDbType.Varchar2);
                                paramCurCreatedBy.Value = "User";
                                insertCommand.Parameters.Add(paramCurCreatedBy);

                                OracleParameter paramCurCreatedOn = new OracleParameter("CUR_CREATED_BY", OracleDbType.Date);
                                paramCurCreatedOn.Value = DateTime.Now;
                                insertCommand.Parameters.Add(paramCurCreatedOn);

                                result = insertCommand.ExecuteNonQuery();
                            }
                            i++;

                        }
                    }
                    connection.Close();
                }
            }
            catch (Exception ex)
            {
                return result;
            }


            return result;
        }

        //end of funtion
    }

    public class DalQuery
    {
        public const string getLastIdQuery = "SELECT MAX((CUA_REQUEST_ID)) FROM SAPSUR.T_SIS_CAP_UMC_APRVL";

        public const string insertCapRequestQuery1 = @"
                    INSERT INTO SAPSUR.T_SIS_CAP_UMC_APRVL (CUA_REQUEST_ID,
                        CUA_UMC, CUA_USER_REMARKS, CUA_STATUS, CUA_CAPEX_APPROVED_BY, 
                        CUA_CAPEX_APPROVED_ON, CUA_CAPEX_REMARKS, CUA_VP_APPROVED_BY, CUA_VP_APPROVED_ON, 
                        CUA_VP_REMARKS, CUA_INDENT_NO
                    ) VALUES (:CUA_REQUEST_ID,
                        :CUA_UMC, :CUA_USER_REMARKS, :CUA_STATUS, :CUA_CAPEX_APPROVED_BY, 
                        :CUA_CAPEX_APPROVED_ON, :CUA_CAPEX_REMARKS, :CUA_VP_APPROVED_BY, :CUA_VP_APPROVED_ON, 
                        :CUA_VP_REMARKS, :CUA_INDENT_NO
                    )";

        public const string insertCapRequestQuery2 = @"
                    INSERT INTO SAPSUR.T_SIS_CAP_UMC_REQ (CUR_REQUEST_ID, CUR_QUESTION_ID, CUR_RESPONSE, CUR_CREATED_BY, CUR_CREATED_ON)
                    VALUES (:CUR_REQUEST_ID, :CUR_QUESTION_ID, :CUR_RESPONSE, :CUR_CREATED_BY, :CUR_CREATED_ON)";

    }
}