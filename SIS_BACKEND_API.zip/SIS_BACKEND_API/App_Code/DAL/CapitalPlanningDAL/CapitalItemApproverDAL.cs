﻿using Oracle.ManagedDataAccess.Client;
using SIS_BACKEND_API.Models;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;

namespace SIS_BACKEND_API.App_Code.DAL.CapitalPlanningDAL
{
    public class CapitalItemApproverDAL
    {
        private string strConnSISDB = ConfigurationManager.ConnectionStrings["OracleConnection"].ConnectionString;



        //start of funtion

        public DataTable GetApproverScreen1(string role)
        {
            var approvalDataList = new List<CapexApprovalRequestData>();
            DataTable dt = new DataTable();
            if (role.ToLower() == "capex")
            {
                try
                {

                    using (var connection = new OracleConnection(strConnSISDB))
                    {
                        connection.Open();


                        using (var command = new OracleCommand(DalQueryApproval.GetApproverScreenForCapex, connection))
                        {
                            using (var reader = command.ExecuteReader())
                            {

                                dt.Load(reader);
                            }
                        }
                        connection.Close();


                    }
                }
                catch (Exception ex)
                {

                }

            }
            else if (role.ToLower() == "vp")
            {
                try
                {



                    using (var connection = new OracleConnection(strConnSISDB))
                    {
                        connection.Open();



                        using (var command = new OracleCommand(DalQueryApproval.GetApproverScreenForVp, connection))
                        {
                            using (var reader = command.ExecuteReader())
                            {

                                dt.Load(reader);
                            }
                        }
                        connection.Close();


                    }
                }
                catch (Exception ex)
                {
                    return dt;
                }
            }
            return dt;
        }

        //end of funtion


        //start of funtion
        public int UpdateApproverScreenRequestID(string role, UmcCapexApprovalUpdateModel model)
        {
            int rowsAffected = 0;
            if (role.ToLower() == "capex")
            {
                using (var connection = new OracleConnection(strConnSISDB))
                {
                    using (var command = new OracleCommand(DalQueryApproval.queryUpdateCapexApprove, connection))
                    {

                        OracleParameter paramCapRemark = new OracleParameter("remarks", OracleDbType.Varchar2);
                        paramCapRemark.Value = model.CUA_CAPEX_REMARKS;
                        command.Parameters.Add(paramCapRemark);

                        OracleParameter paramCapApprovedBy = new OracleParameter("approvedBy", OracleDbType.Varchar2);
                        paramCapApprovedBy.Value = "808986";
                        command.Parameters.Add(paramCapApprovedBy);

                        OracleParameter paramRequestId = new OracleParameter("requestId", OracleDbType.Varchar2);
                        paramRequestId.Value = model.CUA_REQUEST_ID;
                        command.Parameters.Add(paramRequestId);
                        try
                        {
                            connection.Open();
                            rowsAffected = command.ExecuteNonQuery();

                            /**if (rowsAffected == 0)
                            {
                                return NotFound();
                            }
                            return Ok(new { RowsAffected = rowsAffected });
                            */


                        }
                        catch (Exception ex)
                        {
                            return rowsAffected;
                        }

                    }

                }
            }
            else if (role.ToLower() == "vp")
            {
                using (var connection = new OracleConnection(strConnSISDB))
                {
                    using (var command = new OracleCommand(DalQueryApproval.queryUpdateVpApprove, connection))
                    {

                        OracleParameter paramVpRemark = new OracleParameter("remarks", OracleDbType.Varchar2);
                        paramVpRemark.Value = model.CUA_VP_REMARKS;
                        command.Parameters.Add(paramVpRemark);

                        OracleParameter paramVpApprovedBy = new OracleParameter("approvedBy", OracleDbType.Varchar2);
                        paramVpApprovedBy.Value = "808518";
                        command.Parameters.Add(paramVpApprovedBy);

                        OracleParameter paramRequestId = new OracleParameter("requestId", OracleDbType.Varchar2);
                        paramRequestId.Value = model.CUA_REQUEST_ID;
                        command.Parameters.Add(paramRequestId);
                        try
                        {
                            connection.Open();
                            rowsAffected = command.ExecuteNonQuery();

                            /** 
                             * if (rowsAffected == 0)
                             {
                                 return NotFound();
                             }
                             return Ok(new { RowsAffected = rowsAffected }); */


                        }
                        catch (Exception ex)
                        {
                            return rowsAffected;
                        }

                    }

                }

            }
            return rowsAffected;
        }


        //end of funtion


        //start of funtion
        public int UpdateApproverScreenRejectRequestID(string role, UmcCapexApprovalUpdateModel model)
        {
            int rowsAffected = 0;
            if (role.ToLower() == "capex")
            {
                using (var connection = new OracleConnection(strConnSISDB))
                {

                    using (var command = new OracleCommand(DalQueryApproval.queryUpdateCapexReject, connection))
                    {

                        OracleParameter paramCapRemark = new OracleParameter("remarks", OracleDbType.Varchar2);
                        paramCapRemark.Value = model.CUA_CAPEX_REMARKS;
                        command.Parameters.Add(paramCapRemark);


                        OracleParameter paramRequestId = new OracleParameter("requestId", OracleDbType.Varchar2);
                        paramRequestId.Value = model.CUA_REQUEST_ID;
                        command.Parameters.Add(paramRequestId);
                        try
                        {
                            connection.Open();
                            rowsAffected = command.ExecuteNonQuery();

                            /** if (rowsAffected == 0)
                             {
                                 return NotFound();
                             }
                             return Ok(new { RowsAffected = rowsAffected });*/


                        }
                        catch (Exception ex)
                        {
                            return rowsAffected;
                        }
                    }
                }

            }
            else if (role.ToLower() == "vp")
            {
                using (var connection = new OracleConnection(strConnSISDB))
                {



                    using (var command = new OracleCommand(DalQueryApproval.queryUpdateVpReject, connection))
                    {

                        OracleParameter paramVpRemark = new OracleParameter("remarks", OracleDbType.Varchar2);
                        paramVpRemark.Value = model.CUA_VP_REMARKS;
                        command.Parameters.Add(paramVpRemark);


                        OracleParameter paramRequestId = new OracleParameter("requestId", OracleDbType.Varchar2);
                        paramRequestId.Value = model.CUA_REQUEST_ID;
                        command.Parameters.Add(paramRequestId);
                        try
                        {
                            connection.Open();
                            rowsAffected = command.ExecuteNonQuery();

                            /** if (rowsAffected == 0)
                             {
                                 return NotFound();
                             }
                             return Ok(new { RowsAffected = rowsAffected });*/


                        }
                        catch (Exception ex)
                        {
                            return rowsAffected;
                        }

                    }

                }

            }
            return rowsAffected;

        }


        //end of funtion


        // start of function

        public int UPSERTAPPROVEPAGE(T_CAP_REV_UMC model)
        {
            int result = 0;
            using (OracleConnection connection = new OracleConnection(strConnSISDB))
            {
                connection.Open();
                OracleTransaction transaction = connection.BeginTransaction();
                try
                {


                    using (OracleCommand command = new OracleCommand(DalQueryApproval.queryUpsertCapitalTagApprovalByVp, connection))
                    {

                        command.Parameters.Add(":CRU_UMC", model.CRU_UMC);
                        command.Parameters.Add(":CRU_TAG", model.CRU_TAG);
                        command.Parameters.Add(":CRU_REQUEST_ID", model.CRU_REQUEST_ID);
                        command.Parameters.Add(":CRU_STATUS", 'N');
                        command.Parameters.Add(":CRU_CREATED_BY", "vp");




                        result = command.ExecuteNonQuery();
                    }

                    transaction.Commit();

                }
                catch (Exception ex)
                {
                    transaction.Rollback();


                }
                return result;
            }
        }


        //end of funtion

        //start of funtion

        public int CAPEXMARKEDREVENUE(string role, T_CAP_REV_UMC model)
        {
            int result = 0;
            if (role.ToLower() == "capex")
            {
                using (OracleConnection connection = new OracleConnection(strConnSISDB))
                {
                    connection.Open();
                    OracleTransaction transaction = connection.BeginTransaction();
                    try
                    {


                        using (OracleCommand command = new OracleCommand(DalQueryApproval.queryUpsertRevenueTagByCapex, connection))
                        {

                            command.Parameters.Add(":CRU_UMC", model.CRU_UMC);
                            command.Parameters.Add(":CRU_TAG", model.CRU_TAG);
                            command.Parameters.Add(":CRU_REQUEST_ID", model.CRU_REQUEST_ID);
                            command.Parameters.Add(":CRU_STATUS", 'N');
                            command.Parameters.Add(":CRU_CREATED_BY", "Capex Team");




                            result = command.ExecuteNonQuery();
                        }

                        transaction.Commit();

                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();


                    }
                }
            }
            else if (role.ToLower() == "vp")
            {
                using (OracleConnection connection = new OracleConnection(strConnSISDB))
                {
                    connection.Open();
                    OracleTransaction transaction = connection.BeginTransaction();
                    try
                    {


                        using (OracleCommand command = new OracleCommand(DalQueryApproval.queryUpsertRevenueTagByVp, connection))
                        {

                            command.Parameters.Add(":CRU_UMC", model.CRU_UMC);
                            command.Parameters.Add(":CRU_TAG", model.CRU_TAG);
                            command.Parameters.Add(":CRU_REQUEST_ID", model.CRU_REQUEST_ID);
                            command.Parameters.Add(":CRU_STATUS", 'N');
                            command.Parameters.Add(":CRU_CREATED_BY", "vp");




                            result = command.ExecuteNonQuery();
                        }

                        transaction.Commit();

                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();


                    }
                }
            }
            return result;
        }
        //end of funtion


    }

    public class DalQueryApproval
    {
        public const string GetApproverScreenForCapex = @"SELECT a.CUA_REQUEST_ID, a.CUA_UMC, a.CUA_USER_REMARKS, r.CUR_QUESTION_ID, r.CUR_RESPONSE, r.CUR_CREATED_ON, q.CQM_QUES_DESC
                                    FROM SAPSUR.T_SIS_CAP_UMC_APRVL a
                                    JOIN
                                    T_SIS_CAP_UMC_REQ r ON a.CUA_REQUEST_ID = r.CUR_REQUEST_ID
                                    JOIN
                                    SAPSUR.T_SIS_CAP_QUES_MASTER q ON r.CUR_QUESTION_ID = q.CQM_QUES_ID
                                    WHERE
                                    a.CUA_STATUS = '1'
                                    ORDER BY
                                    a.CUA_REQUEST_ID";

        public const string GetApproverScreenForVp = @"SELECT a.CUA_REQUEST_ID, a.CUA_UMC, a.CUA_USER_REMARKS, r.CUR_QUESTION_ID, r.CUR_RESPONSE, r.CUR_CREATED_ON, q.CQM_QUES_DESC
                                    FROM SAPSUR.T_SIS_CAP_UMC_APRVL a
                                    JOIN
                                    T_SIS_CAP_UMC_REQ r ON a.CUA_REQUEST_ID = r.CUR_REQUEST_ID
                                    JOIN
                                    SAPSUR.T_SIS_CAP_QUES_MASTER q ON r.CUR_QUESTION_ID = q.CQM_QUES_ID
                                    WHERE
                                    a.CUA_STATUS = '2'
                                    ORDER BY
                                    a.CUA_REQUEST_ID";

        public const string queryUpdateCapexApprove = @"UPDATE SAPSUR.T_SIS_CAP_UMC_APRVL
                                        SET CUA_CAPEX_REMARKS = :remarks,
                                            CUA_CAPEX_APPROVED_BY=:approvedBy,
                                            CUA_STATUS = TO_CHAR(TO_NUMBER(CUA_STATUS) + 1),
                                            CUA_CAPEX_APPROVED_ON = SYSDATE
                                            WHERE CUA_REQUEST_ID = :requestId
                                             AND CUA_STATUS='1'";

        public const string queryUpdateVpApprove = @"UPDATE SAPSUR.T_SIS_CAP_UMC_APRVL
                                        SET CUA_VP_REMARKS = :remarks,
                                            CUA_VP_APPROVED_BY=:approvedBy,
                                            CUA_STATUS = TO_CHAR(TO_NUMBER(CUA_STATUS) + 1),
                                            CUA_VP_APPROVED_ON = SYSDATE
                                            WHERE CUA_REQUEST_ID = :requestId
                                             AND CUA_STATUS='2'";

        public const string queryUpdateCapexReject = @"UPDATE SAPSUR.T_SIS_CAP_UMC_APRVL
                                        SET CUA_CAPEX_REMARKS = :remarks,
                                            CUA_STATUS = TO_CHAR(TO_NUMBER(CUA_STATUS) + 3)
                                            WHERE CUA_REQUEST_ID = :requestId
                                             AND CUA_STATUS='1'";

        public const string queryUpdateVpReject = @"UPDATE SAPSUR.T_SIS_CAP_UMC_APRVL
                                        SET CUA_VP_REMARKS = :remarks,
                                            CUA_STATUS = TO_CHAR(TO_NUMBER(CUA_STATUS) + 3)
                                            WHERE CUA_REQUEST_ID = :requestId
                                             AND CUA_STATUS='2'";



        public const string queryUpsertCapitalTagApprovalByVp = @"DECLARE
                                      UMCexists number :=0;
                                      BEGIN
                                      Select COUNT(*) into UMCexists from T_SIS_CAP_REV_UMC where CRU_UMC=:CRU_UMC;
                                    if(UMCexists <= 0)
                                    THEN
                                      INSERT INTO T_SIS_CAP_REV_UMC
                                      (CRU_UMC, CRU_TAG, CRU_REQUEST_ID, CRU_STATUS, CRU_CREATED_BY, CRU_CREATED_ON)
                                      VALUES
                                      (:CRU_UMC, :CRU_TAG, :CRU_REQUEST_ID, :CRU_STATUS, :CRU_CREATED_BY, SYSDATE);
                                    ELSE
                                      UPDATE T_SIS_CAP_REV_UMC
                                      SET
                                      CRU_TAG=:CRU_TAG,
                                      CRU_CREATED_BY=:CRU_CREATED_BY,
                                      CRU_CREATED_ON=SYSDATE
                                      WHERE CRU_UMC=:CRU_UMC;
                                    END IF;
                                    END;";

        public const string queryUpsertRevenueTagByCapex = @"DECLARE
                                      UMCexists number :=0;
                                      BEGIN
                                      Select COUNT(*) into UMCexists from T_SIS_CAP_REV_UMC where CRU_UMC=:CRU_UMC;
                                    if(UMCexists <= 0)
                                    THEN
                                      INSERT INTO T_SIS_CAP_REV_UMC
                                      (CRU_UMC, CRU_TAG, CRU_REQUEST_ID, CRU_STATUS, CRU_CREATED_BY, CRU_CREATED_ON)
                                      VALUES
                                      (:CRU_UMC, :CRU_TAG, :CRU_REQUEST_ID, :CRU_STATUS, :CRU_CREATED_BY, SYSDATE);
                                    ELSE
                                      UPDATE T_SIS_CAP_REV_UMC
                                      SET
                                      CRU_TAG=:CRU_TAG,
                                      CRU_CREATED_BY=:CRU_CREATED_BY,
                                      CRU_CREATED_ON=SYSDATE
                                      WHERE CRU_UMC=:CRU_UMC;
                                    END IF;
                                    END;";

        public const string queryUpsertRevenueTagByVp = @"DECLARE
                                      UMCexists number :=0;
                                      BEGIN
                                      Select COUNT(*) into UMCexists from T_SIS_CAP_REV_UMC where CRU_UMC=:CRU_UMC;
                                    if(UMCexists <= 0)
                                    THEN
                                      INSERT INTO T_SIS_CAP_REV_UMC
                                      (CRU_UMC, CRU_TAG, CRU_REQUEST_ID, CRU_STATUS, CRU_CREATED_BY, CRU_CREATED_ON)
                                      VALUES
                                      (:CRU_UMC, :CRU_TAG, :CRU_REQUEST_ID, :CRU_STATUS, :CRU_CREATED_BY, SYSDATE);
                                    ELSE
                                      UPDATE T_SIS_CAP_REV_UMC
                                      SET
                                      CRU_TAG=:CRU_TAG,
                                      CRU_CREATED_BY=:CRU_CREATED_BY,
                                      CRU_CREATED_ON=SYSDATE
                                      WHERE CRU_UMC=:CRU_UMC;
                                    END IF;
                                    END;";
    }
}