﻿//-------------------------------------------------------------------------------------------------------------------------------------------------
//CLASS NAME: ConnectionSQLDB
//=================================================================================================================================================
//DESCRIPTION: This class helps in establishing connection with the SQL Server Database.
//=================================================================================================================================================
//CHANGE HISTORY
//-------------------------------------------------------------------------------------------------------------------------------------------------
//Version               Date                Name                Change                      Work Done
//-------------------------------------------------------------------------------------------------------------------------------------------------
//1.0                   03/01/2014          Abhinandan Singh         Initial Creation               - 
//-------------------------------------------------------------------------------------------------------------------------------------------------


using System;
using System.Data;
using System.Data.SqlClient;

/// <summary>
/// Summary description for ConnectionSQLDB
/// </summary>
public class ConnectionSQLDB
{
    #region variables
    string connString = null;
    SqlCommand Command = null;
    SqlConnection DBConnection = null;
    SqlDataAdapter DataAdapter = null;
    public DataTable ResultantTable = null;
    public SqlDataReader DataReader = null;
    #endregion

    /// <summary>
    /// Parameterized constructor for initializing the connection object and Data Table.
    /// </summary>
    /// <param name="connString"></param>
    /// <param name="needDataTable"></param>
    public ConnectionSQLDB(string connString, string strQuery, CommandType commandType, bool needDataTable)
	{
        //Initialize the SQLConnection object with the passed string.
        DBConnection = new SqlConnection(connString);

        //Initialize the SQL Command object with the passed SQL Connection object and SQL Query.
        Command = new SqlCommand(strQuery, DBConnection);
        //Set the command type attribute of the SQL Command.
        Command.CommandType = commandType;

        //If the data from the query is to be fetched into a Data Table == true
        if (needDataTable == true)
        {
            //Initialize the Data Table.
            ResultantTable = new DataTable();
            //Initialize the Data Adapter.
            DataAdapter = new SqlDataAdapter(Command);
        }
    }

    /// <summary>
    /// This method is used to open the SQL Connection.
    /// </summary>
    public void OpenConnection()
    {
        //Checks whether the connection has been opened early. If yes it reset the connection string, if no it will open the connection.        
        if (DBConnection.State == ConnectionState.Closed)
        {
            DBConnection.Open();
        }
    }

    /// <summary>
    /// This method is used to close the SQL Connection.
    /// </summary>
    public void CloseConnection()
    {
        //Checks whether the connection has been opened early. If yes it reset the connection string, if no it will open the connection.
        if (DBConnection.State == ConnectionState.Open)
        {
            DBConnection.Close();
        }
    }

    /// <summary>
    /// Adds the Parameters to the Command Object Required for the execution.
    /// </summary>
    /// <param name="ParameterName">Name of the parameter with Prefix : </param>
    /// <param name="Value">Value of the Parameter </param>
    public void AddParameters(String ParameterName, object Value)
    {
        if (Command != null)
        {
            //Add Parameters to the SQL Command.
            Command.Parameters.AddWithValue(ParameterName, Value);
        }
        else
        {
            throw new ApplicationException("Sql Command is being used without initialization");
        }
    }

    /// <summary>
    /// Adds the Parameters to the Command Object Required for the execution.
    /// </summary>
    /// <param name="ParameterName">Name of the parameter with Prefix : </param>
    /// <param name="Value">Value of the Parameter </param>
    public SqlParameter AddParametersWithVal(String ParameterName, object Value)
    {
        if (Command != null)
        {
            //Add Parameters to the SQL Command.
            return Command.Parameters.AddWithValue(ParameterName, Value);
        }
        else
        {
            throw new ApplicationException("Sql Command is being used without initialization");
        }
    }

    /// <summary>
    /// Executes Non Query on the SQL Command
    /// </summary>
    /// <returns>Returns the No of Rows affected by executing the Stored Procedure/SQL Query</returns>
    public int ExecuteNonQuery()
    {
        //Execute the Command if the connection state is opened else throw an Application Exception.
        if (DBConnection.State == ConnectionState.Open)
        {
            return Command.ExecuteNonQuery();
        }
        else
        {
            throw new ApplicationException("Connnection Not Opened");
        }
    }

    /// <summary>
    /// Executes Scalar on the SQL Command
    /// </summary>
    /// <returns>Returns the No of Rows affected by executing the Stored Procedure/SQL Query</returns>
    public object ExecuteScalar()
    {
        //Execute the Command if the connection state is opened else throw an Application Exception.
        if (DBConnection.State == ConnectionState.Open)
        {
            return Command.ExecuteScalar();
        }
        else
        {
            throw new ApplicationException("Connnection Not Opened");
        }
    }


    /// <summary>
    ///  This method populates ResultantDataTable with the data fetched by executing the query.  
    /// </summary>
    public void FillDataTable()
    {
        //If the data adapter is initialized then invoke the Fill method on the data adapter else throw and Application Exception.
        if (DataAdapter != null)
        {
            DataAdapter.Fill(ResultantTable);
        }
        else
        {
            throw new ApplicationException("Data Adapter is being used without initialization");
        }
    }


    /// <summary>
    /// Executes the Reader Operation
    /// After executing the DataReader will start pointing to the result set.
    /// </summary>
    public void ExecuteReader()
    {
        //Application Exception is thrown if the connection is not opened.
        if (DBConnection.State != ConnectionState.Open)
        {
            throw new ApplicationException("Connnection Not Opened");
        }

        //If the command is not null then the DataReader object is made to point to the result set.Else an ApplicationException is thrown.
        if (Command != null)
        {
            DataReader = Command.ExecuteReader();
        }
        else
        {
            throw new ApplicationException("Sql Command is being used without initialization");
        }
    }




}