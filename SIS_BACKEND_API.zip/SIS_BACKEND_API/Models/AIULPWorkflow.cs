﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SIS_BACKEND_API.Models
{
    public class AIULPUMC
    {

        public int UmcIndentId {  get; set; }

        public int IndentId { get; set; }

        public int Quantity {  get; set; } 

        public DateTime CreatedDate { get; set; }

        public string UMCStatus { get; set; }

        public int TotalSAPQty { get; set; }

        public int AIULPInventory {  get; set; }

        public int IntaInventory { get; set; }

        
       

    }

    public class AIULPWorkflow
    {
        public int WfID { get; set; }
        public int UmcIndentId { get; set; }
        public int Quantity { get; set; }

        public int ApprovedQuantity { get; set; }

        public string WFType { get; set; }

        public string WFStatus { get; set; }

        public string SrcPlantId { get; set; }

        public string SrcDeptId { get; set; }

        public DateTime WFExpiryDate { get; set; }
        public DateTime LastUpdated { get; set; }

        public DateTime CreatedDate { get; set; }

        public int MrQTY { get; set; }

        public int StrQTY { get; set; }

        public int StoQty { get; set; }

        public int SAPDOCQTY { get; set; }

        public bool SAPUpdateStatus { get; set; }

        public string WFRemarks {  get; set; }

        public bool IsDataUpdatedFromSAP { get; set; }

        public string SAPErrorMessage { get; set; }

        public bool IsDataUpdatedOnSAP { get; set; }

        public int Approved_QTY { get; set; }

    }
}