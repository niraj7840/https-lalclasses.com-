﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Http;

namespace SIS_BACKEND_API.Models
{

    public class QuestionDetails
    {
        public int CQM_QUES_ID { get; set; }
        public string CQM_QUES_DESC { get; set; }
        public string CQM_ACTIVE_FLAG { get; set; }

        public string CQM_CREATED_BY { get; set; }

        public DateTime? CQM_CREATED_ON { get; set; }

    }
}