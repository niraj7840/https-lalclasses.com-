using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SIS_BACKEND_API.Models
{
    public class GenericModel
    {



    }
    public enum MessageType
    {
        success = 17, warning = 18, error = 19, info = 20
    }
    public class Message
    {
        public MessageType Status { get; set; }
        public string Text { get; set; }
        public dynamic jsonData { get; set; }
    }

    public partial class Users
    {
        public string User_Id { get; set; }
        public string User_Name { get; set; }
        public string User_Dept { get; set; }
       
    }


    public partial class UsersDetails
    {
        public string User_Id { get; set; }
        public string User_Name { get; set; }
        public string User_Dept { get; set; }
        public string User_EmailId { get; set; }
        public string User_contactNumber { get; set; }

    }
}