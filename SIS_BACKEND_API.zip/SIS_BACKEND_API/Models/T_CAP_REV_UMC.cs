﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SIS_BACKEND_API.Models
{
    public class T_CAP_REV_UMC
    {
        public string CRU_UMC { get; set; }
        public string CRU_TAG { get; set; }
        public string CRU_REQUEST_ID { get; set; }
        public string CRU_STATUS { get; set; }
        public string CRU_CREATED_BY { get; set; }
        public DateTime? CRU_CREATED_ON { get; set; }

    }
}