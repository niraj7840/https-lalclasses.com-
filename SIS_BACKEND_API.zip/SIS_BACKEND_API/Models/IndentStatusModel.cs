﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SIS_BACKEND_API.Models
{
    public class IndentStatusModel
    {
        public string DTF { get; set; }
        public string DTT { get; set; }
        public string DEPT { get; set; }
        public string FOD { get; set; }
        public string STATUS { get; set; }
        public string INDENTNO { get; set; }
        public string DOCTYPE { get; set; }
        public string USERNAME { get; set; }
    }
}