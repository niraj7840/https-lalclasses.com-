﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SIS_BACKEND_API.Models.IntelliBuyModel
{
    public class IntelliBuyChecks
    {

        public IntelliBuyChecksHeader ObjIntelliBuyChecksHeader { get; set; }
        public List<IntelliBuyIndentDetails> ObjIntelliBuyIndentDetails { get; set; }
        public string IsDraft { get; set; }
    }
    public class IntelliBuyChecksHeader
    {
        public int HEADER_ID { get; set; }
        public string INDENT_ID { get; set; }
        public string INDENTER_LOC { get; set; }
        public string INDENTOR_PLANT { get; set; }
        public string INDENTER_DEPT { get; set; }
        public string INDENT_DESC { get; set; }
        public string INDENT_REMARKS { get; set; }
        public string INDENT_CRT_BY { get; set; }
        public string INDENT_CRT_DT { get; set; }
        public string INDENT_MOD_BY { get; set; }
        public string INDENT_MOD_DT { get; set; }
        public string INDENT_STATUS { get; set; }
        public string SCH_CART_NO { get; set; }
        //  public string SCH_CRT_DT { get; set; }
        public string SCH_USR_NAME { get; set; }
        public string ISACTIVE { get; set; }

    }
    public class IntelliBuyChecksItems
    {
        public int ITEM_ID { get; set; }
        public string INDENT_ID { get; set; }
        public string INDENT_ID_NO { get; set; }
        public string SCI_MATL_DESC { get; set; }
        public string EXISTING_UMC { get; set; }
        public string EXISTING_UMC_DESC { get; set; }
        public string SCI_MATL_GROUP { get; set; }
        public string SCI_PROD_TYPE { get; set; }
        public string SCI_PLANT_CD { get; set; }
        public string SCI_STRG_LOC { get; set; }
        public string SCI_PUR_GROUP { get; set; }
        public string SCI_DOC_TYPE { get; set; }
        public string SCI_QTY { get; set; }
        public string SCI_QTY_UNIT { get; set; }
        public string SCI_PRICE { get; set; }
        public string SCI_FRN_CURR_CD { get; set; }
        public string SCI_REQD_ON_DT { get; set; }
        public string CONSUMP_DT { get; set; }
        public string SCI_STATUS { get; set; }
        public string SCI_DEL_IND { get; set; }
        public string SCI_SAP_ERR_MSG { get; set; }
        public string SCI_PROP_TAG { get; set; }
        public string SCI_REFFB_TAG { get; set; }
        public string SCI_PERISIBL_TAG { get; set; }
        public string SCI_SPARE_CAT { get; set; }
        public string SCI_REMARKS { get; set; }
        public string IS_ACTIVE { get; set; }
        public string CRT_BY { get; set; }
        // public string CRT_DT { get; set; }
        public string MOD_BY { get; set; }
        // public string MOD_DT { get; set; }

    }
    public class IntelliBuyIndentDetails
    {
        //public int ITEM_ID { get; set; }
        //public int ALLOWEDQTY { get; set; }
        //public string DOCUMENT_TYPE { get; set; }
        //public string FOD_TYPE { get; set; }
        //public string INDENTOR_PLANT { get; set; }
        //public string INDENT_CURRENT_STATUS { get; set; }
        //public int INDENT_ID { get; set; }
        //public string INDENT_STATUS { get; set; }
        //public string PRICE_PER_ITEM { get; set; }
        //public int QTY { get; set; }
        //public string REQUIREMENT_DATE { get; set; }
        //public string REQ_UMC_BGG { get; set; }
        //public string REQ_UMC_DESC { get; set; }
        //public string REQ_UMC_NO { get; set; }
        //public string TAGGEDUMC { get; set; }
        //public int TOTAL_SAP_DOC_QTY { get; set; }
        //public int UMC_INDENT_ID { get; set; }
        //public string UOM { get; set; }
        //public string ISACTIVE { get; set; }
        public int SRNO { get; set; }
        public int INDENT_ID { get; set; }
        public string INDENTOR_PLANT { get; set; }
        public string REQ_UMC_NO { get; set; }
        public string REQ_UMC_BGG { get; set; }
        public string REQUIREMENT_DATE { get; set; }
        public string PRICE_PER_ITEM { get; set; }
        public string DOCUMENT_TYPE { get; set; }
        public string FOD_TYPE { get; set; }
        public string REQ_UMC_DESC { get; set; }
        public string UOM { get; set; }
        public string INDENT_CURRENT_STATUS { get; set; }
        public string INDENT_CURRENT_STATUS_CODE { get; set; }
        public string EXISTING_UMC { get; set; }
        public string TAGGEDUMC { get; set; }
        public int TOTAL_SAP_DOC_QTY { get; set; }
        public int ALLOWEDQTY { get; set; }
        public int UMC_INDENT_ID { get; set; }
        public string INDENTOR_DEPT { get; set; }
        public string INDENT_DESC { get; set; }
        public string INDENT_REMARKS { get; set; }
        public string ISACTIVE { get; set; }
        public string IS_REFURBISHABLE { get; set; }
        public int ITEM_ID { get; set; }
        public string QTY { get; set; }
        public string SYS_REQ_DATE { get; set; }
        public string DOCUMENT_TYPE_DESC { get; set; }
        public string DEPT { get; set; }
        public string CONSUMP_DT { get; set; }
        public string ReqDate { get; set; }
        public string ConsDate { get; set; }
        public string ARC_VMI { get; set; }
        public bool RCM_Status { get; set; }
        public bool VMI_Status { get; set; }
        public bool MAXQY_Status { get; set; }
    }

}