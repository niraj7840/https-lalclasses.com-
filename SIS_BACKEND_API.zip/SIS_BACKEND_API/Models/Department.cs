﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SIS_BACKEND_API.Models
{
    public class Department
    {
        public string dept { get; set; }
        public string deptName { get; set; }
        public string plant { get; set; }
    }
}