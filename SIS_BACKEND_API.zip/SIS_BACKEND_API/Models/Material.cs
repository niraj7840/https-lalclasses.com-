﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SIS_BACKEND_API.Models
{
    public class Material
    {
        public string umcno { get; set; }
        public string unitOfMeasure { get; set; }

        public string materialDescription { get; set; }

        public string currency { get; set; }

        public string materialBGG { get; set; }

    }
}