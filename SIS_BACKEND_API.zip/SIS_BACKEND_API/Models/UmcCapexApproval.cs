﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SIS_BACKEND_API.Models
{
    public class UmcCapexApproval
    {
        public int CUA_REQUEST_ID { get; set; }
        public string CUA_UMC { get; set; }
        public string CUA_USER_REMARKS { get; set; }
        public string CUA_STATUS { get; set; }
        public string CUA_CAPEX_APPROVED_BY { get; set; }
        public DateTime? CUA_CAPEX_APPROVED_ON { get; set; }
        public string CUA_CAPEX_REMARKS { get; set; }
        public string CUA_VP_APPROVED_BY { get; set; }

        public DateTime? CUA_VP_APPROVED_ON { get; set; }

        public string CUA_VP_REMARKS { get; set; }

        public int CUA_INTENT_NO { get; set; }
    }
}






