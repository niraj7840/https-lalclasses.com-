﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SIS_BACKEND_API.Models
{
    public class WorkFlowDetails
    {
        public static List<WorkFlow> getWorkflow { get; set; } = new List<WorkFlow>()
        {
    new WorkFlow{
      WorkflowID= "1",
      IndentNumber= "IND001",
      IndentDesc= "Move Quantity",
      UMCNo= "UMC001",
      UMCDesc= "Material 1",
      WFCategory= "AIULP",
      RequestedQuantity= "5",
      UOM= "Nos",
      SourcePlant= "Plant Name 1",
      SourceLOC= "Loc 1",
      SourceDept= "Dept 1",
      ConsumptionDt= "01-Apr-2024",
      RequestDt= "25-Mar-2024",
      ProcType= "Routine",
      PendingSince= "05-Apr-2024"
    },
    new WorkFlow{

      WorkflowID= "2",
      IndentNumber= "IND001",
      IndentDesc= "Move Quantity",
      UMCNo= "UMC001",
      UMCDesc= "Material 1",
      WFCategory= "AIULP",
      RequestedQuantity= "5",
      UOM= "Nos",
      SourcePlant= "Plant Name 1",
      SourceLOC= "Loc 1",
      SourceDept= "Dept 3",
      RequestDt= "25-Mar-2024",
      ProcType= "Routine",
      ConsumptionDt= "01-Apr-2024",
      PendingSince= "05-Apr-2024"
    },
    new WorkFlow{
      WorkflowID= "4",
      IndentNumber= "IND004",
      IndentDesc= "Move Quantity",
      UMCNo= "UMC006",
      UMCDesc= "Material 2",
      WFCategory= "INTRA",
      RequestedQuantity= "4",
      UOM= "Nos",
      SourcePlant= "Plant Name 1",
      SourceLOC= "Loc 1",
      SourceDept= "Dept1 ",
      RequestDt= "25-Mar-2024",
      ProcType= "Routine",
      ConsumptionDt= "01-Apr-2024",
      PendingSince= "05-Apr-2024"

    }
        };
    }

    public class WorkFlow
    {
        public string WorkflowID { get; set; }
        public string IndentNumber { get; set; }
        public string IndentDesc { get; set; }
        public string UMCNo { get; set; }
        public string UMCDesc { get; set; }
        public string WFCategory { get; set; }
        public string RequestedQuantity { get; set; }
        public string UOM { get; set; }
        public string SourcePlant { get; set; }
        public string SourceLOC { get; set; }
        public string SourceDept { get; set; }
        public string RequestDt { get; set; }
        public string ProcType { get; set; }
        public string ConsumptionDt { get; set; }
        public string PendingSince { get; set; }
    }
}