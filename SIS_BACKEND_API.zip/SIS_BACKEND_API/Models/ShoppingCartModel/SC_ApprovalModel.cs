﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SIS_BACKEND_API.Models.ShoppingCartModel
{
    
    public class ApprovalRequest
    {
        public int tot_amnt { get; set; }
        public string indnt_type { get; set; }
        public int scartno { get; set; }
        public int dept_no { get; set; }
        public int Committed_Expenditure_Val { get; set; }
        public int Spare_Budget_Val { get; set; }       
        
    }

    public class ApprovalSection
    {
        public string nscnum { get; set; }
        public string _status { get; set; }
        public string appr_id { get; set; }
        public string appr_rem { get; set; }      
        public string mail_to { get; set; }
        public string IMEI_no { get; set; }

    }


    public class FileUploadModel
    {
        public string FileName { get; set; }
        public byte[] FileContent { get; set; }
        public int Sno { get; set; }
        public string UserId { get; set; }
    }


}