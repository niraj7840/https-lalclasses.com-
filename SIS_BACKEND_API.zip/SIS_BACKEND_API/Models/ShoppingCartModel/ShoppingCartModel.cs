﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SIS_BACKEND_API.Models.ShoppingCartModel
{
    public class ShoppingCartModel
    {

    }
    public class ShoppingCartHeader
    {
        public int v_sch_cart_no { get; set; }    
        public string V_SCH_CART_NAME { get; set; }
        public string V_SCH_CRT_ID { get; set; }
        public string D_SCH_CRT_DT { get; set; }
        public string N_SCH_TOT_VAL { get; set; }
        public string V_SCH_VAL_UNIT { get; set; }
        public string V_SCH_STATUS { get; set; }
        public string V_SCH_NOTE_APP { get; set; }
        public string V_SCH_UPD_ID { get; set; }
        public string D_SCH_UPD_DT { get; set; }
        public string V_SCH_INDT_TYP { get; set; }
        public string V_SCH_COMP_CD { get; set; }
        public string D_SCH_CRT_TIMESTAMP { get; set; }
        public string N_SCH_APPR_LVL { get; set; }
        public int v_sch_dept { get; set; }
        public int CRT_BY { get; set; }
        public int MOD_BY { get; set; }
    }

    public class ShoppingCartItem
    {
        public int n_sci_cart_no { get; set; }
        public int N_SCI_ITEM_NO { get; set; } 
        public string V_SCI_ITEM_DESC { get; set; }
        public string V_SCI_PROD_TYPE { get; set; }
        public string V_SCI_MATL_NO { get; set; }
        public string V_SCI_MATL_GRP { get; set; }
        public string V_SCI_PLANT_CD { get; set; }
        public string N_SCI_QTY { get; set; }
        public string V_SCI_QTY_UNIT { get; set; }
        public string d_rqdt_on { get; set; }
        public string err_msg { get; set; }
        public int CRT_BY { get; set; }
        public int MOD_BY { get; set; }

    }

}

